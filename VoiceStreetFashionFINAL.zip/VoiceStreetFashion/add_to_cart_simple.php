<?php
session_start();
require_once 'includes/database.php';

if (!isset($_SESSION['user_id'])) {
    $_SESSION['login_redirect'] = $_SERVER['HTTP_REFERER'] ?? 'catalog.php';
    header("Location: login.php");
    exit;
}

$product_id = $_POST['product_id'] ?? null;
$size = $_POST['size'] ?? null;

if (!$product_id || !$size) {
    $_SESSION['cart_error'] = 'Пожалуйста, выберите размер';
    header("Location: " . ($_SERVER['HTTP_REFERER'] ?? 'catalog.php'));
    exit;
}

try {
    $db = new Database();
    $connection = $db->getConnection();
    
    // Проверяем существование товара
    $stmt = $connection->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->execute([$product_id]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$product) {
        $_SESSION['cart_error'] = 'Товар не найден';
        header("Location: " . ($_SERVER['HTTP_REFERER'] ?? 'catalog.php'));
        exit;
    }
    
    // Проверяем наличие товара
    if ($product['in_stock_quantity'] <= 0) {
        $_SESSION['cart_error'] = 'Товар временно отсутствует в наличии';
        header("Location: " . ($_SERVER['HTTP_REFERER'] ?? 'catalog.php'));
        exit;
    }
    
    // Проверяем, есть ли уже такой товар в корзине
    $stmt = $connection->prepare("SELECT id, quantity FROM cart WHERE user_id = ? AND product_id = ? AND size = ?");
    $stmt->execute([$_SESSION['user_id'], $product_id, $size]);
    $existing_item = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($existing_item) {
        // Увеличиваем количество
        $stmt = $connection->prepare("UPDATE cart SET quantity = quantity + 1 WHERE id = ?");
        $stmt->execute([$existing_item['id']]);
    } else {
        // Добавляем новый товар
        $stmt = $connection->prepare("INSERT INTO cart (user_id, product_id, size, quantity) VALUES (?, ?, ?, 1)");
        $stmt->execute([$_SESSION['user_id'], $product_id, $size]);
    }
    
    $_SESSION['cart_success'] = 'Товар "' . htmlspecialchars($product['name']) . '" размера ' . $size . ' успешно добавлен в корзину!';
    header("Location: " . ($_SERVER['HTTP_REFERER'] ?? 'catalog.php'));
    exit;
    
} catch (Exception $e) {
    $_SESSION['cart_error'] = 'Ошибка при добавлении товара в корзину: ' . $e->getMessage();
    header("Location: " . ($_SERVER['HTTP_REFERER'] ?? 'catalog.php'));
    exit;
}
?>
