<?php
// order_confirmation.php
session_start();
require_once 'includes/database.php';
require_once 'includes/config.php';

// Временно для отладки
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Проверяем, что передан ID заказа
if (!isset($_GET['order_id'])) {
    header("Location: index.php");
    exit;
}

$order_id = (int)$_GET['order_id'];
$user_id = $_SESSION['user_id'];

$db = new Database();
$connection = $db->getConnection();

// Получаем информацию о заказе (ТОЛЬКО СУЩЕСТВУЮЩИЕ ПОЛЯ)
$stmt = $connection->prepare("
    SELECT o.*, 
           u.username, u.email, u.phone, u.address
    FROM orders o
    JOIN users u ON o.user_id = u.id
    WHERE o.id = ? AND o.user_id = ?
");
$stmt->execute([$order_id, $user_id]);
$order = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$order) {
    $_SESSION['error'] = 'Заказ не найден';
    header("Location: profile.php");
    exit;
}

// Получаем товары в заказе (с названием товара из products)
$stmt = $connection->prepare("
    SELECT oi.*, p.name as product_name, p.image_url, p.brand
    FROM order_items oi
    JOIN products p ON oi.product_id = p.id
    WHERE oi.order_id = ?
");
$stmt->execute([$order_id]);
$order_items = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Статусы заказа на русском
$status_ru = [
    'pending' => 'Ожидает обработки',
    'processing' => 'В обработке',
    'shipped' => 'Отправлен',
    'delivered' => 'Доставлен',
    'cancelled' => 'Отменён'
];

// Очищаем сообщение об успехе из сессии
$success_message = $_SESSION['order_success'] ?? null;
unset($_SESSION['order_success']);
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Заказ #<?= $order_id ?> подтверждён - <?= SITE_NAME ?></title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #000;
            --secondary-color: #111;
            --success-color: #28a745;
            --border-color: #ddd;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #fff 0%, #fafafa 100%);
            min-height: 100vh;
        }
        
        /* Header Styles */
        header {
            background: white;
            box-shadow: 0 2px 20px rgba(0,0,0,0.1);
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            padding: 0.5rem 0;
            width: 100%;
        }
        
        .header-full-width {
            max-width: 100%;
            margin: 0;
            padding: 0 2rem;
        }
        
        .header-container {
            display: flex;
            align-items: center;
            justify-content: space-between;
            width: 100%;
            gap: 3rem;
        }
        
        .logo h1 {
            color: var(--primary-color);
            font-size: 1.8rem;
            font-weight: bold;
        }
        
        nav ul {
            display: flex;
            list-style: none;
            gap: 2rem;
        }
        
        nav a {
            text-decoration: none;
            color: #333;
            font-weight: 500;
            transition: color 0.3s;
        }
        
        nav a:hover {
            color: var(--primary-color);
        }
        
        .header-actions {
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        
        .cart-link {
            display: flex;
            align-items: center;
            text-decoration: none;
            color: #333;
            position: relative;
        }
        
        .cart-icon {
            width: 24px;
            height: 24px;
        }
        
        .mobile-menu-btn {
            display: none;
        }
        
        /* Confirmation Page Styles */
        .confirmation-container {
            max-width: 1000px;
            margin: 100px auto 3rem;
            padding: 0 2rem;
        }
        
        .success-header {
            text-align: center;
            margin-bottom: 3rem;
            animation: slideDown 0.5s ease;
        }
        
        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .success-icon {
            width: 80px;
            height: 80px;
            background: var(--success-color);
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1.5rem;
            font-size: 3rem;
            animation: scaleIn 0.5s ease 0.3s both;
        }
        
        @keyframes scaleIn {
            from {
                transform: scale(0);
            }
            to {
                transform: scale(1);
            }
        }
        
        .success-header h1 {
            font-size: 2rem;
            color: var(--primary-color);
            margin-bottom: 0.5rem;
        }
        
        .order-number {
            font-size: 1.3rem;
            color: var(--success-color);
            font-weight: 600;
            margin-top: 0.5rem;
        }
        
        .order-card {
            background: white;
            border-radius: 20px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
            overflow: hidden;
            margin-bottom: 2rem;
        }
        
        .order-header {
            background: var(--primary-color);
            color: white;
            padding: 1.5rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 1rem;
        }
        
        .order-status {
            background: rgba(255,255,255,0.2);
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-size: 0.9rem;
        }
        
        .order-date {
            font-size: 0.9rem;
            opacity: 0.9;
        }
        
        .order-body {
            padding: 2rem;
        }
        
        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 2rem;
            margin-bottom: 2rem;
            padding-bottom: 2rem;
            border-bottom: 2px solid var(--border-color);
        }
        
        .info-section h3 {
            font-size: 1.1rem;
            margin-bottom: 1rem;
            color: var(--primary-color);
        }
        
        .info-section p {
            margin: 0.5rem 0;
            color: #555;
        }
        
        .info-section i {
            width: 25px;
            color: var(--primary-color);
        }
        
        .items-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .items-table th {
            text-align: left;
            padding: 1rem 0;
            border-bottom: 2px solid var(--border-color);
            color: var(--primary-color);
        }
        
        .items-table td {
            padding: 1rem 0;
            border-bottom: 1px solid var(--border-color);
            vertical-align: middle;
        }
        
        .product-cell {
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        
        .product-image {
            width: 60px;
            height: 60px;
            object-fit: cover;
            border-radius: 8px;
        }
        
        .product-name {
            font-weight: 600;
        }
        
        .product-brand {
            font-size: 0.8rem;
            color: #666;
        }
        
        .total-row {
            background: #f8f9fa;
            font-weight: bold;
        }
        
        .total-row td {
            padding: 1rem 0;
            border-bottom: none;
        }
        
        .grand-total {
            font-size: 1.2rem;
            color: var(--primary-color);
        }
        
        .action-buttons {
            display: flex;
            gap: 1rem;
            justify-content: center;
            margin-top: 2rem;
        }
        
        .btn {
            display: inline-block;
            padding: 1rem 2rem;
            text-decoration: none;
            border-radius: 12px;
            font-weight: 600;
            transition: all 0.3s ease;
            cursor: pointer;
            border: none;
            font-size: 1rem;
        }
        
        .btn-primary {
            background: var(--primary-color);
            color: white;
            border: 2px solid var(--primary-color);
        }
        
        .btn-primary:hover {
            background: white;
            color: var(--primary-color);
            transform: translateY(-2px);
        }
        
        .btn-secondary {
            background: white;
            color: var(--primary-color);
            border: 2px solid var(--primary-color);
        }
        
        .btn-secondary:hover {
            background: var(--primary-color);
            color: white;
            transform: translateY(-2px);
        }
        
        @media (max-width: 768px) {
            .order-header {
                flex-direction: column;
                text-align: center;
            }
            
            .info-grid {
                grid-template-columns: 1fr;
                gap: 1rem;
            }
            
            .items-table {
                font-size: 0.9rem;
            }
            
            .product-cell {
                flex-direction: column;
                text-align: center;
            }
            
            .action-buttons {
                flex-direction: column;
            }
            
            .mobile-menu-btn {
                display: block;
            }
            
            nav {
                display: none;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="header-full-width">
            <div class="header-container">
                <button class="mobile-menu-btn">
                    <i class="fas fa-bars"></i>
                </button>
                
                <div class="logo">
                    <h1><?= SITE_NAME ?></h1>
                </div>
                
                <nav>
                    <ul>
                        <li><a href="index.php">Главная</a></li>
                        <li><a href="catalog.php">Каталог</a></li>
                        <li><a href="profile.php">Личный кабинет</a></li>
                        <li><a href="logout.php">Выйти</a></li>
                    </ul>
                </nav>
                
                <div class="header-actions">
                    <a href="cart.php" class="cart-link">
                        <i class="fas fa-shopping-cart"></i>
                    </a>
                </div>
            </div>
        </div>
    </header>

    <main class="confirmation-container">
        <div class="success-header">
            <div class="success-icon">
                <i class="fas fa-check"></i>
            </div>
            <h1>Заказ успешно оформлен!</h1>
            <?php if ($success_message): ?>
                <p style="color: var(--success-color); margin-top: 0.5rem;"><?= htmlspecialchars($success_message) ?></p>
            <?php endif; ?>
            <div class="order-number">Номер заказа: #<?= $order_id ?></div>
        </div>
        
        <div class="order-card">
            <div class="order-header">
                <div>
                    <strong>Заказ #<?= $order_id ?></strong>
                    <div class="order-date">от <?= date('d.m.Y H:i', strtotime($order['created_at'])) ?></div>
                </div>
                <div class="order-status">
                    <i class="fas fa-clock"></i> 
                    <?= $status_ru[$order['status']] ?? $order['status'] ?>
                </div>
            </div>
            
            <div class="order-body">
                <div class="info-grid">
                    <div class="info-section">
                        <h3><i class="fas fa-user"></i> Получатель</h3>
                        <p><strong><?= htmlspecialchars($order['username']) ?></strong></p>
                        <p><i class="fas fa-envelope"></i> <?= htmlspecialchars($order['email']) ?></p>
                        <?php if (!empty($order['phone'])): ?>
                            <p><i class="fas fa-phone"></i> <?= htmlspecialchars($order['phone']) ?></p>
                        <?php endif; ?>
                    </div>
                    
                    <div class="info-section">
                        <h3><i class="fas fa-map-marker-alt"></i> Адрес доставки</h3>
                        <p><?= !empty($order['address']) ? htmlspecialchars($order['address']) : 'Не указан' ?></p>
                        <p><small>Доставка осуществляется в течение 3-5 рабочих дней</small></p>
                    </div>
                    
                    <div class="info-section">
                        <h3><i class="fas fa-credit-card"></i> Оплата</h3>
                        <p><i class="fas fa-money-bill-wave"></i> Наличными при получении</p>
                        <p><small>Вы можете оплатить заказ при получении</small></p>
                    </div>
                </div>
                
                <h3 style="margin-bottom: 1rem;">Состав заказа</h3>
                <table class="items-table">
                    <thead>
                        <tr>
                            <th>Товар</th>
                            <th>Кол-во</th>
                            <th>Цена</th>
                            <th>Сумма</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($order_items as $item): ?>
                            <tr>
                                <td>
                                    <div class="product-cell">
                                        <img src="<?= htmlspecialchars($item['image_url'] ?? 'images/placeholder.jpg') ?>" 
                                             alt="<?= htmlspecialchars($item['product_name']) ?>" 
                                             class="product-image"
                                             onerror="this.src='images/placeholder.jpg'">
                                        <div>
                                            <div class="product-name"><?= htmlspecialchars($item['product_name']) ?></div>
                                            <?php if (!empty($item['brand'])): ?>
                                                <div class="product-brand"><?= htmlspecialchars($item['brand']) ?></div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </td>
                                <td><?= $item['quantity'] ?> шт.</td>
                                <td><?= number_format($item['price'], 0, ',', ' ') ?> ₽</td>
                                <td><?= number_format($item['price'] * $item['quantity'], 0, ',', ' ') ?> ₽</td>
                            </tr>
                        <?php endforeach; ?>
                        <tr class="total-row">
                            <td colspan="3" style="text-align: right;"><strong>Итого:</strong></td>
                            <td class="grand-total"><strong><?= number_format($order['total_amount'], 0, ',', ' ') ?> ₽</strong></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        
        <div class="action-buttons">
            <a href="catalog.php" class="btn btn-secondary">
                <i class="fas fa-shopping-bag"></i> Продолжить покупки
            </a>
            <a href="profile.php" class="btn btn-primary">
                <i class="fas fa-list"></i> Мои заказы
            </a>
        </div>
    </main>

    <script>
        // Mobile menu toggle
        document.querySelector('.mobile-menu-btn').addEventListener('click', function() {
            const nav = document.querySelector('nav');
            nav.style.display = nav.style.display === 'block' ? 'none' : 'block';
        });
    </script>
</body>
</html>