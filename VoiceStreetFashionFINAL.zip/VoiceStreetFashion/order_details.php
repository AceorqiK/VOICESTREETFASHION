<?php
session_start();
require_once 'includes/database.php';
require_once 'includes/config.php';

// Класс безопасности
class Security {
    public static function escape($data) {
        if (is_array($data)) {
            return array_map([self::class, 'escape'], $data);
        }
        return htmlspecialchars($data, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    }
    
    public static function validateInput($data, $type = 'string') {
        if ($data === null) return '';
        
        $data = trim($data);
        $data = stripslashes($data);
        
        switch ($type) {
            case 'email':
                $data = filter_var($data, FILTER_SANITIZE_EMAIL);
                return filter_var($data, FILTER_VALIDATE_EMAIL) ? $data : false;
            case 'int':
                return filter_var($data, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
            case 'text':
                return self::escape($data);
            default:
                return self::escape($data);
        }
    }
}

// ЗАЩИТА: Проверка авторизации
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// ЗАЩИТА: Проверка наличия ID заказа
if (!isset($_GET['id'])) {
    header("Location: profile.php");
    exit;
}

$db = new Database();
$connection = $db->getConnection();

// ЗАЩИТА: Валидация ID заказа
$order_id = Security::validateInput($_GET['id'], 'int');
if (!$order_id) {
    header("Location: profile.php");
    exit;
}

// ЗАЩИТА: Получение информации о заказе с подготовленным запросом
$stmt = $connection->prepare("
    SELECT o.*, u.username, u.email, u.phone, u.address 
    FROM orders o 
    JOIN users u ON o.user_id = u.id 
    WHERE o.id = ? AND o.user_id = ?
");
$stmt->execute([$order_id, $_SESSION['user_id']]);
$order = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$order) {
    header("Location: profile.php");
    exit;
}

// ЗАЩИТА: Получение товаров в заказе с подготовленным запросом
$stmt = $connection->prepare("
    SELECT oi.*, p.name, p.price, p.image_url 
    FROM order_items oi 
    JOIN products p ON oi.product_id = p.id 
    WHERE oi.order_id = ?
");
$stmt->execute([$order_id]);
$order_items = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Функция для получения количества товаров в корзине
function getCartCount($connection, $userId) {
    try {
        $checkTable = $connection->query("SHOW TABLES LIKE 'cart'");
        if ($checkTable->rowCount() == 0) {
            return 0;
        }
        
        $stmt = $connection->prepare("
            SELECT COALESCE(SUM(quantity), 0) as total_items 
            FROM cart 
            WHERE user_id = ?
        ");
        $stmt->execute([(int)$userId]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return (int)($result['total_items'] ?? 0);
    } catch (Exception $e) {
        return 0;
    }
}

$cartCount = getCartCount($connection, $_SESSION['user_id']);

// ЗАЩИТА: Отмена заказа (если статус позволяет)
$success = $error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cancel_order'])) {
    if ($order['status'] === 'pending' || $order['status'] === 'processing') {
        $stmt = $connection->prepare("UPDATE orders SET status = 'cancelled' WHERE id = ? AND user_id = ?");
        if ($stmt->execute([$order_id, $_SESSION['user_id']])) {
            $order['status'] = 'cancelled';
            $success = "Заказ успешно отменен";
        } else {
            $error = "Ошибка при отмене заказа";
        }
    } else {
        $error = "Невозможно отменить заказ с текущим статусом";
    }
}

// Безопасные значения для статусов
$status_labels = [
    'pending' => 'Ожидает',
    'processing' => 'В обработке',
    'shipped' => 'Отправлен',
    'delivered' => 'Доставлен',
    'cancelled' => 'Отменен'
];

$status_class = [
    'pending' => 'status-pending',
    'processing' => 'status-processing',
    'shipped' => 'status-shipped',
    'delivered' => 'status-delivered',
    'cancelled' => 'status-cancelled'
];
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Детали заказа #<?= Security::escape($order_id) ?> - <?= Security::escape(SITE_NAME) ?></title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #000;
            --secondary-color: #111;
            --accent-color: #555;
            --light-color: #eee;
            --text-color: #333;
            --success-color: #28a745;
            --border-color: #ddd;
            --admin-color: #dc3545;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: var(--light-color);
            color: var(--text-color);
            min-height: 100vh;
        }
        
        /* Header Styles */
        header {
            background: white;
            box-shadow: 0 2px 20px rgba(0,0,0,0.1);
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            padding: 0.5rem 0;
            width: 100%;
        }
        
        .header-full-width {
            max-width: 100%;
            margin: 0;
            padding: 0 2rem;
        }
        
        .header-container {
            display: flex;
            align-items: center;
            justify-content: space-between;
            width: 100%;
            gap: 3rem;
        }
        
        .logo {
            display: flex;
            flex-direction: column;
            align-items: flex-start;
            min-width: 200px;
        }
        
        .logo h1 {
            color: var(--primary-color) !important;
            font-size: 1.8rem;
            font-weight: bold;
            margin: 0;
            line-height: 1;
            white-space: nowrap;
        }
        
        nav {
            flex: 1;
            display: flex;
            justify-content: center;
            margin: 0 2rem;
        }
        
        nav ul {
            display: flex;
            list-style: none;
            margin: 0;
            padding: 0;
            gap: 2rem;
        }
        
        nav a {
            text-decoration: none;
            color: var(--text-color);
            font-weight: 500;
            font-size: 1rem;
            transition: color 0.3s;
            position: relative;
            white-space: nowrap;
            padding: 0.5rem 0;
        }
        
        nav a:hover {
            color: var(--primary-color);
        }
        
        nav a::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 0;
            height: 2px;
            background: var(--primary-color);
            transition: width 0.3s;
        }
        
        nav a:hover::after {
            width: 100%;
        }
        
        .admin-link {
            color: var(--admin-color) !important;
            font-weight: 600 !important;
        }
        
        .header-actions {
            display: flex;
            align-items: center;
            gap: 1rem;
            min-width: 300px;
            justify-content: flex-end;
        }
        
        .search-box {
            display: flex;
            background: var(--light-color);
            border-radius: 25px;
            padding: 0.4rem;
            border: 2px solid transparent;
            transition: border-color 0.3s;
            min-width: 250px;
            margin-right: 1rem;
        }
        
        .search-box:focus-within {
            border-color: var(--primary-color);
        }
        
        .search-box input {
            border: none;
            background: none;
            outline: none;
            padding: 0 1rem;
            width: 100%;
            font-size: 0.9rem;
        }
        
        .search-box button {
            background: var(--primary-color);
            color: white;
            border: none;
            padding: 0.4rem 1rem;
            border-radius: 20px;
            cursor: pointer;
            font-size: 0.9rem;
            transition: background 0.3s;
            white-space: nowrap;
        }
        
        .search-box button:hover {
            background: var(--secondary-color);
        }
        
        .cart-link {
            display: flex;
            align-items: center;
            text-decoration: none;
            color: var(--text-color);
            transition: color 0.3s;
            padding: 0.5rem;
            position: relative;
            background: none !important;
        }
        
        .cart-link:hover {
            color: var(--primary-color);
        }
        
        .cart-icon {
            width: 24px;
            height: 24px;
        }
        
        .cart-count {
            background: var(--accent-color);
            color: white;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.75rem;
            position: absolute;
            top: -5px;
            right: -5px;
            font-weight: bold;
            border: 2px solid white;
        }

        /* Mobile menu button */
        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            font-size: 1.5rem;
            color: var(--text-color);
            cursor: pointer;
        }

        /* Main content */
        main {
            margin-top: 80px;
            padding: 2rem 0;
        }

        /* Order Details Styles */
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }
        
        .order-details {
            max-width: 900px;
            margin: 0 auto;
        }
        
        .order-section {
            background: white;
            border-radius: 15px;
            padding: 2rem;
            margin-bottom: 1.5rem;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }
        
        .order-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            padding-bottom: 1.5rem;
            border-bottom: 2px solid #f0f0f0;
        }
        
        .order-header h1 {
            font-size: 2rem;
            color: var(--primary-color);
            margin-bottom: 0.5rem;
        }
        
        .status-badge {
            padding: 0.6rem 1.2rem;
            border-radius: 25px;
            font-weight: bold;
            text-transform: uppercase;
            font-size: 0.85rem;
            letter-spacing: 0.5px;
        }
        
        .status-pending { background: #fff3cd; color: #856404; }
        .status-processing { background: #cce7ff; color: #004085; }
        .status-shipped { background: #d4edda; color: #155724; }
        .status-delivered { background: #d1ecf1; color: #0c5460; }
        .status-cancelled { background: #f8d7da; color: #721c24; }
        
        .order-item {
            display: flex;
            align-items: center;
            padding: 1.5rem;
            border: 2px solid #f0f0f0;
            border-radius: 12px;
            margin-bottom: 1rem;
            transition: all 0.3s ease;
            background: white;
        }
        
        .order-item:hover {
            border-color: var(--primary-color);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            transform: translateX(5px);
        }
        
        .item-image {
            width: 100px;
            height: 100px;
            object-fit: cover;
            border-radius: 10px;
            margin-right: 1.5rem;
            background: #f8f9fa;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #6c757d;
            font-size: 0.8rem;
            text-align: center;
            border: 2px solid #eee;
            overflow: hidden;
        }
        
        .item-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .item-details {
            flex: 1;
        }
        
        .item-details h4 {
            font-size: 1.1rem;
            color: var(--primary-color);
            margin-bottom: 0.5rem;
        }
        
        .item-details p {
            color: #666;
            margin: 0.25rem 0;
            font-size: 0.9rem;
        }
        
        .item-price {
            font-weight: bold;
            color: var(--primary-color);
            font-size: 1.2rem;
            white-space: nowrap;
        }
        
        .order-summary {
            background: #f8f9fa;
            border-radius: 12px;
            padding: 1.5rem;
            margin-top: 1.5rem;
        }
        
        .order-summary h3 {
            color: var(--primary-color);
            margin-bottom: 1rem;
            padding-bottom: 0.5rem;
            border-bottom: 2px solid #dee2e6;
        }
        
        .summary-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 0.5rem;
            padding: 0.5rem 0;
        }
        
        .summary-total {
            font-size: 1.3rem;
            font-weight: bold;
            border-top: 2px solid #dee2e6;
            padding-top: 1rem;
            margin-top: 1rem;
            color: var(--primary-color);
        }
        
        .action-buttons {
            display: flex;
            gap: 1rem;
            margin-top: 2rem;
            padding-top: 1.5rem;
            border-top: 2px solid #f0f0f0;
            flex-wrap: wrap;
        }
        
        .btn-secondary {
            background: #6c757d;
            color: white;
            padding: 0.75rem 1.5rem;
            text-decoration: none;
            border-radius: 8px;
            border: none;
            cursor: pointer;
            font-size: 1rem;
            font-weight: 500;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .btn-secondary:hover {
            background: #5a6268;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        
        .btn-danger {
            background: #dc3545;
            color: white;
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 1rem;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        
        .btn-danger:hover {
            background: #c82333;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(220,53,69,0.3);
        }
        
        .delivery-info {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 2rem;
            margin-top: 1rem;
        }
        
        .info-block {
            background: #f8f9fa;
            padding: 1.5rem;
            border-radius: 10px;
        }
        
        .info-block h4 {
            margin-top: 0;
            color: var(--primary-color);
            border-bottom: 2px solid #dee2e6;
            padding-bottom: 0.5rem;
            margin-bottom: 1rem;
        }
        
        .history-item {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 1rem;
            background: #f8f9fa;
            border-radius: 10px;
            margin-bottom: 1rem;
            border-left: 4px solid var(--primary-color);
        }
        
        .success-message {
            background: #d4edda;
            color: #155724;
            padding: 1rem 1.5rem;
            border-radius: 10px;
            border: 2px solid #c3e6cb;
            margin-bottom: 1.5rem;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .error-message {
            background: #f8d7da;
            color: #721c24;
            padding: 1rem 1.5rem;
            border-radius: 10px;
            border: 2px solid #f5c6cb;
            margin-bottom: 1.5rem;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        /* Footer Styles */
        footer {
            background: var(--primary-color);
            color: white;
            padding: 3rem 0;
            margin-top: 4rem;
        }
        
        .footer-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 3rem;
            margin-bottom: 2rem;
        }
        
        .footer-column h3 {
            color: var(--light-color);
            margin-bottom: 1rem;
            font-size: 1.5rem;
        }
        
        .footer-column h4 {
            color: var(--light-color);
            margin-bottom: 1rem;
        }
        
        .footer-links {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }
        
        .footer-links a {
            color: white;
            opacity: 0.8;
            text-decoration: none;
            transition: opacity 0.3s;
        }
        
        .footer-links a:hover {
            opacity: 1;
        }
        
        .footer-bottom {
            text-align: center;
            padding-top: 2rem;
            border-top: 1px solid rgba(255,255,255,0.2);
        }

        /* Responsive */
        @media (max-width: 768px) {
            .header-container {
                flex-wrap: wrap;
                gap: 1rem;
            }
            
            .mobile-menu-btn {
                display: block;
            }
            
            nav {
                order: 3;
                display: none;
                width: 100%;
                margin: 0;
            }
            
            nav.active {
                display: block;
            }
            
            nav ul {
                flex-direction: column;
                gap: 0.5rem;
                padding: 1rem 0;
            }
            
            .header-actions {
                min-width: auto;
                gap: 0.5rem;
            }
            
            .search-box {
                min-width: 150px;
            }
            
            .logo {
                min-width: auto;
            }
            
            .logo h1 {
                font-size: 1.5rem;
            }
            
            .delivery-info {
                grid-template-columns: 1fr;
            }
            
            .order-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 1rem;
            }
            
            .order-item {
                flex-direction: column;
                text-align: center;
            }
            
            .item-image {
                margin-right: 0;
                margin-bottom: 1rem;
            }
            
            .item-price {
                margin-top: 1rem;
            }
            
            .action-buttons {
                flex-direction: column;
            }
            
            .order-section {
                padding: 1.5rem;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header>
        <div class="header-full-width">
            <div class="header-container">
                <button class="mobile-menu-btn">
                    <i class="fas fa-bars"></i>
                </button>
                
                <div class="logo">
                    <h1><?= Security::escape(SITE_NAME) ?></h1>
                </div>
                
                <nav id="main-nav">
                    <ul>
                        <li><a href="index.php">Главная</a></li>
                        <li><a href="catalog.php">Обувь</a></li>
                        <li><a href="feedback.php">Обратная связь</a></li>
                        <?php if(isset($_SESSION['user_id'])): ?>
                            <?php if(isset($_SESSION['is_admin']) && $_SESSION['is_admin']): ?>
                                <li><a href="admin.php" class="admin-link">Админ панель</a></li>
                            <?php endif; ?>
                            <li><a href="profile.php" style="font-weight: 700;">Личный кабинет</a></li>
                            <li><a href="logout.php">Выйти</a></li>
                        <?php else: ?>
                            <li><a href="login.php">Войти</a></li>
                            <li><a href="register.php">Регистрация</a></li>
                        <?php endif; ?>
                    </ul>
                </nav>
                
                <div class="header-actions">
                    <div class="search-box">
                        <input type="text" placeholder="Поиск товаров...">
                        <button>
                            <i class="fas fa-search"></i>
                        </button>
                    </div>
                    
                    <a href="cart.php" class="cart-link">
                        <svg class="cart-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path>
                            <line x1="3" y1="6" x2="21" y2="6"></line>
                            <path d="M16 10a4 4 0 0 1-8 0"></path>
                        </svg>
                        <span class="cart-count"><?= $cartCount ?></span>
                    </a>
                </div>
            </div>
        </div>
    </header>
    
    <main>
        <div class="container">
            <div class="order-details">
                <!-- Основная информация о заказе -->
                <div class="order-section">
                    <div class="order-header">
                        <div>
                            <h1>Заказ #<?= Security::escape($order_id) ?></h1>
                            <p style="color: #666; font-size: 1.1rem;">
                                <i class="far fa-calendar-alt"></i>
                                Дата оформления: <?= Security::escape(date('d.m.Y H:i', strtotime($order['created_at'] ?? $order['order_date'] ?? 'now'))) ?>
                            </p>
                        </div>
                        <div class="status-badge <?= $status_class[$order['status']] ?? 'status-pending' ?>">
                            <?= Security::escape($status_labels[$order['status']] ?? $order['status']) ?>
                        </div>
                    </div>

                    <?php if (!empty($success)): ?>
                        <div class="success-message">
                            <i class="fas fa-check-circle"></i>
                            <?= Security::escape($success) ?>
                        </div>
                    <?php endif; ?>
                    
                    <?php if (!empty($error)): ?>
                        <div class="error-message">
                            <i class="fas fa-exclamation-circle"></i>
                            <?= Security::escape($error) ?>
                        </div>
                    <?php endif; ?>

                    <!-- Информация о доставке -->
                    <h3 style="color: var(--primary-color); margin-bottom: 1rem;">Информация о доставке</h3>
                    <div class="delivery-info">
                        <div class="info-block">
                            <h4><i class="fas fa-user"></i> Контактная информация</h4>
                            <p><strong>Имя:</strong> <?= Security::escape($order['username']) ?></p>
                            <p><strong>Email:</strong> <?= Security::escape($order['email']) ?></p>
                            <p><strong>Телефон:</strong> <?= Security::escape($order['phone'] ?: 'Не указан') ?></p>
                        </div>
                        <div class="info-block">
                            <h4><i class="fas fa-map-marker-alt"></i> Адрес доставки</h4>
                            <p><?= nl2br(Security::escape($order['address'] ?: 'Адрес не указан')) ?></p>
                        </div>
                    </div>

                    <!-- Товары в заказе -->
                    <h3 style="color: var(--primary-color); margin: 2rem 0 1rem;">Состав заказа</h3>
                    <div class="order-items">
                        <?php foreach ($order_items as $item): ?>
                            <div class="order-item">
                                <div class="item-image">
                                    <?php if (!empty($item['image_url'])): ?>
                                        <img src="<?= Security::escape($item['image_url']) ?>" alt="<?= Security::escape($item['name']) ?>">
                                    <?php else: ?>
                                        <div style="padding: 10px; text-align: center;">
                                            <i class="fas fa-image" style="font-size: 2rem; margin-bottom: 5px;"></i>
                                            <br>Нет фото
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="item-details">
                                    <h4><?= Security::escape($item['name']) ?></h4>
                                    <p><i class="fas fa-box"></i> Количество: <?= Security::escape($item['quantity']) ?> шт.</p>
                                    <?php if (!empty($item['size'])): ?>
                                        <p><i class="fas fa-ruler"></i> Размер: <?= Security::escape($item['size']) ?></p>
                                    <?php endif; ?>
                                    <p><i class="fas fa-tag"></i> Цена за шт.: <?= Security::escape(number_format($item['price'], 0, ',', ' ')) ?> ₽</p>
                                </div>
                                <div class="item-price">
                                    <?= Security::escape(number_format($item['price'] * $item['quantity'], 0, ',', ' ')) ?> ₽
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <!-- Итоговая информация -->
                    <div class="order-summary">
                        <h3>Итоговая информация</h3>
                        <div class="summary-row">
                            <span>Стоимость товаров:</span>
                            <span><?= Security::escape(number_format($order['total_amount'], 0, ',', ' ')) ?> ₽</span>
                        </div>
                        <div class="summary-row">
                            <span>Доставка:</span>
                            <span>Бесплатно</span>
                        </div>
                        <div class="summary-row summary-total">
                            <span>Итого к оплате:</span>
                            <span><?= Security::escape(number_format($order['total_amount'], 0, ',', ' ')) ?> ₽</span>
                        </div>
                    </div>

                    <!-- История заказа -->
                    <div style="margin-top: 2rem;">
                        <h3 style="color: var(--primary-color); margin-bottom: 1rem;">История заказа</h3>
                        <div class="history-item">
                            <i class="fas fa-check-circle" style="color: var(--success-color); font-size: 1.5rem;"></i>
                            <div>
                                <strong>Заказ создан</strong>
                                <p style="margin: 0.25rem 0 0 0; color: #666;">
                                    <?= Security::escape(date('d.m.Y H:i', strtotime($order['created_at'] ?? $order['order_date'] ?? 'now'))) ?>
                                </p>
                            </div>
                        </div>
                        
                        <?php if ($order['status'] === 'cancelled'): ?>
                            <div class="history-item" style="border-left-color: #dc3545;">
                                <i class="fas fa-times-circle" style="color: #dc3545; font-size: 1.5rem;"></i>
                                <div>
                                    <strong>Заказ отменен</strong>
                                    <p style="margin: 0.25rem 0 0 0; color: #666;">
                                        <?= Security::escape(date('d.m.Y H:i')) ?>
                                    </p>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>

                    <!-- Кнопки действий -->
                    <div class="action-buttons">
                        <a href="profile.php" class="btn-secondary">
                            <i class="fas fa-arrow-left"></i>
                            Назад к заказам
                        </a>
                        
                        <?php if ($order['status'] === 'pending' || $order['status'] === 'processing'): ?>
                            <form method="POST" action="" style="margin: 0;" onsubmit="return confirm('Вы уверены, что хотите отменить заказ? Это действие нельзя отменить.');">
                                <button type="submit" name="cancel_order" class="btn-danger">
                                    <i class="fas fa-times"></i>
                                    Отменить заказ
                                </button>
                            </form>
                        <?php endif; ?>
                        
                        <?php if ($order['status'] === 'delivered'): ?>
                            <button class="btn-secondary" onclick="window.print()">
                                <i class="fas fa-print"></i>
                                Распечатать чек
                            </button>
                        <?php endif; ?>
                        
                        <a href="catalog.php" class="btn-secondary">
                            <i class="fas fa-shopping-cart"></i>
                            Продолжить покупки
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <footer>
        <div class="container">
            <div class="footer-grid">
                <div class="footer-column">
                    <h3><?= Security::escape(SITE_NAME) ?></h3>
                    <p style="line-height: 1.6; opacity: 0.9;">Ваш голос в мире уличной моды. Премиальная обувь от ведущих мировых брендов с доставкой по всей России.</p>
                </div>
                
                <div class="footer-column">
                    <h4>Контакты</h4>
                    <div class="footer-links">
                        <div>+7 (999) 123-45-67</div>
                        <div>info@voicestreet.ru</div>
                        <div>Москва, ул. Примерная, 123</div>
                    </div>
                </div>
                
                <div class="footer-column">
                    <h4>Навигация</h4>
                    <div class="footer-links">
                        <a href="catalog.php">Каталог обуви</a>
                        <a href="feedback.php">Обратная связь</a>
                        <a href="profile.php">Личный кабинет</a>
                    </div>
                </div>
                
                <div class="footer-column">
                    <h4>Время работы</h4>
                    <div style="opacity: 0.9;">
                        <div>Пн-Пт: 9:00 - 21:00</div>
                        <div>Сб-Вс: 10:00 - 20:00</div>
                    </div>
                </div>
            </div>
            
            <div class="footer-bottom">
                <p>&copy; 2026 <?= Security::escape(SITE_NAME) ?>. Все права защищены.</p>
            </div>
        </div>
    </footer>

    <script>
        // Mobile menu toggle
        document.querySelector('.mobile-menu-btn').addEventListener('click', function() {
            document.getElementById('main-nav').classList.toggle('active');
        });

        document.addEventListener('click', function(event) {
            const nav = document.getElementById('main-nav');
            const menuBtn = document.querySelector('.mobile-menu-btn');
            if (!nav.contains(event.target) && !menuBtn.contains(event.target)) {
                nav.classList.remove('active');
            }
        });
    </script>
</body>
</html>