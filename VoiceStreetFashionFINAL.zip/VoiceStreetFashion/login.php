<?php
session_start();
require_once 'includes/database.php';
require_once 'includes/config.php';

// Класс безопасности
class Security {
    public static function escape($data) {
        if (is_array($data)) {
            return array_map([self::class, 'escape'], $data);
        }
        return htmlspecialchars($data, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    }
    
    public static function validateInput($data, $type = 'string') {
        $data = trim($data);
        $data = stripslashes($data);
        
        switch ($type) {
            case 'email':
                $data = filter_var($data, FILTER_SANITIZE_EMAIL);
                return filter_var($data, FILTER_VALIDATE_EMAIL) ? $data : false;
            case 'username':
                // Разрешаем только буквы, цифры и подчеркивание
                $data = preg_replace('/[^a-zA-Z0-9_]/', '', $data);
                return (strlen($data) >= 3 && strlen($data) <= 50) ? $data : false;
            case 'int':
                return filter_var($data, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
            default:
                return self::escape($data);
        }
    }
}

// Проверяем, является ли пользователь администратором
$is_admin = false;
if(isset($_SESSION['user_id'])) {
    $db = new Database();
    $connection = $db->getConnection();
    
    // ЗАЩИТА ОТ SQL-ИНЪЕКЦИЙ: используем подготовленные выражения
    $user_id = Security::validateInput($_SESSION['user_id'], 'int');
    if ($user_id) {
        $stmt = $connection->prepare("SELECT role FROM users WHERE id = ?");
        $stmt->execute([$user_id]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($user) {
            $is_admin = ($user['role'] === 'admin');
            $_SESSION['is_admin'] = $is_admin;  //сохранение роли на сервере
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $db = new Database();
    $connection = $db->getConnection();
    
    // ЗАЩИТА ОТ XSS: валидация и очистка входных данных
    $username = Security::validateInput($_POST['username'] ?? '', 'username');
    $password = $_POST['password'] ?? '';
    
    $errors = [];
    
    if (empty($username) || empty($password)) {
        $errors[] = "Заполните все поля";
    }
    
    // Дополнительная валидация пароля
    if (strlen($password) > 100) {
        $errors[] = "Слишком длинный пароль";  //проверка на пустоту
    }
    
    if (empty($errors)) {
        // ЗАЩИТА ОТ SQL-ИНЪЕКЦИЙ: подготовленные выражения для логина
        $stmt = $connection->prepare("SELECT id, username, email, password, role FROM users WHERE username = ? OR email = ?");
        $stmt->execute([$username, $username]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($user && password_verify($password, $user['password'])) {
            // Успешный вход
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = Security::escape($user['username']);
            $_SESSION['email'] = Security::escape($user['email']);
            $_SESSION['is_admin'] = ($user['role'] === 'admin');
            
            // ЗАЩИТА ОТ XSS: экранируем вывод
            $_SESSION['success'] = "Добро пожаловать, " . Security::escape($user['username']) . "!";
            
            // Перенаправляем в зависимости от роли
            if ($_SESSION['is_admin']) {
                header("Location: admin.php");
            } else {
                header("Location: profile.php");
            }
            exit;
        } else {
            // Унифицированное сообщение об ошибке для безопасности
            $errors[] = "Неверное имя пользователя или пароль";
        }
    }
}

// Безопасное получение значения для формы
$username_value = isset($_POST['username']) ? Security::escape($_POST['username']) : '';
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- ЗАЩИТА ОТ XSS: экранируем вывод констант -->
    <title>Вход - <?= Security::escape(SITE_NAME) ?></title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #000;
            --secondary-color: #111;
            --accent-color: #555;
            --light-color: #eee;
            --text-color: #333;
            --success-color: #28a745;
            --border-color: #ddd;
            --admin-color: #dc3545;
        }
        
        /* Header Styles - Full Width */
        header {
            background: white;
            box-shadow: 0 2px 20px rgba(0,0,0,0.1);
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            padding: 0.5rem 0;
            width: 100%;
        }
        
        .header-full-width {
            max-width: 100%;
            margin: 0;
            padding: 0 2rem;
        }
        
        .header-container {
            display: flex;
            align-items: center;
            justify-content: space-between;
            width: 100%;
            gap: 3rem;
        }
        
        .logo {
            display: flex;
            flex-direction: column;
            align-items: flex-start;
            min-width: 200px;
        }
        
        .logo h1 {
            color: var(--primary-color) !important;
            font-size: 1.8rem;
            font-weight: bold;
            margin: 0;
            line-height: 1;
            white-space: nowrap;
        }
        
        .logo span {
            color: var(--secondary-color);
            font-size: 0.8rem;
            margin-top: 2px;
        }
        
        nav {
            flex: 1;
            display: flex;
            justify-content: center;
            margin: 0 2rem;
        }
        
        nav ul {
            display: flex;
            list-style: none;
            margin: 0;
            padding: 0;
            gap: 2rem;
        }
        
        nav a {
            text-decoration: none;
            color: var(--text-color);
            font-weight: 500;
            font-size: 1rem;
            transition: color 0.3s;
            position: relative;
            white-space: nowrap;
            padding: 0.5rem 0;
        }
        
        nav a:hover {
            color: var(--primary-color);
        }
        
        nav a::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 0;
            height: 2px;
            background: var(--primary-color);
            transition: width 0.3s;
        }
        
        nav a:hover::after {
            width: 100%;
        }
        
        .admin-link {
            color: var(--admin-color) !important;
            font-weight: 600 !important;
        }
        
        .admin-link:hover {
            color: var(--admin-color) !important;
        }
        
        .admin-link::after {
            background: var(--admin-color) !important;
        }
        
        .header-actions {
            display: flex;
            align-items: center;
            gap: 1rem;
            min-width: 300px;
            justify-content: flex-end;
        }
        
        .search-box {
            display: flex;
            background: var(--light-color);
            border-radius: 25px;
            padding: 0.4rem;
            border: 2px solid transparent;
            transition: border-color 0.3s;
            min-width: 250px;
            margin-right: 1rem;
        }
        
        .search-box:focus-within {
            border-color: var(--primary-color);
        }
        
        .search-box input {
            border: none;
            background: none;
            outline: none;
            padding: 0 1rem;
            width: 100%;
            font-size: 0.9rem;
        }
        
        .search-box button {
            background: var(--primary-color);
            color: white;
            border: none;
            padding: 0.4rem 1rem;
            border-radius: 20px;
            cursor: pointer;
            font-size: 0.9rem;
            transition: background 0.3s;
            white-space: nowrap;
        }
        
        .search-box button:hover {
            background: var(--secondary-color);
        }
        
        .cart-link {
            display: flex;
            align-items: center;
            text-decoration: none;
            color: var(--text-color);
            transition: color 0.3s;
            padding: 0.5rem;
            position: relative;
            background: none !important;
        }
        
        .cart-link:hover {
            color: var(--primary-color);
        }
        
        .cart-icon {
            width: 24px;
            height: 24px;
        }
        
        .cart-count {
            background: var(--accent-color);
            color: white;
            border-radius: 50%;
            width: 18px;
            height: 18px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.7rem;
            position: absolute;
            top: 2px;
            right: 2px;
            font-weight: bold;
        }

        /* Mobile menu button */
        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            font-size: 1.5rem;
            color: var(--text-color);
            cursor: pointer;
        }

        /* Main content margin for fixed header */
        main {
            margin-top: 120px;
            min-height: calc(100vh - 120px);
        }

        /* Form styles */
        .form-container {
            max-width: 400px;
            margin: 2rem auto;
            padding: 2rem;
            background: white;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        .form-container h2 {
            text-align: center;
            color: var(--primary-color);
            margin-bottom: 2rem;
            font-size: 2rem;
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            color: var(--text-color);
            font-weight: 500;
        }

        .form-group input {
            width: 100%;
            padding: 0.75rem;
            border: 2px solid var(--border-color);
            border-radius: 5px;
            font-size: 1rem;
            transition: border-color 0.3s;
        }

        .form-group input:focus {
            outline: none;
            border-color: var(--primary-color);
        }

        .btn {
            width: 100%;
            padding: 0.75rem;
            background: var(--primary-color);
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 1rem;
            cursor: pointer;
            transition: background 0.3s;
        }

        .btn:hover {
            background: var(--secondary-color);
        }

        .form-container p {
            text-align: center;
            margin-top: 1rem;
        }

        .form-container a {
            color: var(--primary-color);
            text-decoration: none;
        }

        .form-container a:hover {
            text-decoration: underline;
        }

        /* Responsive */
        @media (max-width: 1200px) {
            .header-full-width {
                padding: 0 1.5rem;
            }
            
            .header-container {
                gap: 2rem;
            }
            
            nav ul {
                gap: 1.5rem;
            }
            
            .header-actions {
                min-width: 250px;
            }
            
            .search-box {
                min-width: 200px;
            }
        }

        @media (max-width: 992px) {
            .header-container {
                gap: 1.5rem;
            }
            
            nav {
                margin: 0 1rem;
            }
            
            nav ul {
                gap: 1rem;
            }
            
            .header-actions {
                min-width: 200px;
            }
            
            .search-box {
                min-width: 180px;
                margin-right: 0.5rem;
            }
        }

        @media (max-width: 768px) {
            .header-container {
                flex-wrap: wrap;
                gap: 1rem;
            }
            
            .mobile-menu-btn {
                display: block;
            }
            
            nav {
                order: 3;
                display: none;
                width: 100%;
                margin: 0;
            }
            
            nav.active {
                display: block;
            }
            
            nav ul {
                flex-direction: column;
                gap: 0.5rem;
                padding: 1rem 0;
            }
            
            .header-actions {
                min-width: auto;
                gap: 0.5rem;
            }
            
            .search-box {
                min-width: 150px;
            }
            
            .logo {
                min-width: auto;
            }
            
            .logo h1 {
                font-size: 1.5rem;
            }
            
            .cart-link {
                padding: 0.3rem;
            }

            main {
                margin-top: 100px;
            }

            .form-container {
                margin: 1rem;
                padding: 1.5rem;
            }
        }

        @media (max-width: 480px) {
            .header-full-width {
                padding: 0 1rem;
            }
            
            .search-box {
                min-width: 120px;
            }
            
            .cart-link {
                padding: 0.2rem;
            }

            .form-container {
                padding: 1rem;
            }
        }
    </style>
</head>
<body>
    <!-- Header - Full Width -->
    <header>
        <div class="header-full-width">
            <div class="header-container">
                <button class="mobile-menu-btn">
                    <i class="fas fa-bars"></i>
                </button>
                
                <div class="logo">
                    <!-- ЗАЩИТА ОТ XSS: экранируем вывод -->
                    <h1><?= Security::escape(SITE_NAME) ?></h1>
                </div>
                
                <nav id="main-nav">
                    <ul>
                        <li><a href="index.php">Главная</a></li>
                        <li><a href="catalog.php">Обувь</a></li>
                        <li><a href="feedback.php">Обратная связь</a></li>
                        <?php if(isset($_SESSION['user_id'])): ?>
                            <?php if($is_admin): ?>
                                <li><a href="admin.php" class="admin-link">Админ панель</a></li>
                            <?php endif; ?>
                            <li><a href="profile.php">Личный кабинет</a></li>
                            <li><a href="logout.php">Выйти</a></li>
                        <?php else: ?>
                            <li><a href="login.php" style="color: var(--primary-color);">Войти</a></li>
                            <li><a href="register.php">Регистрация</a></li>
                        <?php endif; ?>
                    </ul>
                </nav>
                
                <div class="header-actions">
                    <div class="search-box">
                        <input type="text" id="searchInput" placeholder="Поиск товаров...">
                        <button onclick="searchProducts()">
                            <i class="fas fa-search"></i>
                        </button>
                    </div>
                    
                    <a href="cart.php" class="cart-link">
                        <svg class="cart-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path>
                            <line x1="3" y1="6" x2="21" y2="6"></line>
                            <path d="M16 10a4 4 0 0 1-8 0"></path>
                        </svg>
                        <span class="cart-count">0</span>
                    </a>
                </div>
            </div>
        </div>
    </header>

    <main>
        <div class="form-container">
            <h2>Вход в аккаунт</h2>
            
            <?php if (!empty($errors)): ?>
                <div style="background: #ff6b6b; color: white; padding: 1rem; border-radius: 5px; margin-bottom: 1rem;">
                    <?php foreach ($errors as $error): ?>
                        <!-- ЗАЩИТА ОТ XSS: экранируем вывод ошибок -->
                        <p><?= Security::escape($error) ?></p>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            
            <?php if (isset($_SESSION['success'])): ?>
                <div style="background: #4ecdc4; color: white; padding: 1rem; border-radius: 5px; margin-bottom: 1rem;">
                    <!-- ЗАЩИТА ОТ XSS: экранируем вывод успешных сообщений -->
                    <p><?= Security::escape($_SESSION['success']) ?></p>
                </div>
                <?php unset($_SESSION['success']); ?>
            <?php endif; ?>
            
            <form method="POST" action="">
                <div class="form-group">
                    <label for="username">Имя пользователя или Email:</label>
                    <!-- ЗАЩИТА ОТ XSS: экранируем значение в форме -->
                    <input type="text" id="username" name="username" value="<?= $username_value ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="password">Пароль:</label>
                    <input type="password" id="password" name="password" required>
                </div>
                
                <button type="submit" class="btn">Войти</button>
            </form>
            
            <p style="text-align: center; margin-top: 1rem;">
                Нет аккаунта? <a href="register.php">Зарегистрируйтесь</a>
            </p>
        </div>
    </main>

    <script>
        // Mobile menu toggle
        document.querySelector('.mobile-menu-btn').addEventListener('click', function() {
            document.getElementById('main-nav').classList.toggle('active');
        });

        // Close mobile menu when clicking outside
        document.addEventListener('click', function(event) {
            const nav = document.getElementById('main-nav');
            const menuBtn = document.querySelector('.mobile-menu-btn');
            if (!nav.contains(event.target) && !menuBtn.contains(event.target)) {
                nav.classList.remove('active');
            }
        });

        function searchProducts() {
            const searchTerm = document.getElementById('searchInput').value;
            if (searchTerm.trim()) {
                // Защита от XSS в JavaScript: кодируем параметры URL
                window.location.href = `catalog.php?search=${encodeURIComponent(searchTerm)}`;
            }
        }

        // Update cart count
        function updateCartCount() {
            document.querySelector('.cart-count').textContent = '0';
        }

        // Initialize cart count on page load
        document.addEventListener('DOMContentLoaded', updateCartCount);

        // Search on Enter key
        document.getElementById('searchInput').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                searchProducts();
            }
        });
    </script>
</body>
<footer style="background: var(--primary-color); color: white; padding: 3rem 0; margin-top: 4rem;">
    <div class="container">
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 3rem; margin-bottom: 2rem;">
            <div>
                <!-- ЗАЩИТА ОТ XSS: экранируем вывод -->
                <h3 style="color: var(--light-color); margin-bottom: 1rem; font-size: 1.5rem;"><?= Security::escape(SITE_NAME) ?></h3>
                <p style="line-height: 1.6; opacity: 0.9;">Ваш голос в мире уличной моды. Премиальная обувь от ведущих мировых брендов с доставкой по всей России.</p>
                <div style="display: flex; gap: 1rem; margin-top: 1rem;">
                    <a href="<?= Security::escape(INSTAGRAM) ?>" style="color: white; opacity: 0.8; transition: opacity 0.3s;" onmouseover="this.style.opacity='1'" onmouseout="this.style.opacity='0.8'">
                         Instagram
                    </a>
                    <a href="<?= Security::escape(TELEGRAM) ?>" style="color: white; opacity: 0.8; transition: opacity 0.3s;" onmouseover="this.style.opacity='1'" onmouseout="this.style.opacity='0.8'">
                         Telegram
                    </a>
                    <a href="<?= Security::escape(VK) ?>" style="color: white; opacity: 0.8; transition: opacity 0.3s;" onmouseover="this.style.opacity='1'" onmouseout="this.style.opacity='0.8'">
                         VK
                    </a>
                </div>
            </div>
            
            <div>
                <h4 style="color: var(--light-color); margin-bottom: 1rem;">Контактная информация</h4>
                <div style="display: flex; flex-direction: column; gap: 0.5rem;">
                    <div style="display: flex; align-items: center; gap: 0.5rem;">
                        <span></span>
                        <!-- ЗАЩИТА ОТ XSS: экранируем вывод контактных данных -->
                        <span><?= Security::escape(PHONE) ?></span>
                    </div>
                    <div style="display: flex; align-items: center; gap: 0.5rem;">
                        <span></span>
                        <span><?= Security::escape(EMAIL) ?></span>
                    </div>
                    <div style="display: flex; align-items: center; gap: 0.5rem;">
                        <span></span>
                        <span><?= Security::escape(ADDRESS) ?></span>
                    </div>
                </div>
            </div>
            
            <div>
                <h4 style="color: var(--light-color); margin-bottom: 1rem;">Полезные ссылки</h4>
                <div style="display: flex; flex-direction: column; gap: 0.5rem;">
                    <a href="catalog.php" style="color: white; opacity: 0.8; text-decoration: none; transition: opacity 0.3s;" 
                       onmouseover="this.style.opacity='1'" onmouseout="this.style.opacity='0.8'">Каталог обуви</a>
                    <a href="feedback.php" style="color: white; opacity: 0.8; text-decoration: none; transition: opacity 0.3s;" 
                       onmouseover="this.style.opacity='1'" onmouseout="this.style.opacity='0.8'">Обратная связь</a>
                    <a href="login.php" style="color: white; opacity: 0.8; text-decoration: none; transition: opacity 0.3s;" 
                       onmouseover="this.style.opacity='1'" onmouseout="this.style.opacity='0.8'">Личный кабинет</a>
                </div>
            </div>
            
            <div>
                <h4 style="color: var(--light-color); margin-bottom: 1rem;">Часы работы</h4>
                <div style="display: flex; flex-direction: column; gap: 0.5rem; opacity: 0.9;">
                    <div>Пн-Пт: 9:00 - 21:00</div>
                    <div>Сб-Вс: 10:00 - 20:00</div>
                    <div style="margin-top: 0.5rem; font-size: 0.9rem;">Доставка работает ежедневно</div>
                </div>
            </div>
        </div>
        
        <div style="text-align: center; padding-top: 2rem; border-top: 1px solid rgba(255,255,255,0.2);">
            <p style="margin: 0; opacity: 0.8; font-size: 0.9rem;">
                &copy; 2026 <?= Security::escape(SITE_NAME) ?>. Все права защищены. 
                <span style="display: block; margin-top: 0.5rem;">
                    Сайт создан для демонстрации возможностей интернет-магазина
                </span>
            </p>
        </div>
    </div>
</footer>
</html>
