<?php
session_start();
require_once '../includes/database.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Необходима авторизация']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_id = $_POST['product_id'] ?? null;
    $size = $_POST['size'] ?? null;
    
    if (!$product_id) {
        echo json_encode(['success' => false, 'message' => 'Не указан товар']);
        exit;
    }
    
    $db = new Database();
    $connection = $db->getConnection();
    
    // Проверка существования товара
    $stmt = $connection->prepare("SELECT id FROM products WHERE id = ?");
    $stmt->execute([$product_id]);
    if (!$stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'Товар не найден']);
        exit;
    }
    
    // Проверка наличия товара в корзине
    $stmt = $connection->prepare("SELECT id, quantity FROM cart WHERE user_id = ? AND product_id = ? AND size = ?");
    $stmt->execute([$_SESSION['user_id'], $product_id, $size]);
    $existing_item = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($existing_item) {
        // Увеличиваем количество
        $stmt = $connection->prepare("UPDATE cart SET quantity = quantity + 1 WHERE id = ?");
        $stmt->execute([$existing_item['id']]);
    } else {
        // Добавляем новый товар
        $stmt = $connection->prepare("INSERT INTO cart (user_id, product_id, size) VALUES (?, ?, ?)");
        $stmt->execute([$_SESSION['user_id'], $product_id, $size]);
    }
    
    echo json_encode(['success' => true]);
}
?>
