<?php
session_start();                        // Доступ к данным пользователя
require_once '../includes/database.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['count' => 0]); // Не авторизован = 0
    exit;
}

$db = new Database();
$connection = $db->getConnection();

// Суммируем все товары в корзине этого пользователя
$stmt = $connection->prepare("SELECT SUM(quantity) as total FROM cart WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);

// Если корзина пуста (NULL) → 0
echo json_encode(['count' => $result['total'] ?? 0]);
?>