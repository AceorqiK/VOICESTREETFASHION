<?php
session_start();
require_once '../includes/database.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Необходима авторизация']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_id = $_POST['product_id'] ?? null;
    $rating = $_POST['rating'] ?? null;
    $comment = $_POST['comment'] ?? '';
    
    if (!$product_id || !$rating) {
        echo json_encode(['success' => false, 'message' => 'Не все поля заполнены']);
        exit;
    }
    
    $db = new Database();
    $connection = $db->getConnection();
    
    try {
        $connection->beginTransaction();
        
        // Проверяем, не оставлял ли пользователь уже отзыв
        $stmt = $connection->prepare("SELECT id FROM reviews WHERE user_id = ? AND product_id = ?");
        $stmt->execute([$_SESSION['user_id'], $product_id]);
        
        if ($stmt->fetch()) {
            echo json_encode(['success' => false, 'message' => 'Вы уже оставляли отзыв на этот товар']);
            exit;
        }
        
        // Добавляем отзыв
        $stmt = $connection->prepare("INSERT INTO reviews (user_id, product_id, rating, comment) VALUES (?, ?, ?, ?)");
        $stmt->execute([$_SESSION['user_id'], $product_id, $rating, $comment]);
        
        // Обновляем средний рейтинг товара
        $stmt = $connection->prepare("
            UPDATE products 
            SET average_rating = (
                SELECT AVG(rating) FROM reviews WHERE product_id = ?
            ),
            review_count = (
                SELECT COUNT(*) FROM reviews WHERE product_id = ?
            )
            WHERE id = ?
        ");
        $stmt->execute([$product_id, $product_id, $product_id]);
        
        $connection->commit();
        
        echo json_encode(['success' => true, 'message' => 'Отзыв успешно добавлен']);
        
    } catch (Exception $e) {
        $connection->rollBack();
        echo json_encode(['success' => false, 'message' => 'Ошибка: ' . $e->getMessage()]);
    }
}
?>
