<?php
session_start();
require_once 'includes/database.php';
require_once 'includes/config.php';

// Класс безопасности
class Security {
    public static function escape($data) {
        if (is_array($data)) {
            return array_map([self::class, 'escape'], $data);
        }
        return htmlspecialchars($data, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    }
    
    public static function validateInput($data, $type = 'string') {
        if ($data === null) return '';
        
        $data = trim($data);
        $data = stripslashes($data);
        
        switch ($type) {
            case 'email':
                $data = filter_var($data, FILTER_SANITIZE_EMAIL);
                return filter_var($data, FILTER_VALIDATE_EMAIL) ? $data : false;
            case 'int':
                return filter_var($data, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
            case 'float':
                return filter_var($data, FILTER_VALIDATE_FLOAT);
            case 'url':
                $data = filter_var($data, FILTER_SANITIZE_URL);
                return filter_var($data, FILTER_VALIDATE_URL) ? $data : '';
            case 'text':
                return self::escape($data);
            default:
                return self::escape($data);
        }
    }
    
    public static function validatePrice($price) {
        $price = str_replace(',', '.', $price);
        $price = filter_var($price, FILTER_VALIDATE_FLOAT);
        return ($price !== false && $price >= 0) ? $price : false;
    }
}

// Функция для получения количества товаров в корзине
function getCartCount($user_id, $connection) {
    try {
        $stmt = $connection->prepare("SELECT SUM(quantity) as total FROM cart WHERE user_id = ?");
        $stmt->execute([$user_id]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return (int)($result['total'] ?? 0);
    } catch (PDOException $e) {
        error_log("Cart count error: " . $e->getMessage());
        return 0;
    }
}

// ЗАЩИТА: Проверка авторизации и прав администратора
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$db = new Database();
$connection = $db->getConnection();

// Проверяем, является ли пользователь администратором
$is_admin = false;
$user_role = '';
if(isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $stmt = $connection->prepare("SELECT role FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($user) {
        $is_admin = ($user['role'] === 'admin');
        $_SESSION['is_admin'] = $is_admin;
        $user_role = $user['role'];
    }
}

// ЗАЩИТА: Проверка прав администратора
if (!$is_admin) {
    die('<h2 style="text-align: center; margin-top: 2rem; color: red;">Доступ запрещен. Требуются права администратора.</h2>');
}

// ЗАЩИТА: Валидация раздела
$allowed_sections = ['dashboard', 'products', 'orders', 'users'];
$current_section = Security::validateInput($_GET['section'] ?? 'dashboard');
if (!in_array($current_section, $allowed_sections)) {
    $current_section = 'dashboard';
}

// ЗАЩИТА: Получение статистики с обработкой ошибок
$stats = [];
try {
    $stmt = $connection->prepare("SELECT COUNT(*) as total FROM users");
    $stmt->execute();
    $stats['users'] = $stmt->fetch()['total'];

    $stmt = $connection->prepare("SELECT COUNT(*) as total FROM products");
    $stmt->execute();
    $stats['products'] = $stmt->fetch()['total'];

    $stmt = $connection->prepare("SELECT COUNT(*) as total FROM orders");
    $stmt->execute();
    $stats['orders'] = $stmt->fetch()['total'];

    $stmt = $connection->prepare("SELECT SUM(total_amount) as total FROM orders WHERE status = 'completed'");
    $stmt->execute();
    $stats['revenue'] = $stmt->fetch()['total'] ?? 0;
} catch (PDOException $e) {
    error_log("Admin stats error: " . $e->getMessage());
    $stats = ['users' => 0, 'products' => 0, 'orders' => 0, 'revenue' => 0];
}

// Обработка форм
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $success = $error = '';
    
    if (isset($_POST['add_product'])) {
        // ЗАЩИТА: Валидация и очистка входных данных
        $name = Security::validateInput($_POST['name'] ?? '', 'text');
        $description = Security::validateInput($_POST['description'] ?? '', 'text');
        $price = Security::validatePrice($_POST['price'] ?? '');
        $brand = Security::validateInput($_POST['brand'] ?? '', 'text');
        $in_stock_quantity = Security::validateInput($_POST['in_stock_quantity'] ?? 0, 'int');
        $image_url = Security::validateInput($_POST['image_url'] ?? '', 'url');
        
        if (!$image_url) {
            $image_url = 'https://via.placeholder.com/400x300/4C4F54/EFDFC5?text=' . urlencode($name);
        }
        
        // Дополнительная валидация
        if (empty($name) || empty($description) || $price === false || empty($brand)) {
            $error = "Заполните все обязательные поля корректно";
        } elseif ($in_stock_quantity < 0) {
            $error = "Количество не может быть отрицательным";
        } else {
            // ЗАЩИТА: Подготовленный запрос
            $stmt = $connection->prepare("
                INSERT INTO products (name, description, price, brand, in_stock_quantity, image_url) 
                VALUES (?, ?, ?, ?, ?, ?)
            ");
            
            if ($stmt->execute([$name, $description, $price, $brand, $in_stock_quantity, $image_url])) {
                $success = "Товар успешно добавлен!";
            } else {
                $error = "Ошибка при добавлении товара";
            }
        }
    }
    
    // Редактирование товара
    if (isset($_POST['edit_product'])) {
        $product_id = Security::validateInput($_POST['product_id'] ?? 0, 'int');
        $name = Security::validateInput($_POST['name'] ?? '', 'text');
        $description = Security::validateInput($_POST['description'] ?? '', 'text');
        $price = Security::validatePrice($_POST['price'] ?? '');
        $brand = Security::validateInput($_POST['brand'] ?? '', 'text');
        $in_stock_quantity = Security::validateInput($_POST['in_stock_quantity'] ?? 0, 'int');
        $image_url = Security::validateInput($_POST['image_url'] ?? '', 'url');
        
        if ($product_id && !empty($name) && !empty($description) && $price !== false && !empty($brand)) {
            $stmt = $connection->prepare("
                UPDATE products 
                SET name = ?, description = ?, price = ?, brand = ?, in_stock_quantity = ?, image_url = ?
                WHERE id = ?
            ");
            
            if ($stmt->execute([$name, $description, $price, $brand, $in_stock_quantity, $image_url, $product_id])) {
                $success = "Товар успешно обновлен!";
            } else {
                $error = "Ошибка при обновлении товара";
            }
        } else {
            $error = "Неверные данные для обновления";
        }
    }
}

// Управление товарами
if ($current_section === 'products') {
    // ЗАЩИТА: Получение товаров с подготовленным запросом
    try {
        $stmt = $connection->prepare("SELECT * FROM products ORDER BY id DESC");
        $stmt->execute();
        $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Products fetch error: " . $e->getMessage());
        $products = [];
    }
    
    // Получение данных товара для редактирования
    $edit_product = null;
    if (isset($_GET['edit_product'])) {
        $product_id = Security::validateInput($_GET['edit_product'], 'int');
        if ($product_id) {
            $stmt = $connection->prepare("SELECT * FROM products WHERE id = ?");
            $stmt->execute([$product_id]);
            $edit_product = $stmt->fetch(PDO::FETCH_ASSOC);
        }
    }
    
    // Удаление товара
    if (isset($_GET['delete_product'])) {
        $product_id = Security::validateInput($_GET['delete_product'], 'int');
        if ($product_id) {
            $stmt = $connection->prepare("DELETE FROM products WHERE id = ?");
            if ($stmt->execute([$product_id])) {
                header("Location: admin.php?section=products&deleted=1");
                exit;
            }
        }
    }
}

// Управление заказами
if ($current_section === 'orders') {
    try {
        $stmt = $connection->prepare("SELECT * FROM orders ORDER BY id DESC");
        $stmt->execute();
        $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Orders fetch error: " . $e->getMessage());
        $orders = [];
    }
}

// Управление пользователями
if ($current_section === 'users') {
    try {
        $stmt = $connection->prepare("SELECT id, username, email, created_at, role FROM users ORDER BY id DESC");
        $stmt->execute();
        $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Users fetch error: " . $e->getMessage());
        $users = [];
    }
}

// Безопасное получение значений для форм
$name_value = isset($_POST['name']) ? Security::escape($_POST['name']) : '';
$description_value = isset($_POST['description']) ? Security::escape($_POST['description']) : '';
$price_value = isset($_POST['price']) ? Security::escape($_POST['price']) : '';
$brand_value = isset($_POST['brand']) ? Security::escape($_POST['brand']) : '';
$quantity_value = isset($_POST['in_stock_quantity']) ? Security::escape($_POST['in_stock_quantity']) : '0';
$image_value = isset($_POST['image_url']) ? Security::escape($_POST['image_url']) : '';

// Получаем количество товаров в корзине для текущего пользователя
$cart_count = getCartCount($_SESSION['user_id'], $connection);
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- ЗАЩИТА ОТ XSS: экранируем вывод -->
    <title>Админ-панель - <?= Security::escape(SITE_NAME) ?></title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #000000;
            --secondary-color: #1a1a1a;
            --accent-color: #404040;
            --light-color: #f8f8f8;
            --text-color: #000000;
            --success-color: #2e2e2e;
            --border-color: #cccccc;
            --admin-color: #000000;
            --text-color-light: #ffffff;
            --text-color-muted: #666666;
            --border-color-light: rgba(0,0,0,0.2);
            --shadow-color: rgba(0,0,0,0.1);
        }
        
        body {
            background: #ffffff;
            color: var(--text-color);
            font-family: 'Arial', sans-serif;
        }
        
        /* Header Styles - Full Width */
        header {
            background: white;
            box-shadow: 0 2px 20px var(--shadow-color);
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            padding: 0.5rem 0;
            width: 100%;
            border-bottom: 2px solid var(--primary-color);
        }
        
        .header-full-width {
            max-width: 100%;
            margin: 0;
            padding: 0 2rem;
        }
        
        .header-container {
            display: flex;
            align-items: center;
            justify-content: space-between;
            width: 100%;
            gap: 3rem;
        }
        
        .logo {
            display: flex;
            flex-direction: column;
            align-items: flex-start;
            min-width: 200px;
        }
        
        .logo h1 {
            color: var(--primary-color) !important;
            font-size: 1.8rem;
            font-weight: bold;
            margin: 0;
            line-height: 1;
            white-space: nowrap;
        }
        
        .logo span {
            color: var(--secondary-color);
            font-size: 0.8rem;
            margin-top: 2px;
        }
        
        nav {
            flex: 1;
            display: flex;
            justify-content: center;
            margin: 0 2rem;
        }
        
        nav ul {
            display: flex;
            list-style: none;
            margin: 0;
            padding: 0;
            gap: 2rem;
        }
        
        nav a {
            text-decoration: none;
            color: var(--text-color);
            font-weight: 500;
            font-size: 1rem;
            transition: color 0.3s;
            position: relative;
            white-space: nowrap;
            padding: 0.5rem 0;
        }
        
        nav a:hover {
            color: var(--primary-color);
        }
        
        nav a::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 0;
            height: 2px;
            background: var(--primary-color);
            transition: width 0.3s;
        }
        
        nav a:hover::after {
            width: 100%;
        }
        
        .admin-link {
            color: var(--admin-color) !important;
            font-weight: 600 !important;
        }
        
        .admin-link:hover {
            color: var(--admin-color) !important;
        }
        
        .admin-link::after {
            background: var(--admin-color) !important;
        }
        
        .header-actions {
            display: flex;
            align-items: center;
            gap: 1rem;
            min-width: 300px;
            justify-content: flex-end;
        }
        
        .search-box {
            display: flex;
            background: var(--light-color);
            border-radius: 25px;
            padding: 0.4rem;
            border: 2px solid var(--border-color);
            transition: border-color 0.3s;
            min-width: 250px;
            margin-right: 1rem;
        }
        
        .search-box:focus-within {
            border-color: var(--primary-color);
        }
        
        .search-box input {
            border: none;
            background: none;
            outline: none;
            padding: 0 1rem;
            width: 100%;
            font-size: 0.9rem;
            color: var(--text-color);
        }
        
        .search-box input::placeholder {
            color: var(--text-color-muted);
        }
        
        .search-box button {
            background: var(--primary-color);
            color: white;
            border: none;
            padding: 0.4rem 1rem;
            border-radius: 20px;
            cursor: pointer;
            font-size: 0.9rem;
            transition: background 0.3s;
            white-space: nowrap;
        }
        
        .search-box button:hover {
            background: var(--secondary-color);
        }
        
        .cart-link {
            display: flex;
            align-items: center;
            text-decoration: none;
            color: var(--text-color);
            transition: color 0.3s;
            padding: 0.5rem;
            position: relative;
            background: none !important;
        }
        
        .cart-link:hover {
            color: var(--primary-color);
        }
        
        .cart-icon {
            width: 24px;
            height: 24px;
        }
        
        .cart-count {
            background: var(--accent-color);
            color: white;
            border-radius: 50%;
            min-width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.75rem;
            position: absolute;
            top: 2px;
            right: 2px;
            font-weight: bold;
            padding: 0 4px;
            transition: transform 0.2s;
        }
        
        .cart-count.highlight {
            animation: pulse 0.3s ease-in-out;
        }
        
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.2); }
            100% { transform: scale(1); }
        }

        /* Mobile menu button */
        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            font-size: 1.5rem;
            color: var(--text-color);
            cursor: pointer;
        }

        /* Main content margin for fixed header */
        main {
            margin-top: 100px;
        }

        /* Responsive */
        @media (max-width: 1200px) {
            .header-full-width {
                padding: 0 1.5rem;
            }
            
            .header-container {
                gap: 2rem;
            }
            
            nav ul {
                gap: 1.5rem;
            }
            
            .header-actions {
                min-width: 250px;
            }
            
            .search-box {
                min-width: 200px;
            }
        }

        @media (max-width: 992px) {
            .header-container {
                gap: 1.5rem;
            }
            
            nav {
                margin: 0 1rem;
            }
            
            nav ul {
                gap: 1rem;
            }
            
            .header-actions {
                min-width: 200px;
            }
            
            .search-box {
                min-width: 180px;
                margin-right: 0.5rem;
            }
        }

        @media (max-width: 768px) {
            .header-container {
                flex-wrap: wrap;
                gap: 1rem;
            }
            
            .mobile-menu-btn {
                display: block;
            }
            
            nav {
                order: 3;
                display: none;
                width: 100%;
                margin: 0;
            }
            
            nav.active {
                display: block;
            }
            
            nav ul {
                flex-direction: column;
                gap: 0.5rem;
                padding: 1rem 0;
            }
            
            .header-actions {
                min-width: auto;
                gap: 0.5rem;
            }
            
            .search-box {
                min-width: 150px;
            }
            
            .logo {
                min-width: auto;
            }
            
            .logo h1 {
                font-size: 1.5rem;
            }
            
            .cart-link {
                padding: 0.3rem;
            }
            
            .cart-count {
                min-width: 18px;
                height: 18px;
                font-size: 0.7rem;
            }
            
            main {
                margin-top: 120px;
            }
        }

        @media (max-width: 480px) {
            .header-full-width {
                padding: 0 1rem;
            }
            
            .search-box {
                min-width: 120px;
            }
            
            .cart-link {
                padding: 0.2rem;
            }
        }

        /* Admin Panel Styles */
        .admin-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-bottom: 2rem;
        }
        .stat-card {
            background: var(--light-color);
            padding: 1.5rem;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 5px 15px var(--shadow-color);
            border: 1px solid var(--border-color);
        }
        .stat-card h3 {
            color: var(--accent-color);
            margin-bottom: 0.5rem;
            font-size: 0.9rem;
        }
        .stat-card .number {
            font-size: 2rem;
            font-weight: bold;
            color: var(--text-color);
        }
        .admin-section {
            background: var(--light-color);
            padding: 1.5rem;
            border-radius: 10px;
            box-shadow: 0 5px 15px var(--shadow-color);
            margin-bottom: 2rem;
            border: 1px solid var(--border-color);
        }
        .admin-nav {
            background: var(--primary-color);
            padding: 1rem;
            border-radius: 10px;
            margin-bottom: 2rem;
            display: flex;
            flex-wrap: wrap;
            gap: 1rem;
        }
        .admin-nav a {
            color: var(--text-color-light);
            text-decoration: none;
            padding: 0.5rem 1rem;
            border-radius: 5px;
            transition: background 0.3s;
            border: 1px solid transparent;
        }
        .admin-nav a:hover, .admin-nav a.active {
            background: var(--secondary-color);
            color: white;
        }
        .admin-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1rem;
        }
        .admin-table th, .admin-table td {
            padding: 0.75rem;
            text-align: left;
            border-bottom: 1px solid var(--border-color);
            color: var(--text-color);
        }
        .admin-table th {
            background: var(--primary-color);
            color: var(--text-color-light);
        }
        .btn {
            background: var(--secondary-color);
            color: white;
            border: none;
            padding: 0.5rem 1rem;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            font-size: 0.9rem;
            transition: background 0.3s;
            border: 1px solid var(--border-color);
        }
        .btn:hover {
            background: var(--accent-color);
        }
        .btn-danger {
            background: var(--admin-color);
        }
        .btn-danger:hover {
            background: var(--secondary-color);
        }
        .btn-success {
            background: var(--success-color);
        }
        .btn-success:hover {
            background: var(--accent-color);
        }
        .no-data {
            text-align: center;
            padding: 2rem;
            color: var(--text-color);
        }
        .form-group {
            margin-bottom: 1rem;
        }
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            color: var(--text-color);
            font-weight: bold;
        }
        .form-group input, .form-group textarea {
            width: 100%;
            padding: 0.5rem;
            border: 1px solid var(--border-color);
            border-radius: 5px;
            background: white;
            color: var(--text-color);
        }
        .form-group input::placeholder, .form-group textarea::placeholder {
            color: var(--text-color-muted);
        }
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
        }
        .action-buttons {
            display: flex;
            gap: 0.5rem;
        }
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
        }
        .modal-content {
            background-color: white;
            margin: 5% auto;
            padding: 2rem;
            border-radius: 10px;
            width: 90%;
            max-width: 600px;
            max-height: 80vh;
            overflow-y: auto;
            border: 2px solid var(--primary-color);
        }
        .close {
            color: var(--text-color);
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
        }
        .close:hover {
            color: var(--primary-color);
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }
        
        /* Success and error messages */
        .alert {
            padding: 1rem;
            border-radius: 5px;
            margin-bottom: 1rem;
            border: 1px solid var(--border-color);
        }
        .alert-success {
            background: var(--success-color);
            color: white;
        }
        .alert-danger {
            background: var(--admin-color);
            color: white;
        }
        
        /* Additional black and white styling */
        h1, h2, h3, h4, h5, h6 {
            color: var(--text-color);
        }
        
        input, textarea, select {
            border: 1px solid var(--border-color) !important;
        }
        
        table {
            border: 1px solid var(--border-color);
        }
        
        .admin-table tr:hover {
            background-color: #f5f5f5;
        }
    </style>
</head>
<body>
    <!-- Header - Full Width -->
    <header>
        <div class="header-full-width">
            <div class="header-container">
                <button class="mobile-menu-btn">
                    <i class="fas fa-bars"></i>
                </button>
                
                <div class="logo">
                    <h1><?= Security::escape(SITE_NAME) ?></h1>
                </div>
                
                <nav id="main-nav">
                    <ul>
                        <li><a href="index.php">Главная</a></li>
                        <li><a href="catalog.php">Обувь</a></li>
                        <li><a href="feedback.php">Обратная связь</a></li>
                        <?php if(isset($_SESSION['user_id'])): ?>
                            <?php if($is_admin): ?>
                                <li><a href="admin.php" class="admin-link">Админ панель</a></li>
                            <?php endif; ?>
                            <li><a href="profile.php">Личный кабинет</a></li>
                            <li><a href="logout.php">Выйти</a></li>
                        <?php else: ?>
                            <li><a href="login.php">Войти</a></li>
                            <li><a href="register.php">Регистрация</a></li>
                        <?php endif; ?>
                    </ul>
                </nav>
                
                <div class="header-actions">
                    <div class="search-box">
                        <input type="text" id="searchInput" placeholder="Поиск товаров...">
                        <button onclick="searchProducts()">
                            <i class="fas fa-search"></i>
                        </button>
                    </div>
                    
                    <a href="cart.php" class="cart-link">
                        <svg class="cart-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path>
                            <line x1="3" y1="6" x2="21" y2="6"></line>
                            <path d="M16 10a4 4 0 0 1-8 0"></path>
                        </svg>
                        <span class="cart-count" id="cartCount"><?= (int)$cart_count ?></span>
                    </a>
                </div>
            </div>
        </div>
    </header>

    <main>
        <div class="container">
            <h1 style="color: var(--primary-color); text-align: center; margin-bottom: 2rem;">Админ-панель</h1>
            
            <div class="admin-nav">
                <a href="admin.php?section=dashboard" class="<?= $current_section === 'dashboard' ? 'active' : '' ?>"> Статистика</a>
                <a href="admin.php?section=products" class="<?= $current_section === 'products' ? 'active' : '' ?>"> Управление товарами</a>
                <a href="admin.php?section=orders" class="<?= $current_section === 'orders' ? 'active' : '' ?>"> Управление заказами</a>
                <a href="admin.php?section=users" class="<?= $current_section === 'users' ? 'active' : '' ?>"> Управление пользователями</a>
            </div>

            <?php if ($current_section === 'dashboard'): ?>
                <!-- Статистика -->
                <div class="admin-stats">
                    <div class="stat-card">
                        <h3>Пользователи</h3>
                        <div class="number"><?= Security::escape($stats['users']) ?></div>
                    </div>
                    <div class="stat-card">
                        <h3>Товары</h3>
                        <div class="number"><?= Security::escape($stats['products']) ?></div>
                    </div>
                    <div class="stat-card">
                        <h3>Заказы</h3>
                        <div class="number"><?= Security::escape($stats['orders']) ?></div>
                    </div>
                    <div class="stat-card">
                        <h3>Выручка</h3>
                        <div class="number"><?= Security::escape(number_format($stats['revenue'], 0, ',', ' ')) ?> ₽</div>
                    </div>
                </div>

                <!-- Добавление товара -->
                <div class="admin-section">
                    <h2 style="color: var(--primary-color); margin-bottom: 1rem;">Добавить новый товар</h2>
                    
                    <?php if (isset($success) && $success): ?>
                        <div class="alert alert-success">
                            <?= Security::escape($success) ?>
                        </div>
                    <?php endif; ?>
                    
                    <?php if (isset($error) && $error): ?>
                        <div class="alert alert-danger">
                            <?= Security::escape($error) ?>
                        </div>
                    <?php endif; ?>
                    
                    <form method="POST" style="display: grid; gap: 1rem; max-width: 500px;">
                        <div class="form-group">
                            <label>Название товара:</label>
                            <input type="text" name="name" value="<?= $name_value ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label>Описание:</label>
                            <textarea name="description" required rows="4"><?= $description_value ?></textarea>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label>Цена (₽):</label>
                                <input type="number" name="price" step="0.01" value="<?= $price_value ?>" required>
                            </div>
                            
                            <div class="form-group">
                                <label>Бренд:</label>
                                <input type="text" name="brand" value="<?= $brand_value ?>" required>
                            </div>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label>Количество в наличии:</label>
                                <input type="number" name="in_stock_quantity" value="<?= $quantity_value ?>" required>
                            </div>
                            
                            <div class="form-group">
                                <label>URL изображения:</label>
                                <input type="url" name="image_url" value="<?= $image_value ?>" placeholder="https://example.com/image.jpg">
                            </div>
                        </div>
                        
                        <button type="submit" name="add_product" class="btn btn-success">Добавить товар</button>
                    </form>
                </div>

            <?php elseif ($current_section === 'products'): ?>
                <!-- Управление товарами -->
                <div class="admin-section">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                        <h2 style="color: var(--primary-color); margin: 0;">Управление товарами</h2>
                        <button class="btn btn-success" onclick="openAddModal()">+ Добавить товар</button>
                    </div>
                    
                    <?php if (isset($_GET['deleted'])): ?>
                        <div class="alert alert-success">
                            Товар успешно удален!
                        </div>
                    <?php endif; ?>
                    
                    <?php if (isset($success) && $success): ?>
                        <div class="alert alert-success">
                            <?= Security::escape($success) ?>
                        </div>
                    <?php endif; ?>
                    
                    <?php if (empty($products)): ?>
                        <div class="no-data">
                            <h3>Товары не найдены</h3>
                            <p>Добавьте первый товар</p>
                        </div>
                    <?php else: ?>
                        <table class="admin-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Название</th>
                                    <th>Бренд</th>
                                    <th>Цена</th>
                                    <th>В наличии</th>
                                    <th>Действия</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($products as $product): ?>
                                <tr>
                                    <td><?= Security::escape($product['id']) ?></td>
                                    <td><?= Security::escape($product['name']) ?></td>
                                    <td><?= Security::escape($product['brand']) ?></td>
                                    <td><?= Security::escape(number_format($product['price'], 0, ',', ' ')) ?> ₽</td>
                                    <td><?= Security::escape($product['in_stock_quantity']) ?></td>
                                    <td>
                                        <div class="action-buttons">
                                            <!-- ЗАЩИТА: Экранируем параметры URL -->
                                            <a href="admin.php?section=products&amp;edit_product=<?= Security::escape($product['id']) ?>" 
                                               class="btn">
                                                Редактировать
                                            </a>
                                            <a href="admin.php?section=products&amp;delete_product=<?= Security::escape($product['id']) ?>" 
                                               class="btn btn-danger" 
                                               onclick="return confirm('Вы уверены, что хотите удалить этот товар?')">
                                                Удалить
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>

                <!-- Модальное окно для добавления/редактирования -->
                <div id="productModal" class="modal">
                    <div class="modal-content">
                        <span class="close" onclick="closeModal()">&times;</span>
                        <h3 id="modalTitle" style="color: var(--primary-color);">Добавить товар</h3>
                        <form id="productForm" method="POST">
                            <input type="hidden" name="product_id" id="product_id">
                            
                            <div class="form-group">
                                <label>Название товара:</label>
                                <input type="text" name="name" id="name" required>
                            </div>
                            
                            <div class="form-group">
                                <label>Описание:</label>
                                <textarea name="description" id="description" required rows="4"></textarea>
                            </div>
                            
                            <div class="form-row">
                                <div class="form-group">
                                    <label>Цена (₽):</label>
                                    <input type="number" name="price" id="price" step="0.01" required>
                                </div>
                                
                                <div class="form-group">
                                    <label>Бренд:</label>
                                    <input type="text" name="brand" id="brand" required>
                                </div>
                            </div>
                            
                            <div class="form-row">
                                <div class="form-group">
                                    <label>Количество в наличии:</label>
                                    <input type="number" name="in_stock_quantity" id="in_stock_quantity" value="0" required>
                                </div>
                                
                                <div class="form-group">
                                    <label>URL изображения:</label>
                                    <input type="url" name="image_url" id="image_url" placeholder="https://example.com/image.jpg">
                                </div>
                            </div>
                            
                            <div style="display: flex; gap: 1rem; margin-top: 1rem;">
                                <button type="submit" name="edit_product" class="btn btn-success" id="submitBtn">Сохранить</button>
                                <button type="button" class="btn btn-danger" onclick="closeModal()">Отмена</button>
                            </div>
                        </form>
                    </div>
                </div>

            <?php elseif ($current_section === 'orders'): ?>
                <!-- Управление заказами -->
                <div class="admin-section">
                    <h2 style="color: var(--primary-color); margin-bottom: 1rem;">Управление заказами</h2>
                    
                    <?php if (empty($orders)): ?>
                        <div class="no-data">
                            <h3>Заказы не найдены</h3>
                            <p>Заказы еще не созданы</p>
                        </div>
                    <?php else: ?>
                        <table class="admin-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Пользователь</th>
                                    <th>Сумма</th>
                                    <th>Статус</th>
                                    <th>Дата</th>
                                    <th>Действия</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($orders as $order): ?>
                                <tr>
                                    <td><?= Security::escape($order['id']) ?></td>
                                    <td><?= Security::escape($order['user_id']) ?></td>
                                    <td><?= Security::escape(number_format($order['total_amount'], 0, ',', ' ')) ?> ₽</td>
                                    <td>
                                        <span style="padding: 0.25rem 0.5rem; background: <?= $order['status'] === 'completed' ? '#28a745' : '#ffc107' ?>; color: white; border-radius: 4px;">
                                            <?= Security::escape($order['status']) ?>
                                        </span>
                                    </td>
                                    <td><?= isset($order['created_at']) ? Security::escape(date('d.m.Y H:i', strtotime($order['created_at']))) : '-' ?></td>
                                    <td>
                                        <a href="admin.php?section=orders&amp;view_order=<?= Security::escape($order['id']) ?>" class="btn">Просмотр</a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>

            <?php elseif ($current_section === 'users'): ?>
                <!-- Управление пользователями -->
                <div class="admin-section">
                    <h2 style="color: var(--primary-color); margin-bottom: 1rem;">Управление пользователями</h2>
                    
                    <?php if (empty($users)): ?>
                        <div class="no-data">
                            <h3>Пользователи не найдены</h3>
                        </div>
                    <?php else: ?>
                        <table class="admin-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Имя пользователя</th>
                                    <th>Email</th>
                                    <th>Роль</th>
                                    <th>Дата регистрации</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($users as $user): ?>
                                <tr>
                                    <td><?= Security::escape($user['id']) ?></td>
                                    <td><?= Security::escape($user['username']) ?></td>
                                    <td><?= Security::escape($user['email']) ?></td>
                                    <td>
                                        <span style="padding: 0.25rem 0.5rem; background: <?= $user['role'] === 'admin' ? '#000' : '#6c757d' ?>; color: white; border-radius: 4px;">
                                            <?= Security::escape($user['role'] ?? 'user') ?>
                                        </span>
                                    </td>
                                    <td><?= isset($user['created_at']) ? Security::escape(date('d.m.Y H:i', strtotime($user['created_at']))) : '-' ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </main>

    <script>
        // Mobile menu toggle
        document.querySelector('.mobile-menu-btn').addEventListener('click', function() {
            document.getElementById('main-nav').classList.toggle('active');
        });

        // Close mobile menu when clicking outside
        document.addEventListener('click', function(event) {
            const nav = document.getElementById('main-nav');
            const menuBtn = document.querySelector('.mobile-menu-btn');
            if (!nav.contains(event.target) && !menuBtn.contains(event.target)) {
                nav.classList.remove('active');
            }
        });

        function searchProducts() {
            const searchTerm = document.getElementById('searchInput').value;
            if (searchTerm.trim()) {
                // ЗАЩИТА: Кодируем параметры URL
                window.location.href = `catalog.php?search=${encodeURIComponent(searchTerm)}`;
            }
        }

        // Search on Enter key
        document.getElementById('searchInput').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                searchProducts();
            }
        });

        function openAddModal() {
            document.getElementById('modalTitle').textContent = 'Добавить товар';
            document.getElementById('productForm').reset();
            document.getElementById('product_id').value = '';
            document.getElementById('submitBtn').name = 'add_product';
            document.getElementById('submitBtn').textContent = 'Добавить товар';
            document.getElementById('productModal').style.display = 'block';
        }

        function closeModal() {
            document.getElementById('productModal').style.display = 'none';
        }

        window.onclick = function(event) {
            const modal = document.getElementById('productModal');
            if (event.target === modal) {
                closeModal();
            }
        }

        <?php if (isset($edit_product) && $edit_product): ?>
            document.addEventListener('DOMContentLoaded', function() {
                document.getElementById('modalTitle').textContent = 'Редактировать товар';
                document.getElementById('product_id').value = '<?= Security::escape($edit_product['id']) ?>';
                document.getElementById('name').value = '<?= Security::escape($edit_product['name']) ?>';
                document.getElementById('description').value = '<?= Security::escape($edit_product['description']) ?>';
                document.getElementById('price').value = '<?= Security::escape($edit_product['price']) ?>';
                document.getElementById('brand').value = '<?= Security::escape($edit_product['brand']) ?>';
                document.getElementById('in_stock_quantity').value = '<?= Security::escape($edit_product['in_stock_quantity']) ?>';
                document.getElementById('image_url').value = '<?= Security::escape($edit_product['image_url']) ?>';
                document.getElementById('submitBtn').name = 'edit_product';
                document.getElementById('submitBtn').textContent = 'Сохранить изменения';
                document.getElementById('productModal').style.display = 'block';
            });
        <?php endif; ?>
        
        // Функция для обновления счетчика корзины
        function updateCartCount(count) {
            const cartCountElement = document.getElementById('cartCount');
            cartCountElement.textContent = count;
            cartCountElement.classList.add('highlight');
            setTimeout(() => {
                cartCountElement.classList.remove('highlight');
            }, 300);
        }
        
        // Проверяем наличие параметра added_to_cart в URL для анимации
        if (window.location.search.includes('added_to_cart=1')) {
            const cartCount = document.getElementById('cartCount');
            cartCount.classList.add('highlight');
            setTimeout(() => {
                cartCount.classList.remove('highlight');
            }, 300);
        }
        
        // Периодически обновляем счетчик (на случай, если корзина изменилась в другой вкладке)
        setInterval(function() {
            fetch('get_cart_count.php')
                .then(response => response.json())
                .then(data => {
                    if (data.count !== undefined) {
                        document.getElementById('cartCount').textContent = data.count;
                    }
                })
                .catch(error => console.error('Error updating cart count:', error));
        }, 5000);
    </script>
</body>
</html>