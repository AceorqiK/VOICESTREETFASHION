<?php
session_start();
require_once 'includes/database.php';
require_once 'includes/config.php';

// Класс безопасности
class Security {
    public static function escape($data) {
        if (is_array($data)) {
            return array_map([self::class, 'escape'], $data);
        }
        return htmlspecialchars($data, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    }
    
    public static function validateInput($data, $type = 'string') {
        if ($data === null) return '';
        
        $data = trim($data);
        $data = stripslashes($data);
        
        switch ($type) {
            case 'email':
                $data = filter_var($data, FILTER_SANITIZE_EMAIL);
                return filter_var($data, FILTER_VALIDATE_EMAIL) ? $data : false;
            case 'int':
                return filter_var($data, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
            case 'text':
                return self::escape($data);
            default:
                return self::escape($data);
        }
    }
}

$db = new Database();
$connection = $db->getConnection();

// ЗАЩИТА: Проверяем, является ли пользователь администратором
$is_admin = false;
if(isset($_SESSION['user_id'])) {
    $user_id = Security::validateInput($_SESSION['user_id'], 'int');
    
    if ($user_id) {
        try {
            // ЗАЩИТА: Подготовленный запрос для проверки роли
            $stmt = $connection->prepare("SELECT role FROM users WHERE id = ?");
            $stmt->execute([$user_id]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($user && isset($user['role'])) {
                $is_admin = ($user['role'] === 'admin');
                $_SESSION['is_admin'] = $is_admin;
            } else {
                // Если колонки role нет, используем ID пользователя как fallback
                $is_admin = ($user_id == 1);
                $_SESSION['is_admin'] = $is_admin;
            }
        } catch (PDOException $e) {
            // Если произошла ошибка (колонка role не существует), используем fallback
            error_log("Ошибка проверки роли: " . $e->getMessage());
            $is_admin = ($user_id == 1); // ID 1 = администратор
            $_SESSION['is_admin'] = $is_admin;
        }
    }
}

// Обработка AJAX запроса на добавление в корзину
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_to_cart') {
    header('Content-Type: application/json');
    
    if (!isset($_SESSION['user_id'])) {
        echo json_encode(['success' => false, 'message' => 'Необходимо авторизоваться']);
        exit;
    }
    
    $product_id = isset($_POST['product_id']) ? (int)$_POST['product_id'] : 0;
    $size = isset($_POST['size']) ? trim($_POST['size']) : '';
    
    if (!$product_id || !$size) {
        echo json_encode(['success' => false, 'message' => 'Не выбраны параметры товара']);
        exit;
    }
    
    try {
        // Проверяем существование товара
        $stmt = $connection->prepare("SELECT id, name, price, in_stock_quantity FROM products WHERE id = ?");
        $stmt->execute([$product_id]);
        $product = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$product) {
            echo json_encode(['success' => false, 'message' => 'Товар не найден']);
            exit;
        }
        
        // Проверяем, есть ли уже такой товар в корзине
        $stmt = $connection->prepare("SELECT id, quantity FROM cart WHERE user_id = ? AND product_id = ? AND size = ?");
        $stmt->execute([$_SESSION['user_id'], $product_id, $size]);
        $existing_item = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($existing_item) {
            // Обновляем количество
            $new_quantity = $existing_item['quantity'] + 1;
            $stmt = $connection->prepare("UPDATE cart SET quantity = ? WHERE id = ?");
            $stmt->execute([$new_quantity, $existing_item['id']]);
        } else {
            // Добавляем новый товар
            $stmt = $connection->prepare("INSERT INTO cart (user_id, product_id, quantity, size, created_at) VALUES (?, ?, 1, ?, NOW())");
            $stmt->execute([$_SESSION['user_id'], $product_id, $size]);
        }
        
        // Получаем общее количество товаров в корзине
        $stmt = $connection->prepare("SELECT SUM(quantity) as total FROM cart WHERE user_id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        $cart_total = $result['total'] ?? 0;
        
        echo json_encode([
            'success' => true, 
            'message' => 'Товар добавлен в корзину',
            'cart_count' => $cart_total
        ]);
        exit;
        
    } catch (PDOException $e) {
        error_log("Ошибка добавления в корзину: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Ошибка при добавлении в корзину: ' . $e->getMessage()]);
        exit;
    }
}

// Получаем количество товаров в корзине для отображения в шапке
$cart_count = 0;
if (isset($_SESSION['user_id'])) {
    try {
        $stmt = $connection->prepare("SELECT SUM(quantity) as total FROM cart WHERE user_id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        $cart_count = $result['total'] ?? 0;
    } catch (PDOException $e) {
        error_log("Ошибка получения количества товаров в корзине: " . $e->getMessage());
    }
}

// ЗАЩИТА: Получение и валидация параметров
$brand = isset($_GET['brand']) ? Security::validateInput($_GET['brand']) : '';
$search = isset($_GET['search']) ? Security::validateInput($_GET['search']) : '';
$page = isset($_GET['page']) ? Security::validateInput($_GET['page'], 'int') : 1;
if ($page < 1) $page = 1;

$per_page = 12;
$offset = ($page - 1) * $per_page;

// ЗАЩИТА: Построение безопасного запроса
$query = "SELECT * FROM products WHERE 1=1";
$count_query = "SELECT COUNT(*) FROM products WHERE 1=1";
$params = [];
$count_params = [];

if ($brand) {
    $query .= " AND brand = ?";
    $count_query .= " AND brand = ?";
    $params[] = $brand;
    $count_params[] = $brand;
}

if ($search) {
    $query .= " AND (name LIKE ? OR description LIKE ?)";
    $count_query .= " AND (name LIKE ? OR description LIKE ?)";
    $searchTerm = "%$search%";
    $params[] = $searchTerm;
    $params[] = $searchTerm;
    $count_params[] = $searchTerm;
    $count_params[] = $searchTerm;
}

// ЗАЩИТА: Получаем общее количество товаров с подготовленным запросом
try {
    $stmt = $connection->prepare($count_query);
    $stmt->execute($count_params);
    $total_products = $stmt->fetchColumn();
} catch (PDOException $e) {
    error_log("Ошибка подсчета товаров: " . $e->getMessage());
    $total_products = 0;
}

// Вычисляем общее количество страниц
$total_pages = ceil($total_products / $per_page);
if ($total_pages < 1) $total_pages = 1;
if ($page > $total_pages) $page = $total_pages;

// ЗАЩИТА: Добавляем лимит и сортировку (безопасные значения)
$query .= " ORDER BY created_at DESC LIMIT ? OFFSET ?";
$params[] = $per_page;
$params[] = $offset;

// ЗАЩИТА: Получаем товары с подготовленным запросом
try {
    $stmt = $connection->prepare($query);
    $stmt->execute($params);
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Ошибка получения товаров: " . $e->getMessage());
    $products = [];
}

// ЗАЩИТА: Получение брендов для фильтра
try {
    $brands_stmt = $connection->prepare("SELECT DISTINCT brand FROM products WHERE brand IS NOT NULL ORDER BY brand");
    $brands_stmt->execute();
    $brands = $brands_stmt->fetchAll(PDO::FETCH_COLUMN);
} catch (PDOException $e) {
    error_log("Ошибка получения брендов: " . $e->getMessage());
    $brands = [];
}

// Безопасное значение для поиска в форме
$search_value = isset($_GET['search']) ? Security::escape($_GET['search']) : '';
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- ЗАЩИТА ОТ XSS: экранируем вывод -->
    <title>Каталог обуви - <?= Security::escape(SITE_NAME) ?></title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #000;
            --secondary-color: #111;
            --accent-color: #555;
            --light-color: #eee;
            --text-color: #333;
            --success-color: #28a745;
            --border-color: #ddd;
            --admin-color: #dc3545;
        }
        
        /* Header Styles - Full Width */
        header {
            background: white;
            box-shadow: 0 2px 20px rgba(0,0,0,0.1);
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            padding: 0.5rem 0;
            width: 100%;
        }
        
        .header-full-width {
            max-width: 100%;
            margin: 0;
            padding: 0 2rem;
        }
        
        .header-container {
            display: flex;
            align-items: center;
            justify-content: space-between;
            width: 100%;
            gap: 3rem;
        }
        
        .logo {
            display: flex;
            flex-direction: column;
            align-items: flex-start;
            min-width: 200px;
        }
        
        .logo h1 {
            color: var(--primary-color) !important;
            font-size: 1.8rem;
            font-weight: bold;
            margin: 0;
            line-height: 1;
            white-space: nowrap;
        }
        
        .logo span {
            color: var(--secondary-color);
            font-size: 0.8rem;
            margin-top: 2px;
        }
        
        nav {
            flex: 1;
            display: flex;
            justify-content: center;
            margin: 0 2rem;
        }
        
        nav ul {
            display: flex;
            list-style: none;
            margin: 0;
            padding: 0;
            gap: 2rem;
        }
        
        nav a {
            text-decoration: none;
            color: var(--text-color);
            font-weight: 500;
            font-size: 1rem;
            transition: color 0.3s;
            position: relative;
            white-space: nowrap;
            padding: 0.5rem 0;
        }
        
        nav a:hover {
            color: var(--primary-color);
        }
        
        nav a::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 0;
            height: 2px;
            background: var(--primary-color);
            transition: width 0.3s;
        }
        
        nav a:hover::after {
            width: 100%;
        }
        
        .admin-link {
            color: var(--admin-color) !important;
            font-weight: 600 !important;
        }
        
        .admin-link:hover {
            color: var(--admin-color) !important;
        }
        
        .admin-link::after {
            background: var(--admin-color) !important;
        }
        
        .header-actions {
            display: flex;
            align-items: center;
            gap: 1rem;
            min-width: 300px;
            justify-content: flex-end;
        }
        
        .search-box {
            display: flex;
            background: var(--light-color);
            border-radius: 25px;
            padding: 0.4rem;
            border: 2px solid transparent;
            transition: border-color 0.3s;
            min-width: 250px;
            margin-right: 1rem;
        }
        
        .search-box:focus-within {
            border-color: var(--primary-color);
        }
        
        .search-box input {
            border: none;
            background: none;
            outline: none;
            padding: 0 1rem;
            width: 100%;
            font-size: 0.9rem;
        }
        
        .search-box button {
            background: var(--primary-color);
            color: white;
            border: none;
            padding: 0.4rem 1rem;
            border-radius: 20px;
            cursor: pointer;
            font-size: 0.9rem;
            transition: background 0.3s;
            white-space: nowrap;
        }
        
        .search-box button:hover {
            background: var(--secondary-color);
        }
        
        .cart-link {
            display: flex;
            align-items: center;
            text-decoration: none;
            color: var(--text-color);
            transition: color 0.3s;
            padding: 0.5rem;
            position: relative;
            background: none !important;
        }
        
        .cart-link:hover {
            color: var(--primary-color);
        }
        
        .cart-icon {
            width: 24px;
            height: 24px;
        }
        
        .cart-count {
            background: var(--accent-color);
            color: white;
            border-radius: 50%;
            width: 18px;
            height: 18px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.7rem;
            position: absolute;
            top: 2px;
            right: 2px;
            font-weight: bold;
        }

        /* Mobile menu button */
        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            font-size: 1.5rem;
            color: var(--text-color);
            cursor: pointer;
        }

        /* Main content margin for fixed header */
        main {
            margin-top: 80px;
        }

        /* Responsive */
        @media (max-width: 1200px) {
            .header-full-width {
                padding: 0 1.5rem;
            }
            
            .header-container {
                gap: 2rem;
            }
            
            nav ul {
                gap: 1.5rem;
            }
            
            .header-actions {
                min-width: 250px;
            }
            
            .search-box {
                min-width: 200px;
            }
        }

        @media (max-width: 992px) {
            .header-container {
                gap: 1.5rem;
            }
            
            nav {
                margin: 0 1rem;
            }
            
            nav ul {
                gap: 1rem;
            }
            
            .header-actions {
                min-width: 200px;
            }
            
            .search-box {
                min-width: 180px;
                margin-right: 0.5rem;
            }
        }

        @media (max-width: 768px) {
            .header-container {
                flex-wrap: wrap;
                gap: 1rem;
            }
            
            .mobile-menu-btn {
                display: block;
            }
            
            nav {
                order: 3;
                display: none;
                width: 100%;
                margin: 0;
            }
            
            nav.active {
                display: block;
            }
            
            nav ul {
                flex-direction: column;
                gap: 0.5rem;
                padding: 1rem 0;
            }
            
            .header-actions {
                min-width: auto;
                gap: 0.5rem;
            }
            
            .search-box {
                min-width: 150px;
            }
            
            .logo {
                min-width: auto;
            }
            
            .logo h1 {
                font-size: 1.5rem;
            }
            
            .cart-link {
                padding: 0.3rem;
            }
        }

        @media (max-width: 480px) {
            .header-full-width {
                padding: 0 1rem;
            }
            
            .search-box {
                min-width: 120px;
            }
            
            .cart-link {
                padding: 0.2rem;
            }
        }

        /* Catalog Styles */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #fff;
            color: var(--text-color);
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }
        
        .catalog-layout {
            display: grid;
            grid-template-columns: 200px 1fr;
            gap: 20px;
            margin-top: 20px;
        }
        
        @media (max-width: 768px) {
            .catalog-layout {
                grid-template-columns: 1fr;
            }
        }
        
        .filters {
            background: #fff;
            padding: 15px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        .filters h3 {
            margin-top: 0;
            font-size: 18px;
            color: var(--primary-color);
            border-bottom: 1px solid var(--border-color);
            padding-bottom: 10px;
        }
        
        .brand-option {
            padding: 8px 10px;
            margin-bottom: 5px;
            cursor: pointer;
            border-radius: 3px;
            transition: background-color 0.2s;
            color: var(--text-color);
        }
        
        .brand-option:hover {
            background-color: var(--light-color);
        }
        
        .brand-option.active {
            background-color: var(--primary-color);
            color: white !important;
            font-weight: 500;
        }
        
        .products-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 20px;
        }
        
        .product-card {
            background: #fff;
            border-radius: 5px;
            overflow: hidden;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            transition: transform 0.3s, box-shadow 0.3s;
            cursor: pointer;
        }
        
        .product-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .product-image {
            position: relative;
            height: 200px;
            overflow: hidden;
        }
        
        .product-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .product-status {
            position: absolute;
            top: 10px;
            right: 10px;
            background: var(--primary-color);
            color: white;
            padding: 3px 8px;
            border-radius: 3px;
            font-size: 12px;
            font-weight: bold;
        }
        
        .product-info {
            padding: 15px;
        }
        
        .product-info h3 {
            margin: 0 0 10px 0;
            font-size: 16px;
            font-weight: normal;
            line-height: 1.3;
        }
        
        .product-price {
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 8px;
        }
        
        .product-delivery {
            color: var(--accent-color);
            font-size: 14px;
            margin-bottom: 10px;
        }
        
        .product-meta {
            display: flex;
            justify-content: space-between;
            font-size: 12px;
            color: var(--accent-color);
            margin-bottom: 15px;
        }
        
        .btn {
            background: var(--primary-color);
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 3px;
            cursor: pointer;
            width: 100%;
            font-size: 14px;
            transition: background-color 0.3s;
        }
        
        .btn:hover {
            background: var(--secondary-color);
        }
        
        .btn:disabled {
            background: var(--accent-color);
            cursor: not-allowed;
        }
        
        .pagination {
            display: flex;
            justify-content: center;
            margin-top: 30px;
            gap: 5px;
        }
        
        .pagination a, .pagination span {
            padding: 8px 12px;
            border: 1px solid var(--border-color);
            border-radius: 3px;
            text-decoration: none;
            color: var(--text-color);
        }
        
        .pagination a:hover {
            background: var(--light-color);
        }
        
        .pagination .active {
            background: var(--primary-color);
            color: white;
            border-color: var(--primary-color);
        }
        
        .catalog-header {
            margin-bottom: 20px;
        }
        
        .catalog-header h1 {
            margin: 0 0 5px 0;
            font-size: 24px;
        }
        
        .selected-brand-display {
            background: var(--light-color);
            padding: 10px 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .selected-brand-display button {
            background: none;
            border: 1px solid var(--accent-color);
            color: var(--accent-color);
            padding: 5px 10px;
            border-radius: 3px;
            cursor: pointer;
        }
        
        /* Modal Styles */
        .size-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
            z-index: 2000;
            justify-content: center;
            align-items: center;
        }
        
        .size-modal.active {
            display: flex;
        }
        
        .modal-content {
            background: white;
            padding: 30px;
            border-radius: 10px;
            max-width: 400px;
            width: 90%;
            position: relative;
            animation: modalSlideIn 0.3s ease;
        }
        
        @keyframes modalSlideIn {
            from {
                transform: translateY(-50px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }
        
        .modal-content h2 {
            margin: 0 0 15px 0;
            color: var(--primary-color);
        }
        
        .modal-content p {
            margin-bottom: 20px;
            color: var(--accent-color);
        }
        
        .size-options {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(60px, 1fr));
            gap: 10px;
            margin-bottom: 20px;
        }
        
        .size-option {
            padding: 10px;
            border: 2px solid var(--border-color);
            border-radius: 5px;
            text-align: center;
            cursor: pointer;
            transition: all 0.2s;
        }
        
        .size-option:hover {
            border-color: var(--primary-color);
        }
        
        .size-option.selected {
            background: var(--primary-color);
            color: white;
            border-color: var(--primary-color);
        }
        
        .modal-buttons {
            display: flex;
            gap: 10px;
        }
        
        .modal-buttons button {
            flex: 1;
            padding: 12px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: all 0.2s;
        }
        
        .modal-buttons .confirm-btn {
            background: var(--primary-color);
            color: white;
        }
        
        .modal-buttons .confirm-btn:hover {
            background: var(--secondary-color);
        }
        
        .modal-buttons .cancel-btn {
            background: var(--light-color);
            color: var(--text-color);
        }
        
        .modal-buttons .cancel-btn:hover {
            background: var(--border-color);
        }
        
        .close-modal {
            position: absolute;
            top: 15px;
            right: 15px;
            background: none;
            border: none;
            font-size: 24px;
            cursor: pointer;
            color: var(--accent-color);
        }
        
        .close-modal:hover {
            color: var(--primary-color);
        }
        
        /* Notification */
        .notification {
            position: fixed;
            top: 100px;
            right: 20px;
            background: white;
            border-left: 4px solid var(--success-color);
            color: var(--text-color);
            padding: 15px 25px;
            border-radius: 5px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            z-index: 3000;
            animation: notificationSlide 0.3s ease;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .notification.error {
            border-left-color: var(--admin-color);
        }
        
        .notification i {
            color: var(--success-color);
            font-size: 20px;
        }
        
        .notification.error i {
            color: var(--admin-color);
        }
        
        @keyframes notificationSlide {
            from {
                transform: translateX(100px);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
        
        /* Loading spinner */
        .spinner {
            display: inline-block;
            width: 16px;
            height: 16px;
            border: 2px solid rgba(255,255,255,0.3);
            border-top-color: white;
            border-radius: 50%;
            animation: spin 0.8s linear infinite;
        }
        
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
    </style>
</head>
<body>
    <!-- Header - Full Width -->
    <header>
        <div class="header-full-width">
            <div class="header-container">
                <button class="mobile-menu-btn">
                    <i class="fas fa-bars"></i>
                </button>
                
                <div class="logo">
                    <h1><?= Security::escape(SITE_NAME) ?></h1>
                </div>
                
                <nav id="main-nav">
                    <ul>
                        <li><a href="index.php">Главная</a></li>
                        <li><a href="catalog.php" style="color: var(--primary-color);">Обувь</a></li>
                        <li><a href="feedback.php">Обратная связь</a></li>
                        <?php if(isset($_SESSION['user_id'])): ?>
                            <?php if($is_admin): ?>
                                <li><a href="admin.php" class="admin-link">Админ панель</a></li>
                            <?php endif; ?>
                            <li><a href="profile.php">Личный кабинет</a></li>
                            <li><a href="logout.php">Выйти</a></li>
                        <?php else: ?>
                            <li><a href="login.php">Войти</a></li>
                            <li><a href="register.php">Регистрация</a></li>
                        <?php endif; ?>
                    </ul>
                </nav>
                
                <div class="header-actions">
                    <div class="search-box">
                        <input type="text" id="searchInput" placeholder="Поиск товаров..." value="<?= $search_value ?>">
                        <button onclick="searchProducts()">
                            <i class="fas fa-search"></i>
                        </button>
                    </div>
                    
                    <a href="cart.php" class="cart-link">
                        <svg class="cart-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path>
                            <line x1="3" y1="6" x2="21" y2="6"></line>
                            <path d="M16 10a4 4 0 0 1-8 0"></path>
                        </svg>
                        <span class="cart-count"><?= Security::escape($cart_count) ?></span>
                    </a>
                </div>
            </div>
        </div>
    </header>
    
    <!-- Modal for size selection -->
    <div class="size-modal" id="sizeModal">
        <div class="modal-content">
            <button class="close-modal" onclick="closeSizeModal()">&times;</button>
            <h2 id="modalProductName">Выберите размер</h2>
            <p id="modalProductPrice"></p>
            <div class="size-options" id="sizeOptions">
                <!-- Size options will be dynamically inserted here -->
            </div>
            <div class="modal-buttons">
                <button class="confirm-btn" onclick="confirmAddToCart()">Добавить в корзину</button>
                <button class="cancel-btn" onclick="closeSizeModal()">Отмена</button>
            </div>
        </div>
    </div>
    
    <main>
        <div class="container">
            <div class="catalog-layout">
                <!-- Фильтры по брендам - ВЕРНУЛ КАК БЫЛО -->
                <aside class="filters">
                    <h3>Бренды</h3>
                    <div>
                        <div onclick="clearBrandFilter()"
                             style="padding: 8px 10px; margin-bottom: 5px; cursor: pointer; border-radius: 3px; background-color: <?= !$brand ? '#000000' : 'transparent' ?>; color: <?= !$brand ? '#ffffff' : '#333' ?>; font-weight: <?= !$brand ? '500' : 'normal' ?>;">
                            Все бренды
                        </div>
                        <?php foreach ($brands as $brand_option): ?>
                            <div onclick="selectBrand('<?= Security::escape($brand_option) ?>')"
                                 style="padding: 8px 10px; margin-bottom: 5px; cursor: pointer; border-radius: 3px; background-color: <?= $brand == $brand_option ? '#000000' : 'transparent' ?>; color: <?= $brand == $brand_option ? '#ffffff' : '#333' ?>; font-weight: <?= $brand == $brand_option ? '500' : 'normal' ?>;">
                                <?= Security::escape($brand_option) ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </aside>

                <!-- Товары -->
                <section class="products">
                    <div class="catalog-header">
                        <h1>Каталог обуви</h1>
                        <div>
                            Найдено товаров: <?= Security::escape($total_products) ?>
                            <?php if ($brand): ?>
                                • Бренд: <strong><?= Security::escape($brand) ?></strong>
                            <?php endif; ?>
                        </div>
                    </div>

                    <?php if ($brand): ?>
                        <div class="selected-brand-display">
                            <span>Показаны товары бренда: <strong><?= Security::escape($brand) ?></strong></span>
                            <button onclick="clearBrandFilter()">
                                ✕ Сбросить
                            </button>
                        </div>
                    <?php endif; ?>
                    
                    <div class="products-grid">
                        <?php if (!empty($products)): ?>
                            <?php foreach ($products as $product): ?>
                                <div class="product-card" onclick="window.location.href='product.php?id=<?= Security::escape($product['id']) ?>'">
                                    <div class="product-image">
                                        <img src="<?= Security::escape($product['image_url']) ?>" alt="<?= Security::escape($product['name']) ?>">
                                        <?php if ($product['in_stock_quantity'] == 0): ?>
                                            <div class="product-status">ПОД ЗАКАЗ</div>
                                        <?php else: ?>
                                            <div class="product-status" style="background: var(--success-color);">В НАЛИЧИИ</div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="product-info">
                                        <h3><?= Security::escape($product['name']) ?></h3>
                                        <div class="product-price"><?= Security::escape(number_format($product['price'], 0, ',', ' ')) ?> ₽</div>
                                        <div class="product-delivery">
                                            <?php if ($product['in_stock_quantity'] > 0): ?>
                                                Доставка: Сегодня или завтра
                                            <?php else: ?>
                                                21 день • ♦ 13 дней
                                            <?php endif; ?>
                                        </div>
                                        <div class="product-meta">
                                            <span><?= Security::escape($product['brand']) ?></span>
                                            <span><?= $product['in_stock_quantity'] > 0 ? 'В наличии' : 'Под заказ' ?></span>
                                        </div>
                                        <button class="btn add-to-cart-btn" 
                                                onclick="event.stopPropagation(); openSizeModal(<?= Security::escape($product['id']) ?>, '<?= Security::escape(addslashes($product['name'])) ?>', <?= Security::escape($product['price']) ?>)"
                                                data-product-id="<?= Security::escape($product['id']) ?>">
                                            В корзину
                                        </button>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div style="text-align: center; padding: 40px; grid-column: 1 / -1;">
                                <h3>Товары не найдены</h3>
                                <p>Попробуйте выбрать другой бренд или изменить поисковый запрос</p>
                                <button onclick="clearBrandFilter()" class="btn" style="width: auto; display: inline-block; padding: 10px 20px;">Показать все товары</button>
                            </div>
                        <?php endif; ?>
                    </div>

                    <!-- Пагинация -->
                    <?php if ($total_pages > 1): ?>
                    <div class="pagination">
                        <?php if ($page > 1): ?>
                            <a href="?<?= Security::escape(http_build_query(array_merge($_GET, ['page' => $page - 1]))) ?>">
                                ← Назад
                            </a>
                        <?php endif; ?>
                        
                        <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                            <?php if ($i == 1 || $i == $total_pages || ($i >= $page - 2 && $i <= $page + 2)): ?>
                                <a href="?<?= Security::escape(http_build_query(array_merge($_GET, ['page' => $i]))) ?>" 
                                   class="<?= $i == $page ? 'active' : '' ?>">
                                    <?= Security::escape($i) ?>
                                </a>
                            <?php elseif ($i == $page - 3 || $i == $page + 3): ?>
                                <span>...</span>
                            <?php endif; ?>
                        <?php endfor; ?>
                        
                        <?php if ($page < $total_pages): ?>
                            <a href="?<?= Security::escape(http_build_query(array_merge($_GET, ['page' => $page + 1]))) ?>">
                                Вперед →
                            </a>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                </section>
            </div>
        </div>
    </main>

    <?php include 'includes/footer.php'; ?>

    <script>
        // Mobile menu toggle
        document.querySelector('.mobile-menu-btn').addEventListener('click', function() {
            document.getElementById('main-nav').classList.toggle('active');
        });

        // Close mobile menu when clicking outside
        document.addEventListener('click', function(event) {
            const nav = document.getElementById('main-nav');
            const menuBtn = document.querySelector('.mobile-menu-btn');
            if (!nav.contains(event.target) && !menuBtn.contains(event.target)) {
                nav.classList.remove('active');
            }
        });

        function selectBrand(brand) {
            const url = new URL(window.location);
            url.searchParams.set('brand', brand);
            url.searchParams.delete('page');
            window.location.href = url.toString();
        }

        function clearBrandFilter() {
            const url = new URL(window.location);
            url.searchParams.delete('brand');
            url.searchParams.delete('page');
            window.location.href = url.toString();
        }

        function searchProducts() {
            const searchTerm = document.getElementById('searchInput').value;
            if (searchTerm.trim()) {
                const url = new URL(window.location);
                url.searchParams.set('search', searchTerm);
                url.searchParams.delete('page');
                window.location.href = url.toString();
            }
        }

        // Search on Enter key
        document.getElementById('searchInput').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                searchProducts();
            }
        });

        // Cart functionality
        let currentProductId = null;
        let selectedSize = null;

        // Available sizes
        const availableSizes = [36, 37, 38, 39, 40, 41, 42, 43, 44, 45];

        function openSizeModal(productId, productName, productPrice) {
            currentProductId = productId;
            selectedSize = null;
            
            document.getElementById('modalProductName').textContent = productName;
            document.getElementById('modalProductPrice').textContent = productPrice + ' ₽';
            
            // Generate size options
            const sizeOptions = document.getElementById('sizeOptions');
            sizeOptions.innerHTML = '';
            
            availableSizes.forEach(size => {
                const sizeDiv = document.createElement('div');
                sizeDiv.className = 'size-option';
                sizeDiv.textContent = size;
                sizeDiv.onclick = function() {
                    // Remove selected class from all options
                    document.querySelectorAll('.size-option').forEach(opt => {
                        opt.classList.remove('selected');
                    });
                    // Add selected class to this option
                    this.classList.add('selected');
                    selectedSize = this.textContent;
                };
                sizeOptions.appendChild(sizeDiv);
            });
            
            document.getElementById('sizeModal').classList.add('active');
        }

        function closeSizeModal() {
            document.getElementById('sizeModal').classList.remove('active');
            currentProductId = null;
            selectedSize = null;
        }

        function showNotification(message, isError = false) {
            const notification = document.createElement('div');
            notification.className = 'notification' + (isError ? ' error' : '');
            notification.innerHTML = `
                <i class="fas ${isError ? 'fa-exclamation-circle' : 'fa-check-circle'}"></i>
                <span>${message}</span>
            `;
            
            document.body.appendChild(notification);
            
            setTimeout(() => {
                notification.remove();
            }, 3000);
        }

        async function confirmAddToCart() {
            if (!selectedSize) {
                showNotification('Пожалуйста, выберите размер', true);
                return;
            }

            if (!currentProductId) {
                showNotification('Ошибка: товар не выбран', true);
                return;
            }

            // Проверяем авторизацию
            <?php if (!isset($_SESSION['user_id'])): ?>
            showNotification('Необходимо авторизоваться', true);
            setTimeout(() => {
                window.location.href = 'login.php';
            }, 2000);
            return;
            <?php endif; ?>

            // Disable the confirm button and show loading
            const confirmBtn = document.querySelector('.confirm-btn');
            const originalText = confirmBtn.textContent;
            confirmBtn.innerHTML = '<span class="spinner"></span> Добавление...';
            confirmBtn.disabled = true;

            try {
                const formData = new FormData();
                formData.append('action', 'add_to_cart');
                formData.append('product_id', currentProductId);
                formData.append('size', selectedSize);

                const response = await fetch(window.location.href, {
                    method: 'POST',
                    body: formData
                });

                const data = await response.json();

                if (data.success) {
                    showNotification('Товар успешно добавлен в корзину!');
                    // Update cart count in header
                    document.querySelector('.cart-count').textContent = data.cart_count;
                    closeSizeModal();
                } else {
                    showNotification(data.message || 'Ошибка при добавлении в корзину', true);
                }
            } catch (error) {
                console.error('Error:', error);
                showNotification('Ошибка при добавлении в корзину', true);
            } finally {
                // Restore button
                confirmBtn.innerHTML = originalText;
                confirmBtn.disabled = false;
            }
        }

        // Close modal when clicking outside
        document.getElementById('sizeModal').addEventListener('click', function(e) {
            if (e.target === this) {
                closeSizeModal();
            }
        });

        // Close modal on Escape key
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape' && document.getElementById('sizeModal').classList.contains('active')) {
                closeSizeModal();
            }
        });
    </script>
</body>
</html>