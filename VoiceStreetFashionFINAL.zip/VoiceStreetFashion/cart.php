<?php
session_start();
require_once 'includes/database.php';
require_once 'includes/config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$db = new Database();
$connection = $db->getConnection();

// Проверяем, является ли пользователь администратором
$is_admin = false;
if(isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $stmt = $connection->prepare("SELECT role FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($user) {
        $is_admin = ($user['role'] === 'admin');
        $_SESSION['is_admin'] = $is_admin;
    }
}

// Получаем товары в корзине пользователя
$stmt = $connection->prepare("
    SELECT c.*, p.name, p.price, p.image_url, p.brand 
    FROM cart c 
    JOIN products p ON c.product_id = p.id 
    WHERE c.user_id = ?
");
$stmt->execute([$_SESSION['user_id']]);
$cart_items = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Обновление количества
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_POST['checkout'])) {
    if (isset($_POST['update_quantity'])) {
        $cart_id = $_POST['cart_id'];
        $quantity = intval($_POST['quantity']);
        
        if ($quantity <= 0) {
            // Удаляем товар если количество 0
            $stmt = $connection->prepare("DELETE FROM cart WHERE id = ? AND user_id = ?");
            $stmt->execute([$cart_id, $_SESSION['user_id']]);
            $_SESSION['cart_success'] = 'Товар удален из корзины';
        } else {
            $stmt = $connection->prepare("UPDATE cart SET quantity = ? WHERE id = ? AND user_id = ?");
            $stmt->execute([$quantity, $cart_id, $_SESSION['user_id']]);
            $_SESSION['cart_success'] = 'Количество обновлено';
        }
        
        header("Location: cart.php");
        exit;
    }
    
    // Удаление товара
    if (isset($_POST['remove_item'])) {
        $cart_id = $_POST['cart_id'];
        $stmt = $connection->prepare("DELETE FROM cart WHERE id = ? AND user_id = ?");
        $stmt->execute([$cart_id, $_SESSION['user_id']]);
        $_SESSION['cart_success'] = 'Товар удален из корзины';
        
        header("Location: cart.php");
        exit;
    }
}

// Расчет общей суммы
$total_amount = 0;
foreach ($cart_items as $item) {
    $total_amount += $item['price'] * $item['quantity'];
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Корзина - <?= SITE_NAME ?></title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #000;
            --secondary-color: #111;
            --accent-color: #555;
            --light-color: #eee;
            --text-color: #333;
            --success-color: #28a745;
            --border-color: #ddd;
            --admin-color: #dc3545;
            --card-shadow: 0 10px 30px -10px rgba(0,0,0,0.1);
            --hover-shadow: 0 20px 40px -15px rgba(0,0,0,0.2);
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #fff 0%, #fafafa 100%);
            color: var(--text-color);
            min-height: 100vh;
        }
        
        /* Header Styles - Original */
        header {
            background: white;
            box-shadow: 0 2px 20px rgba(0,0,0,0.1);
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            padding: 0.5rem 0;
            width: 100%;
        }
        
        .header-full-width {
            max-width: 100%;
            margin: 0;
            padding: 0 2rem;
        }
        
        .header-container {
            display: flex;
            align-items: center;
            justify-content: space-between;
            width: 100%;
            gap: 3rem;
        }
        
        .logo {
            display: flex;
            flex-direction: column;
            align-items: flex-start;
            min-width: 200px;
        }
        
        .logo h1 {
            color: var(--primary-color) !important;
            font-size: 1.8rem;
            font-weight: bold;
            margin: 0;
            line-height: 1;
            white-space: nowrap;
        }
        
        .logo span {
            color: var(--secondary-color);
            font-size: 0.8rem;
            margin-top: 2px;
        }
        
        nav {
            flex: 1;
            display: flex;
            justify-content: center;
            margin: 0 2rem;
        }
        
        nav ul {
            display: flex;
            list-style: none;
            margin: 0;
            padding: 0;
            gap: 2rem;
        }
        
        nav a {
            text-decoration: none;
            color: var(--text-color);
            font-weight: 500;
            font-size: 1rem;
            transition: color 0.3s;
            position: relative;
            white-space: nowrap;
            padding: 0.5rem 0;
        }
        
        nav a:hover {
            color: var(--primary-color);
        }
        
        nav a::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 0;
            height: 2px;
            background: var(--primary-color);
            transition: width 0.3s;
        }
        
        nav a:hover::after {
            width: 100%;
        }
        
        .admin-link {
            color: var(--admin-color) !important;
            font-weight: 600 !important;
        }
        
        .admin-link:hover {
            color: var(--admin-color) !important;
        }
        
        .admin-link::after {
            background: var(--admin-color) !important;
        }
        
        .header-actions {
            display: flex;
            align-items: center;
            gap: 1rem;
            min-width: 300px;
            justify-content: flex-end;
        }
        
        .search-box {
            display: flex;
            background: var(--light-color);
            border-radius: 25px;
            padding: 0.4rem;
            border: 2px solid transparent;
            transition: border-color 0.3s;
            min-width: 250px;
            margin-right: 1rem;
        }
        
        .search-box:focus-within {
            border-color: var(--primary-color);
        }
        
        .search-box input {
            border: none;
            background: none;
            outline: none;
            padding: 0 1rem;
            width: 100%;
            font-size: 0.9rem;
        }
        
        .search-box button {
            background: var(--primary-color);
            color: white;
            border: none;
            padding: 0.4rem 1rem;
            border-radius: 20px;
            cursor: pointer;
            font-size: 0.9rem;
            transition: background 0.3s;
            white-space: nowrap;
        }
        
        .search-box button:hover {
            background: var(--secondary-color);
        }
        
        .cart-link {
            display: flex;
            align-items: center;
            text-decoration: none;
            color: var(--text-color);
            transition: color 0.3s;
            padding: 0.5rem;
            position: relative;
            background: none !important;
        }
        
        .cart-link:hover {
            color: var(--primary-color);
        }
        
        .cart-icon {
            width: 24px;
            height: 24px;
        }
        
        .cart-count {
            background: var(--accent-color);
            color: white;
            border-radius: 50%;
            width: 18px;
            height: 18px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.7rem;
            position: absolute;
            top: 2px;
            right: 2px;
            font-weight: bold;
        }

        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            font-size: 1.5rem;
            color: var(--text-color);
            cursor: pointer;
        }

        /* Main Content */
        .cart-container {
            max-width: 1200px;
            margin: 100px auto 3rem;
            padding: 0 2rem;
        }
        
        .cart-title {
            font-size: 2.5rem;
            font-weight: 800;
            color: var(--primary-color);
            margin-bottom: 2rem;
            text-align: center;
            position: relative;
            letter-spacing: -0.5px;
        }
        
        .cart-title::after {
            content: '';
            display: block;
            width: 80px;
            height: 3px;
            background: var(--primary-color);
            margin: 1rem auto 0;
        }
        
        /* Cart Layout */
        .cart-layout {
            display: grid;
            grid-template-columns: 1fr 380px;
            gap: 2rem;
            align-items: start;
        }
        
        /* Cart Items - Обновленный дизайн */
        .cart-items {
            display: flex;
            flex-direction: column;
            gap: 1.5rem;
        }

        .cart-item {
            background: #ffffff;
            border: none;
            border-radius: 24px;
            padding: 2rem;
            display: flex;
            gap: 2.5rem;
            transition: all 0.4s cubic-bezier(0.165, 0.84, 0.44, 1);
            animation: slideIn 0.5s ease forwards;
            opacity: 0;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            position: relative;
            overflow: hidden;
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .cart-item::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 4px;
            height: 100%;
            background: linear-gradient(135deg, #000 0%, #333 100%);
            opacity: 0;
            transition: opacity 0.3s ease;
        }

        .cart-item:hover {
            transform: translateY(-6px) scale(1.02);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.12);
        }

        .cart-item:hover::before {
            opacity: 1;
        }

        .cart-item-image-wrapper {
            width: 200px;
            height: 200px;
            flex-shrink: 0;
            border-radius: 20px;
            overflow: hidden;
            border: 2px solid #f0f0f0;
            transition: border-color 0.3s ease;
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .cart-item:hover .cart-item-image-wrapper {
            border-color: #000;
        }

        .cart-item-image {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .cart-item-content {
            flex: 1;
            display: flex;
            flex-direction: column;
            gap: 1.2rem;
        }

        .cart-item-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 1.5rem;
        }

        .cart-item-info {
            flex: 1;
        }

        .cart-item-brand {
            font-size: 0.9rem;
            color: #666;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .cart-item-brand i {
            color: #000;
            font-size: 0.8rem;
        }

        .cart-item-name {
            font-size: 1.6rem;
            font-weight: 700;
            color: #000;
            margin-bottom: 0.8rem;
            line-height: 1.2;
        }

        .cart-item-size {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            color: #666;
            font-size: 1rem;
            background: #f8f9fa;
            padding: 0.5rem 1rem;
            border-radius: 40px;
            width: fit-content;
        }

        .cart-item-size i {
            color: #000;
        }

        .cart-item-price {
            font-size: 2rem;
            font-weight: 800;
            color: #000;
            white-space: nowrap;
            background: linear-gradient(135deg, #000 0%, #333 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .cart-item-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: auto;
            padding-top: 1rem;
            border-top: 1px solid #f0f0f0;
        }

        .quantity-section {
            display: flex;
            align-items: center;
            gap: 1.2rem;
        }

        .quantity-label {
            font-weight: 500;
            color: #666;
            font-size: 0.95rem;
        }

        .quantity-controls {
            background: #f8f9fa;
            border-radius: 60px;
            padding: 0.4rem;
        }

        .quantity-form {
            display: flex;
            align-items: center;
            gap: 0.3rem;
        }

        .quantity-btn {
            width: 36px;
            height: 36px;
            border: none;
            background: white;
            color: #000;
            border-radius: 50%;
            cursor: pointer;
            font-size: 0.9rem;
            transition: all 0.2s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
        }

        .quantity-btn:hover {
            background: #000;
            color: white;
            transform: scale(0.95);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }

        .quantity-btn:active {
            transform: scale(0.9);
        }

        .quantity-input {
            width: 45px;
            text-align: center;
            border: none;
            background: transparent;
            font-size: 1.1rem;
            font-weight: 600;
            color: #000;
        }

        .quantity-input:focus {
            outline: none;
        }

        .remove-btn {
            background: transparent;
            border: none;
            color: #999;
            width: 42px;
            height: 42px;
            border-radius: 50%;
            cursor: pointer;
            font-size: 1.1rem;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .remove-btn:hover {
            background: #fee;
            color: #e74c3c;
            transform: rotate(8deg) scale(1.1);
        }
        
        /* Order Summary */
        .order-summary {
            background: white;
            border: 2px solid #000;
            border-radius: 20px;
            padding: 2rem;
            position: sticky;
            top: 100px;
            box-shadow: var(--card-shadow);
        }
        
        .order-summary h2 {
            font-size: 1.8rem;
            font-weight: 800;
            color: var(--primary-color);
            margin-bottom: 1.5rem;
            padding-bottom: 1rem;
            border-bottom: 2px solid #000;
            text-align: center;
        }
        
        .summary-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem 0;
            border-bottom: 1px dashed var(--border-color);
        }
        
        .summary-row:last-of-type {
            border-bottom: none;
        }
        
        .summary-label {
            color: var(--accent-color);
            font-size: 1rem;
        }
        
        .summary-value {
            font-weight: 600;
            color: var(--primary-color);
        }
        
        .total-row {
            border-top: 2px solid #000;
            border-bottom: none !important;
            margin-top: 1rem;
            padding-top: 1.5rem;
        }
        
        .total-label {
            font-size: 1.3rem;
            font-weight: 800;
            color: var(--primary-color);
        }
        
        .total-value {
            font-size: 2rem;
            font-weight: 900;
            color: var(--primary-color);
        }
        
        .checkout-btn {
            width: 100%;
            background: var(--primary-color);
            color: white;
            border: 2px solid var(--primary-color);
            padding: 1.2rem;
            border-radius: 12px;
            font-size: 1.2rem;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-top: 2rem;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .checkout-btn:hover {
            background: white;
            color: var(--primary-color);
            transform: translateY(-3px);
            box-shadow: 0 10px 30px -5px rgba(0,0,0,0.3);
        }
        
        .checkout-btn:active {
            transform: translateY(0);
        }
        
        .checkout-btn:disabled {
            opacity: 0.6;
            cursor: not-allowed;
        }
        
        /* Empty Cart */
        .empty-cart {
            text-align: center;
            padding: 4rem 2rem;
            background: white;
            border: 2px solid #000;
            border-radius: 20px;
            box-shadow: var(--card-shadow);
            grid-column: 1 / -1;
        }
        
        .empty-cart-icon {
            width: 120px;
            height: 120px;
            margin: 0 auto 2rem;
            color: var(--border-color);
            stroke: currentColor;
            stroke-width: 1.5;
            fill: none;
        }
        
        .empty-cart h2 {
            font-size: 2rem;
            font-weight: 800;
            color: var(--primary-color);
            margin-bottom: 1rem;
        }
        
        .empty-cart p {
            color: var(--accent-color);
            font-size: 1.1rem;
            margin-bottom: 2rem;
        }
        
        .btn {
            display: inline-block;
            background: var(--primary-color);
            color: white;
            padding: 1rem 2.5rem;
            text-decoration: none;
            border: 2px solid var(--primary-color);
            border-radius: 12px;
            font-weight: 600;
            font-size: 1.1rem;
            transition: all 0.3s ease;
        }
        
        .btn:hover {
            background: white;
            color: var(--primary-color);
            transform: translateY(-3px);
            box-shadow: 0 10px 30px -5px rgba(0,0,0,0.2);
        }
        
        /* Messages */
        .success-message {
            background: #d4edda;
            color: #155724;
            padding: 1rem 1.5rem;
            border-radius: 12px;
            border: 2px solid #c3e6cb;
            margin-bottom: 1.5rem;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            animation: slideDown 0.5s ease;
        }
        
        .error-message {
            background: #f8d7da;
            color: #721c24;
            padding: 1rem 1.5rem;
            border-radius: 12px;
            border: 2px solid #f5c6cb;
            margin-bottom: 1.5rem;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            animation: slideDown 0.5s ease;
        }
        
        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        /* Loading Animation */
        .loading {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 2px solid rgba(255,255,255,0.3);
            border-top-color: white;
            border-radius: 50%;
            animation: spin 0.8s linear infinite;
        }
        
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
        
        /* Responsive */
        @media (max-width: 1024px) {
            .cart-layout {
                grid-template-columns: 1fr;
            }
            
            .order-summary {
                position: static;
            }
            
            .header-full-width {
                padding: 0 1.5rem;
            }
            
            .header-container {
                gap: 2rem;
            }
            
            nav ul {
                gap: 1.5rem;
            }
            
            .header-actions {
                min-width: 250px;
            }
            
            .search-box {
                min-width: 200px;
            }
        }
        
        @media (max-width: 768px) {
            .header-container {
                flex-wrap: wrap;
                gap: 1rem;
            }
            
            .mobile-menu-btn {
                display: block;
            }
            
            nav {
                order: 3;
                display: none;
                width: 100%;
                margin: 0;
            }
            
            nav.active {
                display: block;
            }
            
            nav ul {
                flex-direction: column;
                gap: 0.5rem;
                padding: 1rem 0;
            }
            
            .header-actions {
                min-width: auto;
                gap: 0.5rem;
            }
            
            .search-box {
                min-width: 150px;
            }
            
            .logo {
                min-width: auto;
            }
            
            .logo h1 {
                font-size: 1.5rem;
            }
            
            .cart-item {
                flex-direction: column;
                gap: 1.5rem;
                padding: 1.5rem;
            }
            
            .cart-item-image-wrapper {
                width: 250px;
                height: 250px;
                margin: 0 auto;
            }
            
            .cart-item-header {
                flex-direction: column;
                text-align: center;
                gap: 1rem;
            }
            
            .cart-item-size {
                margin: 0 auto;
            }
            
            .cart-item-price {
                align-self: center;
            }
            
            .cart-item-footer {
                flex-direction: column;
                gap: 1.5rem;
            }
            
            .quantity-section {
                flex-direction: column;
                gap: 0.8rem;
            }
            
            .cart-title {
                font-size: 2rem;
            }
        }
        
        @media (max-width: 480px) {
            .cart-container {
                padding: 0 1rem;
            }
            
            .cart-item {
                padding: 1.2rem;
            }
            
            .cart-item-image-wrapper {
                width: 200px;
                height: 200px;
            }
            
            .cart-item-name {
                font-size: 1.4rem;
            }
            
            .cart-item-price {
                font-size: 1.8rem;
            }
            
            .order-summary {
                padding: 1.5rem;
            }
            
            .total-value {
                font-size: 1.8rem;
            }
            
            .checkout-btn {
                padding: 1rem;
                font-size: 1.1rem;
            }
        }
    </style>
</head>
<body>
    <!-- Original Header -->
    <header>
        <div class="header-full-width">
            <div class="header-container">
                <button class="mobile-menu-btn">
                    <i class="fas fa-bars"></i>
                </button>
                
                <div class="logo">
                    <h1><?= SITE_NAME ?></h1>
                </div>
                
                <nav id="main-nav">
                    <ul>
                        <li><a href="index.php">Главная</a></li>
                        <li><a href="catalog.php">Обувь</a></li>
                        <li><a href="feedback.php">Обратная связь</a></li>
                        <?php if(isset($_SESSION['user_id'])): ?>
                            <?php if($is_admin): ?>
                                <li><a href="admin.php" class="admin-link">Админ панель</a></li>
                            <?php endif; ?>
                            <li><a href="profile.php">Личный кабинет</a></li>
                            <li><a href="logout.php">Выйти</a></li>
                        <?php else: ?>
                            <li><a href="login.php">Войти</a></li>
                            <li><a href="register.php">Регистрация</a></li>
                        <?php endif; ?>
                    </ul>
                </nav>
                
                <div class="header-actions">
                    <div class="search-box">
                        <input type="text" id="searchInput" placeholder="Поиск товаров...">
                        <button onclick="searchProducts()">
                            <i class="fas fa-search"></i>
                        </button>
                    </div>
                    
                    <a href="cart.php" class="cart-link">
                        <svg class="cart-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path>
                            <line x1="3" y1="6" x2="21" y2="6"></line>
                            <path d="M16 10a4 4 0 0 1-8 0"></path>
                        </svg>
                        <span class="cart-count"><?= count($cart_items) ?></span>
                    </a>
                </div>
            </div>
        </div>
    </header>

    <main class="cart-container">
        <h1 class="cart-title">Корзина</h1>
        
        <?php if (isset($_SESSION['cart_success'])): ?>
            <div class="success-message">
                <i class="fas fa-check-circle"></i>
                <?= $_SESSION['cart_success'] ?>
            </div>
            <?php unset($_SESSION['cart_success']); ?>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['cart_error'])): ?>
            <div class="error-message">
                <i class="fas fa-exclamation-circle"></i>
                <?= $_SESSION['cart_error'] ?>
            </div>
            <?php unset($_SESSION['cart_error']); ?>
        <?php endif; ?>
        
        <?php if (empty($cart_items)): ?>
            <div class="empty-cart">
                <svg class="empty-cart-icon" viewBox="0 0 24 24">
                    <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path>
                    <line x1="3" y1="6" x2="21" y2="6"></line>
                    <path d="M16 10a4 4 0 0 1-8 0"></path>
                </svg>
                <h2>Ваша корзина пуста</h2>
                <p>Добавьте товары из каталога</p>
                <a href="catalog.php" class="btn">Перейти в каталог</a>
            </div>
        <?php else: ?>
            <div class="cart-layout">
                <!-- Cart Items - Обновленный дизайн -->
                <div class="cart-items">
                    <?php foreach ($cart_items as $index => $item): ?>
                        <div class="cart-item" style="animation-delay: <?= $index * 0.1 ?>s">
                            <div class="cart-item-image-wrapper">
                                <img src="<?= htmlspecialchars($item['image_url']) ?>" 
                                     alt="<?= htmlspecialchars($item['name']) ?>" 
                                     class="cart-item-image"
                                     onerror="this.src='images/placeholder.jpg'">
                            </div>
                            
                            <div class="cart-item-content">
                                <div class="cart-item-header">
                                    <div class="cart-item-info">
                                        <div class="cart-item-brand">
                                            <i class="fas fa-tag"></i>
                                            <?= htmlspecialchars($item['brand']) ?>
                                        </div>
                                        <div class="cart-item-name"><?= htmlspecialchars($item['name']) ?></div>
                                        <div class="cart-item-size">
                                            <i class="fas fa-ruler"></i>
                                            Размер: <?= htmlspecialchars($item['size']) ?>
                                        </div>
                                    </div>
                                    <div class="cart-item-price">
                                        <?= number_format($item['price'], 0, ',', ' ') ?> ₽
                                    </div>
                                </div>
                                
                                <div class="cart-item-footer">
                                    <div class="quantity-section">
                                        <span class="quantity-label">Количество:</span>
                                        <div class="quantity-controls">
                                            <form method="POST" action="cart.php" class="quantity-form">
                                                <input type="hidden" name="cart_id" value="<?= $item['id'] ?>">
                                                <button type="button" class="quantity-btn minus-btn" title="Уменьшить">
                                                    <i class="fas fa-minus"></i>
                                                </button>
                                                <input type="number" name="quantity" value="<?= $item['quantity'] ?>" 
                                                       min="0" class="quantity-input" readonly>
                                                <button type="button" class="quantity-btn plus-btn" title="Увеличить">
                                                    <i class="fas fa-plus"></i>
                                                </button>
                                                <input type="hidden" name="update_quantity" value="1">
                                            </form>
                                        </div>
                                    </div>
                                    
                                    <form method="POST" action="cart.php" class="remove-form">
                                        <input type="hidden" name="cart_id" value="<?= $item['id'] ?>">
                                        <input type="hidden" name="remove_item" value="1">
                                        <button type="submit" class="remove-btn" title="Удалить товар">
                                            <i class="fas fa-trash-alt"></i>
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                
                <!-- Order Summary -->
                <div class="order-summary">
                    <h2>Оформление заказа</h2>
                    
                    <div class="summary-row">
                        <span class="summary-label">Товары (<?= count($cart_items) ?>)</span>
                        <span class="summary-value"><?= number_format($total_amount, 0, ',', ' ') ?> ₽</span>
                    </div>
                    
                    <div class="summary-row">
                        <span class="summary-label">Доставка</span>
                        <span class="summary-value">Бесплатно</span>
                    </div>
                    
                    <div class="summary-row">
                        <span class="summary-label">НДС</span>
                        <span class="summary-value">Включен</span>
                    </div>
                    
                    <div class="summary-row total-row">
                        <span class="total-label">Итого</span>
                        <span class="total-value"><?= number_format($total_amount, 0, ',', ' ') ?> ₽</span>
                    </div>
                    
                    <form method="POST" action="checkout.php" id="checkoutForm">
                        <button type="submit" class="checkout-btn" id="checkoutBtn">
                            Оформить заказ
                        </button>
                    </form>
                </div>
            </div>
        <?php endif; ?>
    </main>

    <script>
        // Mobile menu toggle
        document.querySelector('.mobile-menu-btn').addEventListener('click', function() {
            document.getElementById('main-nav').classList.toggle('active');
        });

        // Close mobile menu when clicking outside
        document.addEventListener('click', function(event) {
            const nav = document.getElementById('main-nav');
            const menuBtn = document.querySelector('.mobile-menu-btn');
            if (!nav.contains(event.target) && !menuBtn.contains(event.target)) {
                nav.classList.remove('active');
            }
        });

        function searchProducts() {
            const searchTerm = document.getElementById('searchInput').value;
            if (searchTerm.trim()) {
                window.location.href = `catalog.php?search=${encodeURIComponent(searchTerm)}`;
            }
        }

        // Search on Enter key
        document.getElementById('searchInput').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                searchProducts();
            }
        });

        // Quantity controls with AJAX
        document.querySelectorAll('.quantity-form').forEach(form => {
            const minusBtn = form.querySelector('.minus-btn');
            const plusBtn = form.querySelector('.plus-btn');
            const quantityInput = form.querySelector('.quantity-input');
            
            async function updateQuantity(newQuantity) {
                if (newQuantity < 0) return;
                
                const formData = new FormData();
                formData.append('cart_id', form.querySelector('input[name="cart_id"]').value);
                formData.append('quantity', newQuantity);
                formData.append('update_quantity', '1');
                
                try {
                    const response = await fetch('cart.php', {
                        method: 'POST',
                        body: formData
                    });
                    
                    if (response.ok) {
                        window.location.reload();
                    }
                } catch (error) {
                    console.error('Error:', error);
                    window.location.reload();
                }
            }
            
            minusBtn.addEventListener('click', function() {
                let quantity = parseInt(quantityInput.value);
                updateQuantity(quantity - 1);
            });
            
            plusBtn.addEventListener('click', function() {
                let quantity = parseInt(quantityInput.value);
                updateQuantity(quantity + 1);
            });
        });

        // Remove item with confirmation
        document.querySelectorAll('.remove-form').forEach(form => {
            form.addEventListener('submit', function(e) {
                e.preventDefault();
                
                if (confirm('Удалить товар из корзины?')) {
                    this.submit();
                }
            });
        });

        // Checkout button
        document.getElementById('checkoutForm')?.addEventListener('submit', function(e) {
            <?php if (empty($cart_items)): ?>
            e.preventDefault();
            alert('Корзина пуста');
            return false;
            <?php endif; ?>
            
            if (!confirm('Подтвердить оформление заказа? Товары будут перемещены в историю заказов.')) {
                e.preventDefault();
                return false;
            }
            
            const btn = document.getElementById('checkoutBtn');
            btn.innerHTML = '<span class="loading"></span> Оформление...';
            btn.disabled = true;
            
            return true;
        });

        // Update cart count
        function updateCartCount() {
            const cartCount = document.querySelector('.cart-count');
            if (cartCount) {
                cartCount.textContent = '<?= count($cart_items) ?>';
            }
        }

        // Initialize on page load
        document.addEventListener('DOMContentLoaded', updateCartCount);
    </script>
</body>
</html>