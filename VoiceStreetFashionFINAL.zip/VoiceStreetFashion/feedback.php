<?php
session_start();
require_once 'includes/database.php';
require_once 'includes/config.php';

// Класс безопасности (оставляем без изменений)
class Security {
    public static function escape($data) {
        if (is_array($data)) {
            return array_map([self::class, 'escape'], $data);
        }
        return htmlspecialchars($data, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    }
    
    public static function validateInput($data, $type = 'string') {
        if ($data === null) return '';
        
        $data = trim($data);
        $data = stripslashes($data);
        
        switch ($type) {
            case 'email':
                $data = filter_var($data, FILTER_SANITIZE_EMAIL);
                return filter_var($data, FILTER_VALIDATE_EMAIL) ? $data : false;
            case 'int':
                return filter_var($data, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
            case 'text':
                if (strlen($data) > 1000) {
                    $data = substr($data, 0, 1000);
                }
                return self::escape($data);
            default:
                return self::escape($data);
        }
    }
}

// Функция для получения количества товаров в корзине
function getCartCount() {
    $count = 0;
    
    // Проверяем, авторизован ли пользователь
    if (isset($_SESSION['user_id'])) {
        // Для авторизованных пользователей считаем товары в БД
        try {
            $db = new Database();
            $connection = $db->getConnection();
            
            $stmt = $connection->prepare("
                SELECT SUM(quantity) as total 
                FROM cart 
                WHERE user_id = ?
            ");
            $stmt->execute([$_SESSION['user_id']]);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($result && $result['total']) {
                $count = (int)$result['total'];
            }
        } catch (PDOException $e) {
            error_log("Ошибка получения количества товаров в корзине: " . $e->getMessage());
        }
    } else {
        // Для неавторизованных пользователей считаем товары в сессии
        if (isset($_SESSION['cart']) && is_array($_SESSION['cart'])) {
            foreach ($_SESSION['cart'] as $item) {
                $count += isset($item['quantity']) ? (int)$item['quantity'] : 1;
            }
        }
    }
    
    return $count;
}

// Получаем количество товаров в корзине
$cart_count = getCartCount();

// Сначала инициализируем базу данных для проверки ролей
$db = new Database();
$connection = $db->getConnection();

// ЗАЩИТА: Проверяем, является ли пользователь администратором
$is_admin = false;
if(isset($_SESSION['user_id'])) {
    $user_id = Security::validateInput($_SESSION['user_id'], 'int');
    
    if ($user_id) {
        try {
            // ЗАЩИТА: Подготовленный запрос для проверки роли
            $stmt = $connection->prepare("SELECT role FROM users WHERE id = ?");
            $stmt->execute([$user_id]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($user && isset($user['role'])) {
                $is_admin = ($user['role'] === 'admin');
                $_SESSION['is_admin'] = $is_admin;
            } else {
                // Если колонки role нет, используем ID пользователя как fallback
                $is_admin = ($user_id == 1);
                $_SESSION['is_admin'] = $is_admin;
            }
        } catch (PDOException $e) {
            // Если произошла ошибка (колонка role не существует), используем fallback
            error_log("Ошибка проверки роли: " . $e->getMessage());
            $is_admin = ($user_id == 1); // ID 1 = администратор
            $_SESSION['is_admin'] = $is_admin;
        }
    }
}

// ЗАЩИТА: Обработка формы обратной связи
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $subject = Security::validateInput($_POST['subject'] ?? '', 'text');
    $message = Security::validateInput($_POST['message'] ?? '', 'text');
    $user_id = isset($_SESSION['user_id']) ? Security::validateInput($_SESSION['user_id'], 'int') : null;
    
    $errors = [];
    
    if (empty($subject)) {
        $errors[] = "Введите тему сообщения";
    } elseif (strlen($subject) > 255) {
        $errors[] = "Тема сообщения слишком длинная (максимум 255 символов)";
    }
    
    if (empty($message)) {
        $errors[] = "Введите текст сообщения";
    } elseif (strlen($message) > 1000) {
        $errors[] = "Сообщение слишком длинное (максимум 1000 символов)";
    }
    
    if (empty($errors)) {
        // ЗАЩИТА: Подготовленный запрос для вставки обратной связи
        try {
            $stmt = $connection->prepare("INSERT INTO feedback (user_id, subject, message) VALUES (?, ?, ?)");
            if ($stmt->execute([$user_id, $subject, $message])) {
                $success = "Сообщение успешно отправлено! Мы ответим вам в ближайшее время.";
                // Очищаем поля формы после успешной отправки
                $subject = $message = '';
            } else {
                $errors[] = "Ошибка при отправке сообщения";
            }
        } catch (PDOException $e) {
            error_log("Ошибка отправки обратной связи: " . $e->getMessage());
            $errors[] = "Произошла ошибка при отправке сообщения. Пожалуйста, попробуйте позже.";
        }
    }
}

// Безопасные значения для формы
$subject_value = Security::escape($_POST['subject'] ?? '');
$message_value = Security::escape($_POST['message'] ?? '');
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- ЗАЩИТА ОТ XSS: экранируем вывод -->
    <title>Обратная связь - <?= Security::escape(SITE_NAME) ?></title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #000;
            --secondary-color: #111;
            --accent-color: #555;
            --light-color: #eee;
            --text-color: #333;
            --success-color: #28a745;
            --border-color: #ddd;
            --admin-color: #dc3545;
        }
        
        /* Header Styles - Full Width */
        header {
            background: white;
            box-shadow: 0 2px 20px rgba(0,0,0,0.1);
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            padding: 0.5rem 0;
            width: 100%;
        }
        
        .header-full-width {
            max-width: 100%;
            margin: 0;
            padding: 0 2rem;
        }
        
        .header-container {
            display: flex;
            align-items: center;
            justify-content: space-between;
            width: 100%;
            gap: 3rem;
        }
        
        .logo {
            display: flex;
            flex-direction: column;
            align-items: flex-start;
            min-width: 200px;
        }
        
        .logo h1 {
            color: var(--primary-color) !important;
            font-size: 1.8rem;
            font-weight: bold;
            margin: 0;
            line-height: 1;
            white-space: nowrap;
        }
        
        .logo span {
            color: var(--secondary-color);
            font-size: 0.8rem;
            margin-top: 2px;
        }
        
        nav {
            flex: 1;
            display: flex;
            justify-content: center;
            margin: 0 2rem;
        }
        
        nav ul {
            display: flex;
            list-style: none;
            margin: 0;
            padding: 0;
            gap: 2rem;
        }
        
        nav a {
            text-decoration: none;
            color: var(--text-color);
            font-weight: 500;
            font-size: 1rem;
            transition: color 0.3s;
            position: relative;
            white-space: nowrap;
            padding: 0.5rem 0;
        }
        
        nav a:hover {
            color: var(--primary-color);
        }
        
        nav a::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 0;
            height: 2px;
            background: var(--primary-color);
            transition: width 0.3s;
        }
        
        nav a:hover::after {
            width: 100%;
        }
        
        .admin-link {
            color: var(--admin-color) !important;
            font-weight: 600 !important;
        }
        
        .admin-link:hover {
            color: var(--admin-color) !important;
        }
        
        .admin-link::after {
            background: var(--admin-color) !important;
        }
        
        .header-actions {
            display: flex;
            align-items: center;
            gap: 1rem;
            min-width: 300px;
            justify-content: flex-end;
        }
        
        .search-box {
            display: flex;
            background: var(--light-color);
            border-radius: 25px;
            padding: 0.4rem;
            border: 2px solid transparent;
            transition: border-color 0.3s;
            min-width: 250px;
            margin-right: 1rem;
        }
        
        .search-box:focus-within {
            border-color: var(--primary-color);
        }
        
        .search-box input {
            border: none;
            background: none;
            outline: none;
            padding: 0 1rem;
            width: 100%;
            font-size: 0.9rem;
        }
        
        .search-box button {
            background: var(--primary-color);
            color: white;
            border: none;
            padding: 0.4rem 1rem;
            border-radius: 20px;
            cursor: pointer;
            font-size: 0.9rem;
            transition: background 0.3s;
            white-space: nowrap;
        }
        
        .search-box button:hover {
            background: var(--secondary-color);
        }
        
        .cart-link {
            display: flex;
            align-items: center;
            text-decoration: none;
            color: var(--text-color);
            transition: color 0.3s;
            padding: 0.5rem;
            position: relative;
            background: none !important;
        }
        
        .cart-link:hover {
            color: var(--primary-color);
        }
        
        .cart-icon {
            width: 24px;
            height: 24px;
        }
        
        .cart-count {
            background: var(--accent-color);
            color: white;
            border-radius: 50%;
            width: 18px;
            height: 18px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.7rem;
            position: absolute;
            top: 2px;
            right: 2px;
            font-weight: bold;
        }

        /* Mobile menu button */
        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            font-size: 1.5rem;
            color: var(--text-color);
            cursor: pointer;
        }

        /* Main content margin for fixed header */
        main {
            margin-top: 80px;
            min-height: calc(100vh - 80px);
            display: flex;
            align-items: center;
            justify-content: center;
            background: var(--light-color);
        }

        /* Responsive */
        @media (max-width: 1200px) {
            .header-full-width {
                padding: 0 1.5rem;
            }
            
            .header-container {
                gap: 2rem;
            }
            
            nav ul {
                gap: 1.5rem;
            }
            
            .header-actions {
                min-width: 250px;
            }
            
            .search-box {
                min-width: 200px;
            }
        }

        @media (max-width: 992px) {
            .header-container {
                gap: 1.5rem;
            }
            
            nav {
                margin: 0 1rem;
            }
            
            nav ul {
                gap: 1rem;
            }
            
            .header-actions {
                min-width: 200px;
            }
            
            .search-box {
                min-width: 180px;
                margin-right: 0.5rem;
            }
        }

        @media (max-width: 768px) {
            .header-container {
                flex-wrap: wrap;
                gap: 1rem;
            }
            
            .mobile-menu-btn {
                display: block;
            }
            
            nav {
                order: 3;
                display: none;
                width: 100%;
                margin: 0;
            }
            
            nav.active {
                display: block;
            }
            
            nav ul {
                flex-direction: column;
                gap: 0.5rem;
                padding: 1rem 0;
            }
            
            .header-actions {
                min-width: auto;
                gap: 0.5rem;
            }
            
            .search-box {
                min-width: 150px;
            }
            
            .logo {
                min-width: auto;
            }
            
            .logo h1 {
                font-size: 1.5rem;
            }
            
            .cart-link {
                padding: 0.3rem;
            }
        }

        @media (max-width: 480px) {
            .header-full-width {
                padding: 0 1rem;
            }
            
            .search-box {
                min-width: 120px;
            }
            
            .cart-link {
                padding: 0.2rem;
            }
        }

        /* Form Styles */
        .form-container {
            background: white;
            padding: 2rem;
            border-radius: 10px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 500px;
            margin: 2rem;
        }
        
        .form-container h2 {
            text-align: center;
            color: var(--primary-color);
            margin-bottom: 2rem;
            font-size: 2rem;
        }
        
        .form-group {
            margin-bottom: 1.5rem;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            color: var(--text-color);
            font-weight: 500;
        }
        
        .form-group input,
        .form-group textarea {
            width: 100%;
            padding: 0.75rem;
            border: 2px solid var(--border-color);
            border-radius: 5px;
            font-size: 1rem;
            transition: border-color 0.3s;
            box-sizing: border-box;
            font-family: inherit;
        }
        
        .form-group input:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: var(--primary-color);
        }
        
        .form-group textarea {
            height: 150px;
            resize: vertical;
        }
        
        .btn {
            background: var(--primary-color);
            color: white;
            border: none;
            padding: 1rem 2rem;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1rem;
            width: 100%;
            transition: background-color 0.3s;
        }
        
        .btn:hover {
            background: var(--secondary-color);
        }
        
        .error-message {
            background: #ff6b6b;
            color: white;
            padding: 1rem;
            border-radius: 5px;
            margin-bottom: 1rem;
        }
        
        .success-message {
            background: #4ecdc4;
            color: white;
            padding: 1rem;
            border-radius: 5px;
            margin-bottom: 1rem;
        }
    </style>
</head>
<body>
    <!-- Header - Full Width -->
    <header>
        <div class="header-full-width">
            <div class="header-container">
                <button class="mobile-menu-btn">
                    <i class="fas fa-bars"></i>
                </button>
                
                <div class="logo">
                    <!-- ЗАЩИТА ОТ XSS: экранируем вывод -->
                    <h1><?= Security::escape(SITE_NAME) ?></h1>
                </div>
                
                <nav id="main-nav">
                    <ul>
                        <li><a href="index.php">Главная</a></li>
                        <li><a href="catalog.php">Обувь</a></li>
                        <li><a href="feedback.php" style="color: var(--primary-color);">Обратная связь</a></li>
                        <?php if(isset($_SESSION['user_id'])): ?>
                            <?php if($is_admin): ?>
                                <li><a href="admin.php" class="admin-link">Админ панель</a></li>
                            <?php endif; ?>
                            <li><a href="profile.php">Личный кабинет</a></li>
                            <li><a href="logout.php">Выйти</a></li>
                        <?php else: ?>
                            <li><a href="login.php">Войти</a></li>
                            <li><a href="register.php">Регистрация</a></li>
                        <?php endif; ?>
                    </ul>
                </nav>
                
                <div class="header-actions">
                    <div class="search-box">
                        <input type="text" id="searchInput" placeholder="Поиск товаров...">
                        <button onclick="searchProducts()">
                            <i class="fas fa-search"></i>
                        </button>
                    </div>
                    
                    <a href="cart.php" class="cart-link">
                        <svg class="cart-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path>
                            <line x1="3" y1="6" x2="21" y2="6"></line>
                            <path d="M16 10a4 4 0 0 1-8 0"></path>
                        </svg>
                        <span class="cart-count"><?= $cart_count ?></span>
                    </a>
                </div>
            </div>
        </div>
    </header>
    
    <main>
        <div class="form-container">
            <h2>Обратная связь</h2>
            
            <?php if (!empty($errors)): ?>
                <div class="error-message">
                    <!-- ЗАЩИТА ОТ XSS: экранируем сообщения об ошибках -->
                    <?php foreach ($errors as $error): ?>
                        <p><?= Security::escape($error) ?></p>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            
            <?php if (isset($success)): ?>
                <div class="success-message">
                    <!-- ЗАЩИТА ОТ XSS: экранируем сообщение об успехе -->
                    <p><?= Security::escape($success) ?></p>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="">
                <div class="form-group">
                    <label for="subject">Тема:</label>
                    <!-- ЗАЩИТА ОТ XSS: экранируем значение в форме -->
                    <input type="text" id="subject" name="subject" value="<?= $subject_value ?>" required 
                           maxlength="255" placeholder="Введите тему сообщения">
                </div>
                
                <div class="form-group">
                    <label for="message">Сообщение:</label>
                    <!-- ЗАЩИТА ОТ XSS: экранируем значение в форме -->
                    <textarea id="message" name="message" required 
                              maxlength="1000" placeholder="Введите ваше сообщение"><?= $message_value ?></textarea>
                </div>
                
                <button type="submit" class="btn">Отправить сообщение</button>
            </form>
        </div>
    </main>

    <script>
        // Mobile menu toggle
        document.querySelector('.mobile-menu-btn').addEventListener('click', function() {
            document.getElementById('main-nav').classList.toggle('active');
        });

        // Close mobile menu when clicking outside
        document.addEventListener('click', function(event) {
            const nav = document.getElementById('main-nav');
            const menuBtn = document.querySelector('.mobile-menu-btn');
            if (!nav.contains(event.target) && !menuBtn.contains(event.target)) {
                nav.classList.remove('active');
            }
        });

        function searchProducts() {
            const searchTerm = document.getElementById('searchInput').value;
            if (searchTerm.trim()) {
                // ЗАЩИТА: Кодируем параметры URL
                window.location.href = `catalog.php?search=${encodeURIComponent(searchTerm)}`;
            }
        }

        // Функция для обновления счетчика корзины через AJAX
        function updateCartCount() {
            fetch('get_cart_count.php')
                .then(response => response.json())
                .then(data => {
                    if (data.count !== undefined) {
                        document.querySelector('.cart-count').textContent = data.count;
                    }
                })
                .catch(error => console.error('Ошибка обновления корзины:', error));
        }

        // Инициализация счетчика корзины при загрузке страницы
        document.addEventListener('DOMContentLoaded', function() {
            // Счетчик уже установлен из PHP, но можно обновить его через AJAX
            // если корзина могла измениться на этой странице
            updateCartCount();
        });

        // Search on Enter key
        document.getElementById('searchInput').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                searchProducts();
            }
        });

        // ЗАЩИТА: Валидация длины полей на клиентской стороне
        document.getElementById('subject').addEventListener('input', function() {
            if (this.value.length > 255) {
                this.value = this.value.substring(0, 255);
                alert('Тема сообщения не может превышать 255 символов');
            }
        });

        document.getElementById('message').addEventListener('input', function() {
            if (this.value.length > 1000) {
                this.value = this.value.substring(0, 1000);
                alert('Сообщение не может превышать 1000 символов');
            }
        });
    </script>
</body>
<footer style="background: var(--primary-color); color: white; padding: 3rem 0; margin-top: 4rem;">
    <div class="container">
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 3rem; margin-bottom: 2rem;">
            <div>
                <!-- ЗАЩИТА ОТ XSS: экранируем вывод -->
                <h3 style="color: var(--light-color); margin-bottom: 1rem; font-size: 1.5rem;"><?= Security::escape(SITE_NAME) ?></h3>
                <p style="line-height: 1.6; opacity: 0.9;">Ваш голос в мире уличной моды. Премиальная обувь от ведущих мировых брендов с доставкой по всей России.</p>
                <div style="display: flex; gap: 1rem; margin-top: 1rem;">
                    <a href="<?= Security::escape(INSTAGRAM) ?>" style="color: white; opacity: 0.8; transition: opacity 0.3s;" onmouseover="this.style.opacity='1'" onmouseout="this.style.opacity='0.8'">
                         Instagram
                    </a>
                    <a href="<?= Security::escape(TELEGRAM) ?>" style="color: white; opacity: 0.8; transition: opacity 0.3s;" onmouseover="this.style.opacity='1'" onmouseout="this.style.opacity='0.8'">
                         Telegram
                    </a>
                    <a href="<?= Security::escape(VK) ?>" style="color: white; opacity: 0.8; transition: opacity 0.3s;" onmouseover="this.style.opacity='1'" onmouseout="this.style.opacity='0.8'">
                         VK
                    </a>
                </div>
            </div>
            
            <div>
                <h4 style="color: var(--light-color); margin-bottom: 1rem;">Контактная информация</h4>
                <div style="display: flex; flex-direction: column; gap: 0.5rem;">
                    <div style="display: flex; align-items: center; gap: 0.5rem;">
                        <span></span>
                        <!-- ЗАЩИТА ОТ XSS: экранируем контактные данные -->
                        <span><?= Security::escape(PHONE) ?></span>
                    </div>
                    <div style="display: flex; align-items: center; gap: 0.5rem;">
                        <span></span>
                        <span><?= Security::escape(EMAIL) ?></span>
                    </div>
                    <div style="display: flex; align-items: center; gap: 0.5rem;">
                        <span></span>
                        <span><?= Security::escape(ADDRESS) ?></span>
                    </div>
                </div>
            </div>
            
            <div>
                <h4 style="color: var(--light-color); margin-bottom: 1rem;">Полезные ссылки</h4>
                <div style="display: flex; flex-direction: column; gap: 0.5rem;">
                    <a href="catalog.php" style="color: white; opacity: 0.8; text-decoration: none; transition: opacity 0.3s;" 
                       onmouseover="this.style.opacity='1'" onmouseout="this.style.opacity='0.8'">Каталог обуви</a>
                    <a href="feedback.php" style="color: white; opacity: 0.8; text-decoration: none; transition: opacity 0.3s;" 
                       onmouseover="this.style.opacity='1'" onmouseout="this.style.opacity='0.8'">Обратная связь</a>
                    <a href="login.php" style="color: white; opacity: 0.8; text-decoration: none; transition: opacity 0.3s;" 
                       onmouseover="this.style.opacity='1'" onmouseout="this.style.opacity='0.8'">Личный кабинет</a>
                </div>
            </div>
            
            <div>
                <h4 style="color: var(--light-color); margin-bottom: 1rem;">Часы работы</h4>
                <div style="display: flex; flex-direction: column; gap: 0.5rem; opacity: 0.9;">
                    <div>Пн-Пт: 9:00 - 21:00</div>
                    <div>Сб-Вс: 10:00 - 20:00</div>
                    <div style="margin-top: 0.5rem; font-size: 0.9rem;">Доставка работает ежедневно</div>
                </div>
            </div>
        </div>
        
        <div style="text-align: center; padding-top: 2rem; border-top: 1px solid rgba(255,255,255,0.2);">
            <p style="margin: 0; opacity: 0.8; font-size: 0.9rem;">
                &copy; 2026 <?= Security::escape(SITE_NAME) ?>. Все права защищены. 
                <span style="display: block; margin-top: 0.5rem;">
                    Сайт создан для демонстрации возможностей интернет-магазина
                </span>
            </p>
        </div>
    </div>
</footer>
</html>