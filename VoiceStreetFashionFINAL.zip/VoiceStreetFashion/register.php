<?php
    session_start();
    require_once 'includes/database.php';
    require_once 'includes/config.php';

    // Проверяем, является ли пользователь администратором
    $is_admin = false;
    if(isset($_SESSION['user_id'])) {
        $db = new Database();
        $connection = $db->getConnection();
        $user_id = $_SESSION['user_id'];
        $stmt = $connection->prepare("SELECT role FROM users WHERE id = ?");
        $stmt->execute([$user_id]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($user) {
            $is_admin = ($user['role'] === 'admin');
            // Сохраняем в сессии для удобства
            $_SESSION['is_admin'] = $is_admin;
        }
    }

    // Генерация математической капчи
    function generateMathCaptcha() {
        $operations = ['+', '-', '*'];
        $operation = $operations[array_rand($operations)];
        
        $num1 = rand(1, 10);
        $num2 = rand(1, 10);
        
        // Для вычитания убедимся, что результат положительный
        if ($operation === '-' && $num2 > $num1) {
            list($num1, $num2) = [$num2, $num1];
        }
        
        // Для умножения используем меньшие числа
        if ($operation === '*') {
            $num1 = rand(1, 5);
            $num2 = rand(1, 5);
        }
        
        switch($operation) {
            case '+':
                $result = $num1 + $num2;
                $text = "$num1 + $num2";
                break;
            case '-':
                $result = $num1 - $num2;
                $text = "$num1 - $num2";
                break;
            case '*':
                $result = $num1 * $num2;
                $text = "$num1 × $num2";
                break;
        }
        
        // Сохраняем результат в сессии
        $_SESSION['captcha_result'] = $result;
        $_SESSION['captcha_text'] = $text;
        
        return [
            'text' => $text,
            'result' => $result
        ];
    }

    // Генерируем новую капчу при загрузке страницы или если её нет
    if (!isset($_SESSION['captcha_text']) || $_SERVER['REQUEST_METHOD'] !== 'POST') {
        $captcha = generateMathCaptcha();
    } else {
        $captcha = [
            'text' => $_SESSION['captcha_text'],
            'result' => $_SESSION['captcha_result']
        ];
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $db = new Database();
        $connection = $db->getConnection();
        
        $username = trim($_POST['username']);
        $email = trim($_POST['email']);
        $password = $_POST['password'];
        $confirm_password = $_POST['confirm_password'];
        $captcha_answer = trim($_POST['captcha']);
        
        $errors = [];
        
        // Валидация
        if (empty($username)) {
            $errors[] = "Введите имя пользователя";
        }
        
        if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = "Введите корректный email";
        }
        
        if (strlen($password) < 6) {
            $errors[] = "Пароль должен содержать минимум 6 символов";
        }
        
        if ($password !== $confirm_password) {
            $errors[] = "Пароли не совпадают";
        }
        
        // Проверка капчи
        if (empty($captcha_answer)) {
            $errors[] = "Введите результат математического примера";
        } elseif (!is_numeric($captcha_answer)) {
            $errors[] = "Результат должен быть числом";
        } elseif (intval($captcha_answer) !== $_SESSION['captcha_result']) {
            $errors[] = "Неправильный ответ на математический пример";
            // Генерируем новую капчу при ошибке
            $captcha = generateMathCaptcha();
        }
        
        // Проверка существующего пользователя
        $stmt = $connection->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
        $stmt->execute([$username, $email]);
        if ($stmt->fetch()) {
            $errors[] = "Пользователь с таким именем или email уже существует";
        }
        
        if (empty($errors)) {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            $stmt = $connection->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
            if ($stmt->execute([$username, $email, $hashed_password])) {
                // Очищаем капчу из сессии после успешной регистрации
                unset($_SESSION['captcha_result']);
                unset($_SESSION['captcha_text']);
                
                $_SESSION['success'] = "Регистрация успешна! Теперь вы можете войти.";
                header("Location: login.php");
                exit;
            } else {
                $errors[] = "Ошибка при регистрации";
            }
        }
    }
    ?>
    <!DOCTYPE html>
    <html lang="ru">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Регистрация - <?= SITE_NAME ?></title>
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
        <style>
            :root {
                --primary-color: #000;
                --secondary-color: #111;
                --accent-color: #555;
                --light-color: #eee;
                --text-color: #333;
                --success-color: #28a745;
                --border-color: #ddd;
                --admin-color: #dc3545;
            }
            
            /* Header Styles - Full Width */
            header {
                background: white;
                box-shadow: 0 2px 20px rgba(0,0,0,0.1);
                position: fixed;
                top: 0;
                left: 0;
                right: 0;
                z-index: 1000;
                padding: 0.5rem 0;
                width: 100%;
            }
            
            .header-full-width {
                max-width: 100%;
                margin: 0;
                padding: 0 2rem;
            }
            
            .header-container {
                display: flex;
                align-items: center;
                justify-content: space-between;
                width: 100%;
                gap: 3rem;
            }
            
            .logo {
                display: flex;
                flex-direction: column;
                align-items: flex-start;
                min-width: 200px;
            }
            
            .logo h1 {
                color: var(--primary-color) !important;
                font-size: 1.8rem;
                font-weight: bold;
                margin: 0;
                line-height: 1;
                white-space: nowrap;
            }
            
            .logo span {
                color: var(--secondary-color);
                font-size: 0.8rem;
                margin-top: 2px;
            }
            
            nav {
                flex: 1;
                display: flex;
                justify-content: center;
                margin: 0 2rem;
            }
            
            nav ul {
                display: flex;
                list-style: none;
                margin: 0;
                padding: 0;
                gap: 2rem;
            }
            
            nav a {
                text-decoration: none;
                color: var(--text-color);
                font-weight: 500;
                font-size: 1rem;
                transition: color 0.3s;
                position: relative;
                white-space: nowrap;
                padding: 0.5rem 0;
            }
            
            nav a:hover {
                color: var(--primary-color);
            }
            
            nav a::after {
                content: '';
                position: absolute;
                bottom: 0;
                left: 0;
                width: 0;
                height: 2px;
                background: var(--primary-color);
                transition: width 0.3s;
            }
            
            nav a:hover::after {
                width: 100%;
            }
            
            .admin-link {
                color: var(--admin-color) !important;
                font-weight: 600 !important;
            }
            
            .admin-link:hover {
                color: var(--admin-color) !important;
            }
            
            .admin-link::after {
                background: var(--admin-color) !important;
            }
            
            .header-actions {
                display: flex;
                align-items: center;
                gap: 1rem;
                min-width: 300px;
                justify-content: flex-end;
            }
            
            .search-box {
                display: flex;
                background: var(--light-color);
                border-radius: 25px;
                padding: 0.4rem;
                border: 2px solid transparent;
                transition: border-color 0.3s;
                min-width: 250px;
                margin-right: 1rem;
            }
            
            .search-box:focus-within {
                border-color: var(--primary-color);
            }
            
            .search-box input {
                border: none;
                background: none;
                outline: none;
                padding: 0 1rem;
                width: 100%;
                font-size: 0.9rem;
            }
            
            .search-box button {
                background: var(--primary-color);
                color: white;
                border: none;
                padding: 0.4rem 1rem;
                border-radius: 20px;
                cursor: pointer;
                font-size: 0.9rem;
                transition: background 0.3s;
                white-space: nowrap;
            }
            
            .search-box button:hover {
                background: var(--secondary-color);
            }
            
            .cart-link {
                display: flex;
                align-items: center;
                text-decoration: none;
                color: var(--text-color);
                transition: color 0.3s;
                padding: 0.5rem;
                position: relative;
                background: none !important;
            }
            
            .cart-link:hover {
                color: var(--primary-color);
            }
            
            .cart-icon {
                width: 24px;
                height: 24px;
            }
            
            .cart-count {
                background: var(--accent-color);
                color: white;
                border-radius: 50%;
                width: 18px;
                height: 18px;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 0.7rem;
                position: absolute;
                top: 2px;
                right: 2px;
                font-weight: bold;
            }

            /* Mobile menu button */
            .mobile-menu-btn {
                display: none;
                background: none;
                border: none;
                font-size: 1.5rem;
                color: var(--text-color);
                cursor: pointer;
            }

            /* Main content margin for fixed header */
            main {
                margin-top: 100px;
                min-height: calc(100vh - 400px);
            }

            /* Form Styles */
            .form-container {
                max-width: 500px;
                margin: 2rem auto;
                padding: 2rem;
                background: white;
                border-radius: 10px;
                box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            }

            .form-container h2 {
                text-align: center;
                color: var(--primary-color);
                margin-bottom: 2rem;
                font-size: 2rem;
            }

            .form-group {
                margin-bottom: 1.5rem;
            }

            .form-group label {
                display: block;
                margin-bottom: 0.5rem;
                color: var(--text-color);
                font-weight: 500;
            }

            .form-group input {
                width: 100%;
                padding: 0.75rem 1rem;
                border: 2px solid var(--border-color);
                border-radius: 5px;
                font-size: 1rem;
                transition: border-color 0.3s;
            }

            .form-group input:focus {
                outline: none;
                border-color: var(--primary-color);
            }

            /* Captcha styles */
            .captcha-container {
                background: var(--light-color);
                border-radius: 5px;
                padding: 1rem;
                margin-bottom: 1.5rem;
                display: flex;
                align-items: center;
                gap: 1rem;
                flex-wrap: wrap;
            }

            .captcha-question {
                font-size: 1.2rem;
                font-weight: bold;
                color: var(--primary-color);
                padding: 0.5rem 1rem;
                background: white;
                border-radius: 5px;
                border: 2px solid var(--border-color);
                min-width: 120px;
                text-align: center;
            }

            .captcha-input {
                flex: 1;
                min-width: 150px;
            }

            .captcha-input input {
                width: 100%;
                padding: 0.75rem 1rem;
                border: 2px solid var(--border-color);
                border-radius: 5px;
                font-size: 1rem;
                transition: border-color 0.3s;
            }

            .captcha-input input:focus {
                outline: none;
                border-color: var(--primary-color);
            }

            .refresh-captcha {
                background: none;
                border: 2px solid var(--border-color);
                border-radius: 5px;
                padding: 0.75rem 1rem;
                cursor: pointer;
                color: var(--text-color);
                transition: all 0.3s;
                font-size: 1rem;
                white-space: nowrap;
            }

            .refresh-captcha:hover {
                background: var(--primary-color);
                color: white;
                border-color: var(--primary-color);
            }

            .btn {
                width: 100%;
                padding: 0.75rem;
                background: var(--primary-color);
                color: white;
                border: none;
                border-radius: 5px;
                font-size: 1.1rem;
                cursor: pointer;
                transition: background 0.3s;
            }

            .btn:hover {
                background: var(--secondary-color);
            }

            /* Responsive */
            @media (max-width: 1200px) {
                .header-full-width {
                    padding: 0 1.5rem;
                }
                
                .header-container {
                    gap: 2rem;
                }
                
                nav ul {
                    gap: 1.5rem;
                }
                
                .header-actions {
                    min-width: 250px;
                }
                
                .search-box {
                    min-width: 200px;
                }
            }

            @media (max-width: 992px) {
                .header-container {
                    gap: 1.5rem;
                }
                
                nav {
                    margin: 0 1rem;
                }
                
                nav ul {
                    gap: 1rem;
                }
                
                .header-actions {
                    min-width: 200px;
                }
                
                .search-box {
                    min-width: 180px;
                    margin-right: 0.5rem;
                }
            }

            @media (max-width: 768px) {
                .header-container {
                    flex-wrap: wrap;
                    gap: 1rem;
                }
                
                .mobile-menu-btn {
                    display: block;
                }
                
                nav {
                    order: 3;
                    display: none;
                    width: 100%;
                    margin: 0;
                }
                
                nav.active {
                    display: block;
                }
                
                nav ul {
                    flex-direction: column;
                    gap: 0.5rem;
                    padding: 1rem 0;
                }
                
                .header-actions {
                    min-width: auto;
                    gap: 0.5rem;
                }
                
                .search-box {
                    min-width: 150px;
                }
                
                .logo {
                    min-width: auto;
                }
                
                .logo h1 {
                    font-size: 1.5rem;
                }
                
                .cart-link {
                    padding: 0.3rem;
                }

                main {
                    margin-top: 120px;
                }

                .form-container {
                    margin: 1rem;
                    padding: 1.5rem;
                }

                .captcha-container {
                    flex-direction: column;
                    align-items: stretch;
                }

                .captcha-question {
                    text-align: center;
                }
            }

            @media (max-width: 480px) {
                .header-full-width {
                    padding: 0 1rem;
                }
                
                .search-box {
                    min-width: 120px;
                }
                
                .cart-link {
                    padding: 0.2rem;
                }
            }
        </style>
    </head>
    <body>
        <!-- Header - Full Width -->
        <header>
            <div class="header-full-width">
                <div class="header-container">
                    <button class="mobile-menu-btn">
                        <i class="fas fa-bars"></i>
                    </button>
                    
                    <div class="logo">
                        <h1><?= SITE_NAME ?></h1>
                    </div>
                    
                    <nav id="main-nav">
                        <ul>
                            <li><a href="index.php">Главная</a></li>
                            <li><a href="catalog.php">Обувь</a></li>
                            <li><a href="feedback.php">Обратная связь</a></li>
                            <?php if(isset($_SESSION['user_id'])): ?>
                                <?php if($is_admin): ?>
                                    <li><a href="admin.php" class="admin-link">Админ панель</a></li>
                                <?php endif; ?>
                                <li><a href="profile.php">Личный кабинет</a></li>
                                <li><a href="logout.php">Выйти</a></li>
                            <?php else: ?>
                                <li><a href="login.php">Войти</a></li>
                                <li><a href="register.php" style="color: var(--primary-color);">Регистрация</a></li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                    
                    <div class="header-actions">
                        <div class="search-box">
                            <input type="text" id="searchInput" placeholder="Поиск товаров...">
                            <button onclick="searchProducts()">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                        
                        <a href="cart.php" class="cart-link">
                            <svg class="cart-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path>
                                <line x1="3" y1="6" x2="21" y2="6"></line>
                                <path d="M16 10a4 4 0 0 1-8 0"></path>
                            </svg>
                            <span class="cart-count">0</span>
                        </a>
                    </div>
                </div>
            </div>
        </header>

        <main>
            <div class="form-container">
                <h2>Регистрация</h2>
                
                <?php if (!empty($errors)): ?>
                    <div style="background: #ff6b6b; color: white; padding: 1rem; border-radius: 5px; margin-bottom: 1rem;">
                        <?php foreach ($errors as $error): ?>
                            <p><?= $error ?></p>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
                
                <form method="POST" action="" id="registerForm">
                    <div class="form-group">
                        <label for="username">Имя пользователя:</label>
                        <input type="text" id="username" name="username" value="<?= htmlspecialchars($_POST['username'] ?? '') ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Email:</label>
                        <input type="email" id="email" name="email" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="password">Пароль:</label>
                        <input type="password" id="password" name="password" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="confirm_password">Подтвердите пароль:</label>
                        <input type="password" id="confirm_password" name="confirm_password" required>
                    </div>

                    <!-- Captcha Field -->
                    <div class="form-group">
                        <label>Подтвердите, что вы не робот:</label>
                        <div class="captcha-container">
                            <div class="captcha-question" id="captchaQuestion">
                                <?= $_SESSION['captcha_text'] ?? $captcha['text'] ?>
                            </div>
                            <div class="captcha-input">
                                <input type="text" 
                                       id="captcha" 
                                       name="captcha" 
                                       placeholder="Введите ответ" 
                                       value="<?= htmlspecialchars($_POST['captcha'] ?? '') ?>"
                                       required>
                            </div>
                            <button type="button" class="refresh-captcha" onclick="refreshCaptcha()">
                                <i class="fas fa-sync-alt"></i> Обновить
                            </button>
                        </div>
                    </div>
                    
                    <button type="submit" class="btn">Зарегистрироваться</button>
                </form>
                
                <p style="text-align: center; margin-top: 1rem;">
                    Уже есть аккаунт? <a href="login.php">Войдите</a>
                </p>
            </div>
        </main>

        <script>
            // Mobile menu toggle
            document.querySelector('.mobile-menu-btn').addEventListener('click', function() {
                document.getElementById('main-nav').classList.toggle('active');
            });

            // Close mobile menu when clicking outside
            document.addEventListener('click', function(event) {
                const nav = document.getElementById('main-nav');
                const menuBtn = document.querySelector('.mobile-menu-btn');
                if (!nav.contains(event.target) && !menuBtn.contains(event.target)) {
                    nav.classList.remove('active');
                }
            });

            function searchProducts() {
                const searchTerm = document.getElementById('searchInput').value;
                if (searchTerm.trim()) {
                    window.location.href = `catalog.php?search=${encodeURIComponent(searchTerm)}`;
                }
            }

            // Update cart count (you'll need to implement this based on your cart system)
            function updateCartCount() {
                // This should be implemented based on your cart system
                // For now, it's set to 0
                document.querySelector('.cart-count').textContent = '0';
            }

            // Initialize cart count on page load
            document.addEventListener('DOMContentLoaded', updateCartCount);

            // Search on Enter key
            document.getElementById('searchInput').addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    searchProducts();
                }
            });

            // Refresh captcha function
            function refreshCaptcha() {
                fetch('generate_captcha.php')
                    .then(response => response.json())
                    .then(data => {
                        document.getElementById('captchaQuestion').textContent = data.text;
                    })
                    .catch(error => {
                        console.error('Error refreshing captcha:', error);
                        // Fallback: reload the page to get new captcha
                        location.reload();
                    });
            }

            // Allow only numbers in captcha input
            document.getElementById('captcha').addEventListener('input', function(e) {
                this.value = this.value.replace(/[^0-9\-]/g, '');
            });
        </script>
    </body>
    <footer style="background: var(--primary-color); color: white; padding: 3rem 0; margin-top: 4rem;">
        <div class="container">
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 3rem; margin-bottom: 2rem;">
                <div>
                    <h3 style="color: var(--light-color); margin-bottom: 1rem; font-size: 1.5rem;">VoiceStreetFashion</h3>
                    <p style="line-height: 1.6; opacity: 0.9;">Ваш голос в мире уличной моды. Премиальная обувь от ведущих мировых брендов с доставкой по всей России.</p>
                    <div style="display: flex; gap: 1rem; margin-top: 1rem;">
                        <a href="<?= INSTAGRAM ?>" style="color: white; opacity: 0.8; transition: opacity 0.3s;" onmouseover="this.style.opacity='1'" onmouseout="this.style.opacity='0.8'">
                            Instagram
                        </a>
                        <a href="<?= TELEGRAM ?>" style="color: white; opacity: 0.8; transition: opacity 0.3s;" onmouseover="this.style.opacity='1'" onmouseout="this.style.opacity='0.8'">
                            Telegram
                        </a>
                        <a href="<?= VK ?>" style="color: white; opacity: 0.8; transition: opacity 0.3s;" onmouseover="this.style.opacity='1'" onmouseout="this.style.opacity='0.8'">
                            VK
                        </a>
                    </div>
                </div>
                
                <div>
                    <h4 style="color: var(--light-color); margin-bottom: 1rem;">Контактная информация</h4>
                    <div style="display: flex; flex-direction: column; gap: 0.5rem;">
                        <div style="display: flex; align-items: center; gap: 0.5rem;">
                            <span></span>
                            <span><?= PHONE ?></span>
                        </div>
                        <div style="display: flex; align-items: center; gap: 0.5rem;">
                            <span></span>
                            <span><?= EMAIL ?></span>
                        </div>
                        <div style="display: flex; align-items: center; gap: 0.5rem;">
                            <span></span>
                            <span><?= ADDRESS ?></span>
                        </div>
                    </div>
                </div>
                
                <div>
                    <h4 style="color: var(--light-color); margin-bottom: 1rem;">Полезные ссылки</h4>
                    <div style="display: flex; flex-direction: column; gap: 0.5rem;">
                        <a href="catalog.php" style="color: white; opacity: 0.8; text-decoration: none; transition: opacity 0.3s;" 
                        onmouseover="this.style.opacity='1'" onmouseout="this.style.opacity='0.8'">Каталог обуви</a>
                        <a href="feedback.php" style="color: white; opacity: 0.8; text-decoration: none; transition: opacity 0.3s;" 
                        onmouseover="this.style.opacity='1'" onmouseout="this.style.opacity='0.8'">Обратная связь</a>
                        <a href="login.php" style="color: white; opacity: 0.8; text-decoration: none; transition: opacity 0.3s;" 
                        onmouseover="this.style.opacity='1'" onmouseout="this.style.opacity='0.8'">Личный кабинет</a>
                    </div>
                </div>
                
                <div>
                    <h4 style="color: var(--light-color); margin-bottom: 1rem;">Часы работы</h4>
                    <div style="display: flex; flex-direction: column; gap: 0.5rem; opacity: 0.9;">
                        <div>Пн-Пт: 9:00 - 21:00</div>
                        <div>Сб-Вс: 10:00 - 20:00</div>
                        <div style="margin-top: 0.5rem; font-size: 0.9rem;">Доставка работает ежедневно</div>
                    </div>
                </div>
            </div>
            
            <div style="text-align: center; padding-top: 2rem; border-top: 1px solid rgba(255,255,255,0.2);">
                <p style="margin: 0; opacity: 0.8; font-size: 0.9rem;">
                    &copy; 2026 VoiceStreetFashion. Все права защищены. 
                    <span style="display: block; margin-top: 0.5rem;">
                        Сайт создан для демонстрации возможностей интернет-магазина
                    </span>
                </p>
            </div>
        </div>
    </footer>
    </html>