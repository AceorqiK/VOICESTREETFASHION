<?php
session_start();
require_once 'includes/config.php';

// Простой тест отправки email
$to = 'naxvokee@mail.ru'; 
$subject = 'Тест отправки email от ' . SITE_NAME;
$message = 'Это тестовое письмо для проверки работы email системы.';
$headers = 'From: ' . EMAIL_FROM . "\r\n" .
           'Reply-To: ' . EMAIL . "\r\n" .
           'X-Mailer: PHP/' . phpversion();

if (mail($to, $subject, $message, $headers)) {
    echo "Тестовое письмо отправлено успешно!";
} else {
    $error = error_get_last();
    echo "Ошибка отправки: " . ($error ? $error['message'] : 'Unknown error');
    
    // Дополнительная информация
    echo "<br><br>Информация для отладки:";
    echo "<br>EMAIL_FROM: " . EMAIL_FROM;
    echo "<br>SITE_URL: " . SITE_URL;
    echo "<br>PHP mail function: " . (function_exists('mail') ? 'available' : 'not available');
}
?>
