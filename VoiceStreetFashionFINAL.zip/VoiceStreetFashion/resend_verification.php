<?php
session_start();
require_once 'includes/database.php';
require_once 'includes/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    
    $db = new Database();
    $connection = $db->getConnection();
    
    try {
        // Проверяем существование пользователя
        $stmt = $connection->prepare("SELECT id, username, role FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($user) {
            // Пропускаем проверку для администраторов
            if ($user['role'] === 'admin') {
                $_SESSION['success'] = "Для администраторов подтверждение email не требуется. Можете войти в систему.";
                header("Location: login.php");
                exit;
            }
            
            // Генерируем новый токен
            $new_token = bin2hex(random_bytes(32));
            
            // Обновляем токен
            $stmt = $connection->prepare("UPDATE users SET email_verification_token = ? WHERE id = ?");
            if ($stmt->execute([$new_token, $user['id']])) {
                
                $verification_link = SITE_URL . "/verify_email.php?token=" . $new_token;
                
                $_SESSION['debug_link'] = $verification_link;
                $_SESSION['success'] = "Ссылка для подтверждения (для тестирования):";
                
                header("Location: resend_verification.php");
                exit;
                
            } else {
                $_SESSION['error'] = "Ошибка при обновлении данных.";
            }
        } else {
            $_SESSION['error'] = "Пользователь с таким email не найден.";
        }
    } catch (PDOException $e) {
        $_SESSION['error'] = "Ошибка базы данных: " . $e->getMessage();
    }
    
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Повторная отправка подтверждения - <?= SITE_NAME ?></title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        :root {
            --primary-color: #380F17;
            --secondary-color: #8F0B13;
            --accent-color: #EFDFC5;
            --background-color: #252B2B;
            --text-color: #EFDFC5;
            --light-color: #4C4F54;
        }
        
        body {
            background: var(--background-color);
            color: var(--text-color);
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }
        
        .form-container {
            max-width: 600px;
            margin: 120px auto 2rem;
            padding: 2rem;
            background: var(--primary-color);
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.3);
        }
        
        .form-container h2 {
            text-align: center;
            color: var(--accent-color);
            margin-bottom: 2rem;
        }
        
        .form-group {
            margin-bottom: 1.5rem;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            color: var(--accent-color);
            font-weight: 500;
        }
        
        .form-group input {
            width: 100%;
            padding: 0.75rem 1rem;
            background: var(--background-color);
            border: 1px solid var(--light-color);
            border-radius: 5px;
            font-size: 1rem;
            color: var(--text-color);
            box-sizing: border-box;
        }
        
        .form-group input:focus {
            outline: none;
            border-color: var(--secondary-color);
        }
        
        .btn {
            width: 100%;
            padding: 0.75rem;
            background: var(--secondary-color);
            color: var(--accent-color);
            border: none;
            border-radius: 5px;
            font-size: 1.1rem;
            cursor: pointer;
            transition: background 0.3s;
            font-weight: bold;
        }
        
        .btn:hover {
            background: #9f0c15;
        }
        
        .form-container a {
            color: var(--accent-color);
            text-decoration: none;
        }
        
        .form-container a:hover {
            text-decoration: underline;
        }
        
        .debug-link {
            background: var(--background-color);
            padding: 1rem;
            border-radius: 5px;
            margin: 1rem 0;
            word-break: break-all;
            border: 2px dashed var(--secondary-color);
        }
        
        .debug-link a {
            color: #4ecdc4;
            font-weight: bold;
        }
        
        .info-box {
            background: rgba(143, 11, 19, 0.2);
            border: 1px solid var(--secondary-color);
            border-radius: 5px;
            padding: 1rem;
            margin-bottom: 1rem;
            font-size: 0.9rem;
        }
    </style>
</head>
<body>
    <main>
        <div class="form-container">
            <h2>Повторная отправка подтверждения</h2>
            
            <div class="info-box">
                <strong>Режим тестирования:</strong> Ссылка для подтверждения будет показана на этой странице (email не отправляется).
            </div>
            
            <?php if (isset($_SESSION['error'])): ?>
                <div style="background: #8F0B13; color: white; padding: 1rem; border-radius: 5px; margin-bottom: 1rem;">
                    <p><?= $_SESSION['error'] ?></p>
                </div>
                <?php unset($_SESSION['error']); ?>
            <?php endif; ?>
            
            <?php if (isset($_SESSION['success']) && isset($_SESSION['debug_link'])): ?>
                <div style="background: #27ae60; color: white; padding: 1rem; border-radius: 5px; margin-bottom: 1rem;">
                    <p><?= $_SESSION['success'] ?></p>
                </div>
                <div class="debug-link">
                    <strong>Ссылка для подтверждения:</strong><br>
                    <a href="<?= $_SESSION['debug_link'] ?>" target="_blank"><?= $_SESSION['debug_link'] ?></a>
                    <br><br>
                    <small>Нажмите на ссылку чтобы подтвердить email</small>
                </div>
                <?php 
                unset($_SESSION['success']);
                unset($_SESSION['debug_link']);
                ?>
            <?php elseif (isset($_SESSION['success'])): ?>
                <div style="background: #27ae60; color: white; padding: 1rem; border-radius: 5px; margin-bottom: 1rem;">
                    <p><?= $_SESSION['success'] ?></p>
                </div>
                <?php unset($_SESSION['success']); ?>
            <?php endif; ?>
            
            <form method="POST" action="">
                <div class="form-group">
                    <label for="email">Введите ваш email:</label>
                    <input type="email" id="email" name="email" required placeholder="your@email.com">
                </div>
                
                <button type="submit" class="btn">Получить ссылку подтверждения</button>
            </form>
            
            <p style="text-align: center; margin-top: 1rem;">
                <a href="login.php">Вернуться к входу</a>
            </p>
        </div>
    </main>
</body>
</html>