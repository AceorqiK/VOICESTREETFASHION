<?php
session_start();

function generateMathCaptcha() {
    $operations = ['+', '-', '*'];
    $operation = $operations[array_rand($operations)];
    
    $num1 = rand(1, 10);
    $num2 = rand(1, 10);
    
    // Для вычитания убедимся, что результат положительный
    if ($operation === '-' && $num2 > $num1) {
        list($num1, $num2) = [$num2, $num1];
    }
    
    // Для умножения используем меньшие числа
    if ($operation === '*') {
        $num1 = rand(1, 5);
        $num2 = rand(1, 5);
    }
    
    switch($operation) {
        case '+':
            $result = $num1 + $num2;
            $text = "$num1 + $num2";
            break;
        case '-':
            $result = $num1 - $num2;
            $text = "$num1 - $num2";
            break;
        case '*':
            $result = $num1 * $num2;
            $text = "$num1 × $num2";
            break;
    }
    
    // Сохраняем результат в сессии
    $_SESSION['captcha_result'] = $result;
    $_SESSION['captcha_text'] = $text;
    
    return [
        'text' => $text,
        'result' => $result
    ];
}

// Генерируем новую капчу
$captcha = generateMathCaptcha();

// Возвращаем JSON для AJAX запроса
header('Content-Type: application/json');
echo json_encode([
    'text' => $captcha['text'],
    'result' => $captcha['result']
]);
?>