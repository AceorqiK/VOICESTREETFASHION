<?php
session_start();
require_once 'includes/database.php';
require_once 'includes/config.php';

// Проверка авторизации
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Проверяем, что запрос POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: cart.php");
    exit;
}

try {
    $db = new Database();
    $connection = $db->getConnection();
    $userId = (int)$_SESSION['user_id'];
    
    // Начинаем транзакцию
    $connection->beginTransaction();
    
    // Получаем товары из корзины с ценами из таблицы products
    $stmt = $connection->prepare("
        SELECT c.id as cart_id, c.product_id, c.quantity, c.size, p.price, p.name
        FROM cart c 
        JOIN products p ON c.product_id = p.id 
        WHERE c.user_id = ?
    ");
    $stmt->execute([$userId]);
    $cartItems = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Проверяем, что корзина не пуста
    if (empty($cartItems)) {
        $_SESSION['cart_error'] = "Корзина пуста";
        header("Location: cart.php");
        exit;
    }
    
    // Вычисляем общую сумму
    $totalAmount = 0;
    foreach ($cartItems as $item) {
        $totalAmount += $item['price'] * $item['quantity'];
    }
    
    // Создаем заказ
    $stmt = $connection->prepare("
        INSERT INTO orders (user_id, total_amount, status, created_at) 
        VALUES (?, ?, 'pending', NOW())
    ");
    $stmt->execute([$userId, $totalAmount]);
    $orderId = $connection->lastInsertId();
    
    // Добавляем товары в заказ
    $stmt = $connection->prepare("
        INSERT INTO order_items (order_id, product_id, quantity, size, price) 
        VALUES (?, ?, ?, ?, ?)
    ");
    
    foreach ($cartItems as $item) {
        $stmt->execute([
            $orderId,
            $item['product_id'],
            $item['quantity'],
            $item['size'],
            $item['price']
        ]);
    }
    
    // Очищаем корзину пользователя
    $stmt = $connection->prepare("DELETE FROM cart WHERE user_id = ?");
    $stmt->execute([$userId]);
    
    // Подтверждаем транзакцию
    $connection->commit();
    
    // Устанавливаем сообщение об успехе
    $_SESSION['order_success'] = "Заказ #{$orderId} успешно оформлен! Все товары перемещены в историю заказов.";
    
    // Перенаправляем в профиль
    header("Location: profile.php");
    exit;
    
} catch (Exception $e) {
    // Откатываем транзакцию в случае ошибки
    if (isset($connection) && $connection->inTransaction()) {
        $connection->rollBack();
    }
    
    $_SESSION['cart_error'] = "Ошибка при оформлении заказа. Пожалуйста, попробуйте снова.";
    header("Location: cart.php");
    exit;
}
?>