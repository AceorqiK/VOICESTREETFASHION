<?php
session_start();
require_once 'includes/database.php';
require_once 'includes/config.php';

$db = new Database();
$connection = $db->getConnection();

$token = $_GET['token'] ?? '';

if (empty($token)) {
    $_SESSION['error'] = "Неверная ссылка подтверждения";
    header("Location: login.php");
    exit;
}

try {
    // Проверяем существование колонки email_verification_token
    $check_token = $connection->prepare("SHOW COLUMNS FROM users LIKE 'email_verification_token'");
    $check_token->execute();
    $token_exists = $check_token->fetch();

    if (!$token_exists) {
        $_SESSION['error'] = "Система подтверждения email не настроена. Обратитесь к администратору.";
        header("Location: login.php");
        exit;
    }

    // Ищем пользователя с таким токеном
    $stmt = $connection->prepare("SELECT id, username, email_verified, email_verification_token FROM users WHERE email_verification_token = ?");
    $stmt->execute([$token]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        $_SESSION['error'] = "Неверная или устаревшая ссылка подтверждения";
        header("Location: login.php");
        exit;
    }

    // Проверяем существование колонки email_verified
    $check_verified = $connection->prepare("SHOW COLUMNS FROM users LIKE 'email_verified'");
    $check_verified->execute();
    $verified_exists = $check_verified->fetch();

    if ($verified_exists && $user['email_verified'] == 1) {
        $_SESSION['success'] = "Ваш email уже подтвержден. Можете войти в систему.";
        header("Location: login.php");
        exit;
    }

    // Подтверждаем email
    if ($verified_exists) {
        $stmt = $connection->prepare("UPDATE users SET email_verified = 1, email_verification_token = NULL WHERE id = ?");
    } else {
        $stmt = $connection->prepare("UPDATE users SET email_verification_token = NULL WHERE id = ?");
    }
    
    if ($stmt->execute([$user['id']])) {
        $_SESSION['success'] = "Ваш email успешно подтвержден! Теперь вы можете войти в систему.";
    } else {
        $_SESSION['error'] = "Ошибка при подтверждении email. Попробуйте еще раз или свяжитесь с поддержкой.";
    }
} catch (PDOException $e) {
    $_SESSION['error'] = "Ошибка базы данных: " . $e->getMessage();
}

header("Location: login.php");
exit;
?>
