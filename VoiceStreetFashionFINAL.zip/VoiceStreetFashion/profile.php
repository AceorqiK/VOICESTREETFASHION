<?php
session_start();

// Подключаем security functions
require_once 'includes/security.php';

// Устанавливаем security headers
Security::setSecurityHeaders();

// Генерируем CSRF токен
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = Security::generateCSRFToken();
}

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

require_once 'includes/database.php';

$db = new Database();
$connection = $db->getConnection();

// Функция для получения количества товаров в корзине
function getCartCount($connection, $userId) {
    try {
        // Проверяем существует ли таблица cart
        $checkTable = $connection->query("SHOW TABLES LIKE 'cart'");
        if ($checkTable->rowCount() == 0) {
            return 0;
        }
        
        $stmt = $connection->prepare("
            SELECT COALESCE(SUM(quantity), 0) as total_items 
            FROM cart 
            WHERE user_id = ?
        ");
        $stmt->execute([(int)$userId]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return (int)($result['total_items'] ?? 0);
    } catch (Exception $e) {
        error_log("Error getting cart count: " . $e->getMessage());
        return 0;
    }
}

// Получаем количество товаров в корзине
$cartCount = getCartCount($connection, $_SESSION['user_id']);

// Получение заказов пользователя
$stmt = $connection->prepare("
    SELECT o.*, COUNT(oi.id) as items_count 
    FROM orders o 
    LEFT JOIN order_items oi ON o.id = oi.order_id 
    WHERE o.user_id = ? 
    GROUP BY o.id 
    ORDER BY o.created_at DESC
");
$stmt->execute([(int)$_SESSION['user_id']]);
$orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Проверяем сообщение об успешном заказе
$order_success = '';
if (isset($_SESSION['order_success'])) {
    $order_success = $_SESSION['order_success'];
    unset($_SESSION['order_success']);
}

// Получение данных пользователя для формы
$user_stmt = $connection->prepare("SELECT phone, address FROM users WHERE id = ?");
$user_stmt->execute([(int)$_SESSION['user_id']]);
$user_data = $user_stmt->fetch(PDO::FETCH_ASSOC);

$errors = [];
$success = "";

// Обновление профиля с защитой от SQL-инъекций и XSS
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    
    // Проверка CSRF токена
    if (!Security::verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $errors[] = "Недействительный токен безопасности";
        error_log("CSRF attempt detected in profile update from IP: " . ($_SERVER['REMOTE_ADDR'] ?? 'unknown'));
    }
    
    // Валидация и санация данных
    $phone = isset($_POST['phone']) ? Security::sanitizeString($_POST['phone']) : '';
    $address = isset($_POST['address']) ? Security::sanitizeString($_POST['address']) : '';
    
    // Валидация телефона
    if (!empty($phone) && !preg_match('/^[\d\s\-\+\(\)]+$/', $phone)) {
        $errors[] = "Некорректный формат телефона";
    }
    
    // Валидация адреса
    if (!empty($address) && strlen($address) > 500) {
        $errors[] = "Адрес слишком длинный (максимум 500 символов)";
    }
    
    if (empty($errors)) {
        try {
            $stmt = $connection->prepare("UPDATE users SET phone = ?, address = ? WHERE id = ?");
            if ($stmt->execute([$phone, $address, (int)$_SESSION['user_id']])) {
                $success = "Профиль успешно обновлен";
                // Обновляем данные в сессии если нужно
                $_SESSION['phone'] = $phone;
                $_SESSION['address'] = $address;
            } else {
                $errors[] = "Ошибка при обновлении профиля";
            }
        } catch (Exception $e) {
            error_log("Database error in profile update: " . $e->getMessage());
            $errors[] = "Ошибка базы данных при обновлении профиля";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Личный кабинет - VoiceStreetFashion</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #000;
            --secondary-color: #111;
            --accent-color: #555;
            --light-color: #eee;
            --text-color: #333;
            --success-color: #28a745;
            --border-color: #ddd;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: var(--light-color);
        }
        
        /* Header Styles - Full Width */
        header {
            background: white;
            box-shadow: 0 2px 20px rgba(0,0,0,0.1);
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            padding: 0.5rem 0;
            width: 100%;
        }
        
        .header-full-width {
            max-width: 100%;
            margin: 0;
            padding: 0 2rem;
        }
        
        .header-container {
            display: flex;
            align-items: center;
            justify-content: space-between;
            width: 100%;
            gap: 3rem;
        }
        
        .logo {
            display: flex;
            flex-direction: column;
            align-items: flex-start;
            min-width: 200px;
        }
        
        .logo h1 {
            color: var(--primary-color) !important;
            font-size: 1.8rem;
            font-weight: bold;
            margin: 0;
            line-height: 1;
            white-space: nowrap;
        }
        
        .logo span {
            color: var(--secondary-color);
            font-size: 0.8rem;
            margin-top: 2px;
        }
        
        nav {
            flex: 1;
            display: flex;
            justify-content: center;
            margin: 0 2rem;
        }
        
        nav ul {
            display: flex;
            list-style: none;
            margin: 0;
            padding: 0;
            gap: 2rem;
        }
        
        nav a {
            text-decoration: none;
            color: var(--text-color);
            font-weight: 500;
            font-size: 1rem;
            transition: color 0.3s;
            position: relative;
            white-space: nowrap;
            padding: 0.5rem 0;
        }
        
        nav a:hover {
            color: var(--primary-color);
        }
        
        nav a::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 0;
            height: 2px;
            background: var(--primary-color);
            transition: width 0.3s;
        }
        
        nav a:hover::after {
            width: 100%;
        }
        
        .header-actions {
            display: flex;
            align-items: center;
            gap: 1rem;
            min-width: 300px;
            justify-content: flex-end;
        }
        
        .search-box {
            display: flex;
            background: var(--light-color);
            border-radius: 25px;
            padding: 0.4rem;
            border: 2px solid transparent;
            transition: border-color 0.3s;
            min-width: 250px;
            margin-right: 1rem;
        }
        
        .search-box:focus-within {
            border-color: var(--primary-color);
        }
        
        .search-box input {
            border: none;
            background: none;
            outline: none;
            padding: 0 1rem;
            width: 100%;
            font-size: 0.9rem;
        }
        
        .search-box button {
            background: var(--primary-color);
            color: white;
            border: none;
            padding: 0.4rem 1rem;
            border-radius: 20px;
            cursor: pointer;
            font-size: 0.9rem;
            transition: background 0.3s;
            white-space: nowrap;
        }
        
        .search-box button:hover {
            background: var(--secondary-color);
        }
        
        .cart-link {
            display: flex;
            align-items: center;
            text-decoration: none;
            color: var(--text-color);
            transition: color 0.3s;
            padding: 0.5rem;
            position: relative;
            background: none !important;
        }
        
        .cart-link:hover {
            color: var(--primary-color);
        }
        
        .cart-icon {
            width: 24px;
            height: 24px;
        }
        
        .cart-count {
            background: var(--accent-color);
            color: white;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.75rem;
            position: absolute;
            top: -5px;
            right: -5px;
            font-weight: bold;
            transition: transform 0.2s ease;
            border: 2px solid white;
        }

        /* Mobile menu button */
        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            font-size: 1.5rem;
            color: var(--text-color);
            cursor: pointer;
        }

        /* Main content margin for fixed header */
        main {
            margin-top: 80px;
            min-height: calc(100vh - 80px);
            padding: 2rem 0;
            background: var(--light-color);
        }

        /* Profile Styles */
        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 0 20px;
        }
        
        .profile-layout {
            display: flex;
            flex-direction: column;
            gap: 2rem;
        }
        
        .form-container {
            background: white;
            padding: 2rem;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            width: 100%;
        }
        
        .form-container h3 {
            color: var(--primary-color);
            margin-bottom: 1.5rem;
            font-size: 1.5rem;
            border-bottom: 2px solid var(--light-color);
            padding-bottom: 0.5rem;
        }
        
        .profile-form {
            display: flex;
            flex-direction: column;
            gap: 1.5rem;
        }
        
        .form-group {
            margin-bottom: 0;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            color: var(--text-color);
            font-weight: 500;
            font-size: 1rem;
        }
        
        .form-group input,
        .form-group textarea {
            width: 100%;
            padding: 0.75rem;
            border: 2px solid var(--border-color);
            border-radius: 8px;
            font-size: 1rem;
            transition: border-color 0.3s;
            box-sizing: border-box;
        }
        
        .form-group input:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: var(--primary-color);
        }
        
        .form-group input:disabled {
            background-color: var(--light-color);
            color: var(--accent-color);
        }
        
        .form-group textarea {
            height: 100px;
            resize: vertical;
            font-family: inherit;
        }
        
        .btn {
            background: var(--primary-color);
            color: white;
            border: none;
            padding: 1rem 2rem;
            border-radius: 8px;
            cursor: pointer;
            font-size: 1rem;
            font-weight: 600;
            transition: all 0.3s ease;
            width: 100%;
            margin-top: 1rem;
        }
        
        .btn:hover {
            background: var(--secondary-color);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        
        .btn-small {
            width: auto;
            padding: 0.5rem 1rem;
            font-size: 0.9rem;
            margin-top: 0.5rem;
            text-decoration: none;
            display: inline-block;
        }
        
        .success-message {
            background: #d4edda;
            color: #155724;
            padding: 1rem 1.5rem;
            border-radius: 12px;
            border: 2px solid #c3e6cb;
            margin-bottom: 1.5rem;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            animation: slideDown 0.5s ease;
        }
        
        .error-message {
            background: #f8d7da;
            color: #721c24;
            padding: 1rem 1.5rem;
            border-radius: 12px;
            border: 2px solid #f5c6cb;
            margin-bottom: 1.5rem;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            animation: slideDown 0.5s ease;
        }
        
        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .orders-list {
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }
        
        .order-item {
            border: 2px solid var(--border-color);
            padding: 1.5rem;
            border-radius: 12px;
            transition: all 0.3s ease;
            background: white;
        }
        
        .order-item:hover {
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
            transform: translateY(-3px);
            border-color: var(--primary-color);
        }
        
        .order-status {
            padding: 0.4rem 1rem;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: bold;
            display: inline-block;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .status-pending { background: #fff3cd; color: #856404; }
        .status-processing { background: #cce7ff; color: #004085; }
        .status-shipped { background: #d4edda; color: #155724; }
        .status-delivered { background: #d1ecf1; color: #0c5460; }
        .status-cancelled { background: #f8d7da; color: #721c24; }
        
        h2 {
            color: var(--primary-color);
            text-align: center;
            margin-bottom: 2rem;
            font-size: 2rem;
        }
        
        .no-orders {
            text-align: center;
            color: var(--accent-color);
            font-style: italic;
            padding: 3rem 2rem;
            background: var(--light-color);
            border-radius: 12px;
        }
        
        .order-details-btn {
            background: var(--primary-color);
            color: white;
            border: none;
            padding: 0.6rem 1.2rem;
            border-radius: 8px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            margin-top: 1rem;
            transition: all 0.3s ease;
            font-size: 0.9rem;
            font-weight: 500;
        }
        
        .order-details-btn:hover {
            background: var(--secondary-color);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        
        .order-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 1rem;
        }
        
        .order-info {
            flex: 1;
        }
        
        .order-meta {
            text-align: right;
        }
        
        .order-title {
            font-size: 1.2rem;
            font-weight: bold;
            color: var(--primary-color);
            margin: 0 0 0.5rem 0;
        }
        
        .order-date {
            color: var(--accent-color);
            margin: 0.3rem 0;
            font-size: 0.9rem;
        }
        
        .order-items {
            color: var(--text-color);
            margin: 0.3rem 0;
            font-size: 0.9rem;
        }
        
        .order-amount {
            font-size: 1.3rem;
            font-weight: bold;
            color: var(--primary-color);
            margin: 0.5rem 0 0 0;
        }

        /* Footer Styles */
        footer {
            background: var(--primary-color);
            color: white;
            padding: 3rem 0;
            margin-top: 4rem;
        }
        
        .footer-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 3rem;
            margin-bottom: 2rem;
        }
        
        .footer-column h3 {
            color: var(--light-color);
            margin-bottom: 1rem;
            font-size: 1.5rem;
        }
        
        .footer-column h4 {
            color: var(--light-color);
            margin-bottom: 1rem;
        }
        
        .footer-links {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }
        
        .footer-links a {
            color: white;
            opacity: 0.8;
            text-decoration: none;
            transition: opacity 0.3s;
        }
        
        .footer-links a:hover {
            opacity: 1;
        }
        
        .footer-bottom {
            text-align: center;
            padding-top: 2rem;
            border-top: 1px solid rgba(255,255,255,0.2);
        }
        
        .footer-bottom p {
            margin: 0;
            opacity: 0.8;
            font-size: 0.9rem;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .header-container {
                flex-wrap: wrap;
                gap: 1rem;
            }
            
            .mobile-menu-btn {
                display: block;
            }
            
            nav {
                order: 3;
                display: none;
                width: 100%;
                margin: 0;
            }
            
            nav.active {
                display: block;
            }
            
            nav ul {
                flex-direction: column;
                gap: 0.5rem;
                padding: 1rem 0;
            }
            
            .header-actions {
                min-width: auto;
                gap: 0.5rem;
            }
            
            .search-box {
                min-width: 150px;
            }
            
            .logo {
                min-width: auto;
            }
            
            .logo h1 {
                font-size: 1.5rem;
            }
            
            .order-header {
                flex-direction: column;
                gap: 1rem;
            }
            
            .order-meta {
                text-align: left;
            }
            
            .form-container {
                padding: 1.5rem;
            }
        }
    </style>
</head>
<body>
    <!-- Header - Full Width -->
    <header>
        <div class="header-full-width">
            <div class="header-container">
                <button class="mobile-menu-btn">
                    <i class="fas fa-bars"></i>
                </button>
                
                <div class="logo">
                    <h1>VoiceStreetFashion</h1>
                </div>
                
                <nav id="main-nav">
                    <ul>
                        <li><a href="index.php">Главная</a></li>
                        <li><a href="catalog.php">Обувь</a></li>
                        <li><a href="feedback.php">Обратная связь</a></li>
                        <?php if(isset($_SESSION['user_id'])): ?>
                            <li><a href="profile.php" style="color: var(--primary-color); font-weight: 700;">Личный кабинет</a></li>
                            <li><a href="logout.php">Выйти</a></li>
                        <?php else: ?>
                            <li><a href="login.php">Войти</a></li>
                            <li><a href="register.php">Регистрация</a></li>
                        <?php endif; ?>
                    </ul>
                </nav>
                
                <div class="header-actions">
                    <div class="search-box">
                        <input type="text" id="searchInput" placeholder="Поиск товаров...">
                        <button onclick="searchProducts()">
                            <i class="fas fa-search"></i>
                        </button>
                    </div>
                    
                    <a href="cart.php" class="cart-link">
                        <svg class="cart-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path>
                            <line x1="3" y1="6" x2="21" y2="6"></line>
                            <path d="M16 10a4 4 0 0 1-8 0"></path>
                        </svg>
                        <span class="cart-count" id="cart-count"><?= $cartCount ?></span>
                    </a>
                </div>
            </div>
        </div>
    </header>
    
    <main>
        <div class="container">
            <h2>Личный кабинет</h2>
            <?php
// Проверяем сообщение об успешном заказе
$order_success = '';
if (isset($_SESSION['order_success'])) {
    $order_success = $_SESSION['order_success'];
    unset($_SESSION['order_success']);
}
?>

<?php if (!empty($order_success)): ?>
    <div style="background: #d4edda; color: #155724; padding: 1rem 1.5rem; border-radius: 12px; border: 2px solid #c3e6cb; margin-bottom: 2rem; font-weight: 500; display: flex; align-items: center; gap: 0.5rem; max-width: 800px; margin-left: auto; margin-right: auto;">
        <i class="fas fa-check-circle"></i>
        <?= htmlspecialchars($order_success, ENT_QUOTES, 'UTF-8') ?>
    </div>
<?php endif; ?>
            <!-- Сообщение об успешном оформлении заказа -->
            <?php if (!empty($order_success)): ?>
                <div class="success-message" style="margin-bottom: 2rem;">
                    <i class="fas fa-check-circle"></i>
                    <?= htmlspecialchars($order_success, ENT_QUOTES, 'UTF-8') ?>
                </div>
            <?php endif; ?>
            
            <div class="profile-layout">
                <!-- Информация о пользователе -->
                <div class="form-container">
                    <h3>Мой профиль</h3>
                    
                    <form method="POST" action="" class="profile-form">
                        <!-- CSRF защита -->
                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8') ?>">
                        
                        <?php if (!empty($success)): ?>
                            <div class="success-message">
                                <i class="fas fa-check-circle"></i>
                                <?= htmlspecialchars($success, ENT_QUOTES, 'UTF-8') ?>
                            </div>
                        <?php endif; ?>
                        
                        <?php if (!empty($errors)): ?>
                            <div class="error-message">
                                <i class="fas fa-exclamation-circle"></i>
                                <div>
                                    <?php foreach ($errors as $error): ?>
                                        <p><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></p>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        <?php endif; ?>
                        
                        <div class="form-group">
                            <label>Имя пользователя:</label>
                            <input type="text" value="<?= htmlspecialchars($_SESSION['username'] ?? '', ENT_QUOTES, 'UTF-8') ?>" disabled>
                        </div>
                        
                        <div class="form-group">
                            <label>Email:</label>
                            <input type="email" value="<?= htmlspecialchars($_SESSION['email'] ?? '', ENT_QUOTES, 'UTF-8') ?>" disabled>
                        </div>
                        
                        <div class="form-group">
                            <label for="phone">Телефон:</label>
                            <input type="tel" id="phone" name="phone" 
                                   value="<?= htmlspecialchars($user_data['phone'] ?? '', ENT_QUOTES, 'UTF-8') ?>"
                                   pattern="[\d\s\-\+\(\)]+"
                                   title="Разрешены только цифры, пробелы, дефисы, плюсы и скобки"
                                   maxlength="20"
                                   placeholder="+7 (999) 123-45-67">
                            <small style="color: var(--accent-color); font-size: 0.8rem; display: block; margin-top: 0.25rem;">Формат: +7 (999) 123-45-67</small>
                        </div>
                        
                        <div class="form-group">
                            <label for="address">Адрес доставки:</label>
                            <textarea id="address" name="address" maxlength="500" placeholder="Введите ваш адрес для доставки"><?= htmlspecialchars($user_data['address'] ?? '', ENT_QUOTES, 'UTF-8') ?></textarea>
                            <small style="color: var(--accent-color); font-size: 0.8rem; display: block; margin-top: 0.25rem;">Максимум 500 символов</small>
                        </div>
                        
                        <button type="submit" name="update_profile" class="btn">Обновить профиль</button>
                    </form>
                </div>
                
                <!-- История заказов -->
                <div class="form-container">
                    <h3>Мои заказы</h3>
                    
                    <?php if (empty($orders)): ?>
                        <div class="no-orders">
                            <i class="fas fa-shopping-bag" style="font-size: 3rem; color: var(--border-color); margin-bottom: 1rem; display: block;"></i>
                            <p style="font-size: 1.1rem; margin-bottom: 1.5rem;">У вас пока нет заказов</p>
                            <a href="catalog.php" class="btn btn-small">Перейти к покупкам</a>
                        </div>
                    <?php else: ?>
                        <div class="orders-list">
                            <?php foreach ($orders as $order): 
                                // Определяем класс статуса
                                $statusClass = '';
                                $statusLabel = '';
                                switch($order['status']) {
                                    case 'pending':
                                        $statusClass = 'status-pending';
                                        $statusLabel = 'Ожидает';
                                        break;
                                    case 'processing':
                                        $statusClass = 'status-processing';
                                        $statusLabel = 'В обработке';
                                        break;
                                    case 'shipped':
                                        $statusClass = 'status-shipped';
                                        $statusLabel = 'Отправлен';
                                        break;
                                    case 'delivered':
                                        $statusClass = 'status-delivered';
                                        $statusLabel = 'Доставлен';
                                        break;
                                    case 'cancelled':
                                        $statusClass = 'status-cancelled';
                                        $statusLabel = 'Отменен';
                                        break;
                                    default:
                                        $statusClass = 'status-pending';
                                        $statusLabel = $order['status'];
                                }
                            ?>
                                <div class="order-item">
                                    <div class="order-header">
                                        <div class="order-info">
                                            <h4 class="order-title">Заказ #<?= htmlspecialchars($order['id'], ENT_QUOTES, 'UTF-8') ?></h4>
                                            <p class="order-date">
                                                <i class="far fa-calendar-alt"></i> 
                                                <?= htmlspecialchars(date('d.m.Y H:i', strtotime($order['created_at'] ?? $order['order_date'] ?? 'now')), ENT_QUOTES, 'UTF-8') ?>
                                            </p>
                                            <p class="order-items">
                                                <i class="fas fa-box"></i> 
                                                Товаров: <?= htmlspecialchars($order['items_count'], ENT_QUOTES, 'UTF-8') ?>
                                            </p>
                                        </div>
                                        <div class="order-meta">
                                            <span class="order-status <?= $statusClass ?>"><?= $statusLabel ?></span>
                                            <p class="order-amount"><?= htmlspecialchars(number_format($order['total_amount'], 0, ',', ' '), ENT_QUOTES, 'UTF-8') ?> ₽</p>
                                        </div>
                                    </div>
                                    <a href="order_details.php?id=<?= (int)$order['id'] ?>" class="order-details-btn">
                                        Подробнее о заказе
                                    </a>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </main>

    <footer>
        <div class="container">
            <div class="footer-grid">
                <div class="footer-column">
                    <h3>VoiceStreetFashion</h3>
                    <p style="line-height: 1.6; opacity: 0.9;">Ваш голос в мире уличной моды. Премиальная обувь от ведущих мировых брендов с доставкой по всей России.</p>
                    <div style="display: flex; gap: 1rem; margin-top: 1rem;">
                        <a href="#" style="color: white; opacity: 0.8; transition: opacity 0.3s;" onmouseover="this.style.opacity='1'" onmouseout="this.style.opacity='0.8'">Instagram</a>
                        <a href="#" style="color: white; opacity: 0.8; transition: opacity 0.3s;" onmouseover="this.style.opacity='1'" onmouseout="this.style.opacity='0.8'">Telegram</a>
                        <a href="#" style="color: white; opacity: 0.8; transition: opacity 0.3s;" onmouseover="this.style.opacity='1'" onmouseout="this.style.opacity='0.8'">VK</a>
                    </div>
                </div>
                
                <div class="footer-column">
                    <h4>Контактная информация</h4>
                    <div class="footer-links">
                        <div>+7 (999) 123-45-67</div>
                        <div>info@voicestreet.ru</div>
                        <div>Москва, ул. Примерная, 123</div>
                    </div>
                </div>
                
                <div class="footer-column">
                    <h4>Полезные ссылки</h4>
                    <div class="footer-links">
                        <a href="catalog.php">Каталог обуви</a>
                        <a href="feedback.php">Обратная связь</a>
                        <a href="profile.php">Личный кабинет</a>
                    </div>
                </div>
                
                <div class="footer-column">
                    <h4>Часы работы</h4>
                    <div style="display: flex; flex-direction: column; gap: 0.5rem; opacity: 0.9;">
                        <div>Пн-Пт: 9:00 - 21:00</div>
                        <div>Сб-Вс: 10:00 - 20:00</div>
                        <div style="margin-top: 0.5rem; font-size: 0.9rem;">Доставка работает ежедневно</div>
                    </div>
                </div>
            </div>
            <div class="footer-bottom">
                <p>
                    &copy; 2026 VoiceStreetFashion. Все права защищены.
                    <span style="display: block; margin-top: 0.5rem;">
                        Сайт создан для демонстрации возможностей интернет-магазина
                    </span>
                </p>
            </div>
        </div>
    </footer>

    <script>
        // Mobile menu toggle
        document.querySelector('.mobile-menu-btn').addEventListener('click', function() {
            document.getElementById('main-nav').classList.toggle('active');
        });

        // Close mobile menu when clicking outside
        document.addEventListener('click', function(event) {
            const nav = document.getElementById('main-nav');
            const menuBtn = document.querySelector('.mobile-menu-btn');
            if (!nav.contains(event.target) && !menuBtn.contains(event.target)) {
                nav.classList.remove('active');
            }
        });

        function searchProducts() {
            const searchTerm = document.getElementById('searchInput').value.trim();
            if (searchTerm) {
                const cleanSearchTerm = searchTerm.replace(/[<>&"']/g, '');
                window.location.href = `catalog.php?search=${encodeURIComponent(cleanSearchTerm)}`;
            }
        }

        // Search on Enter key
        document.getElementById('searchInput').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                searchProducts();
            }
        });

        // Функция обновления счетчика корзины
        function updateCartCount() {
            const cartCountElement = document.getElementById('cart-count');
            const currentCount = parseInt(cartCountElement.textContent);
            
            // Обновляем классы в зависимости от количества
            if (currentCount === 0) {
                cartCountElement.style.background = '#999';
                cartCountElement.style.opacity = '0.7';
            } else if (currentCount > 5) {
                cartCountElement.style.background = '#ff4444';
                cartCountElement.style.opacity = '1';
            } else {
                cartCountElement.style.background = 'var(--accent-color)';
                cartCountElement.style.opacity = '1';
            }
        }

        // Функция для получения актуального количества товаров через AJAX
        function refreshCartCount() {
            fetch('get_cart_count.php')
                .then(response => response.json())
                .then(data => {
                    if (data.count !== undefined) {
                        const cartCountElement = document.getElementById('cart-count');
                        const oldCount = parseInt(cartCountElement.textContent);
                        const newCount = data.count;
                        
                        if (oldCount !== newCount) {
                            cartCountElement.textContent = newCount;
                            updateCartCount();
                        }
                    }
                })
                .catch(error => console.error('Error updating cart count:', error));
        }

        // Валидация формы на стороне клиента
        document.addEventListener('DOMContentLoaded', function() {
            updateCartCount();
            
            // Обновляем счетчик каждые 30 секунд
            setInterval(refreshCartCount, 30000);
            
            const form = document.querySelector('.profile-form');
            if (form) {
                form.addEventListener('submit', function(e) {
                    const phone = document.getElementById('phone').value;
                    const address = document.getElementById('address').value;
                    
                    if (phone && !/^[\d\s\-\+\(\)]+$/.test(phone)) {
                        e.preventDefault();
                        alert('Некорректный формат телефона. Разрешены только цифры, пробелы, дефисы, плюсы и скобки.');
                        return false;
                    }
                    
                    if (address.length > 500) {
                        e.preventDefault();
                        alert('Адрес слишком длинный. Максимум 500 символов.');
                        return false;
                    }
                    
                    if (/<script|javascript:|onclick|onload|onerror/i.test(address)) {
                        e.preventDefault();
                        alert('Обнаружены недопустимые символы в адресе');
                        return false;
                    }
                });
            }
            
            // Счетчик символов для адреса
            const addressTextarea = document.getElementById('address');
            if (addressTextarea) {
                const small = addressTextarea.nextElementSibling;
                addressTextarea.addEventListener('input', function() {
                    const remaining = 500 - this.value.length;
                    small.textContent = `Осталось символов: ${remaining}`;
                    if (remaining < 50) {
                        small.style.color = '#ff6b6b';
                    } else {
                        small.style.color = 'var(--accent-color)';
                    }
                });
            }
        });

        // Обновляем счетчик при возвращении на страницу
        window.addEventListener('focus', function() {
            refreshCartCount();
        });
    </script>
</body>
</html>