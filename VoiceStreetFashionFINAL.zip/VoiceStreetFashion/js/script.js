// Анимации и взаимодействия
document.addEventListener('DOMContentLoaded', function() {
    // Инициализация категорий
    initCategories();
    
    // Загрузка недавно купленных товаров
    loadRecentProducts();
    
    // Инициализация корзины
    initCart();
});

// Функция поиска
function searchProducts() {
    const searchTerm = document.getElementById('searchInput').value;
    if (searchTerm.trim()) {
        window.location.href = `catalog.php?search=${encodeURIComponent(searchTerm)}`;
    }
}

// Инициализация категорий
function initCategories() {
    const categoryCards = document.querySelectorAll('.category-card');
    categoryCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-10px) scale(1.05)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0) scale(1)';
        });
    });
}

// Загрузка недавно купленных товаров
function loadRecentProducts() {
    fetch('api/get_recent_products.php')
        .then(response => response.json())
        .then(products => {
            const container = document.getElementById('recentProducts');
            if (container && products.length > 0) {
                container.innerHTML = products.map(product => `
                    <div class="product-card" onclick="window.location.href='product.php?id=${product.id}'">
                        <div class="product-image">
                            <img src="${product.image_url}" alt="${product.name}">
                        </div>
                        <div class="product-info">
                            <h3>${product.name}</h3>
                            <div class="product-price">${product.price} ₽</div>
                            <div class="product-meta">
                                <span>${product.brand}</span>
                                <span>${product.in_stock ? 'В наличии' : 'Под заказ'}</span>
                            </div>
                        </div>
                    </div>
                `).join('');
            }
        })
        .catch(error => console.error('Error loading recent products:', error));
}

// Функции корзины
function initCart() {
    updateCartCounter();
}

function addToCart(productId, size = null) {
    const formData = new FormData();
    formData.append('product_id', productId);
    if (size) formData.append('size', size);
    
    fetch('api/add_to_cart.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            updateCartCounter();
            showNotification('Товар добавлен в корзину!', 'success');
        } else {
            showNotification('Ошибка при добавлении в корзину', 'error');
        }
    });
}

function updateCartCounter() {
    fetch('api/get_cart_count.php')
        .then(response => response.json())
        .then(data => {
            const cartLink = document.querySelector('.cart-link');
            if (cartLink && data.count > 0) {
                cartLink.textContent = `Корзина (${data.count})`;
            }
        });
}

function updateQuantity(itemId, change) {
    const quantityInput = document.querySelector(`.quantity-input[data-item-id="${itemId}"]`);
    let newQuantity = parseInt(quantityInput.value) + change;
    
    if (newQuantity < 1) newQuantity = 1;
    
    fetch('api/update_cart_quantity.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            item_id: itemId,
            quantity: newQuantity
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            quantityInput.value = newQuantity;
            updateCartTotal();
        }
    });
}

function removeFromCart(itemId) {
    if (confirm('Удалить товар из корзины?')) {
        fetch('api/remove_from_cart.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ item_id: itemId })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                document.querySelector(`.cart-item[data-item-id="${itemId}"]`).remove();
                updateCartCounter();
                updateCartTotal();
            }
        });
    }
}

function updateCartTotal() {
    // Обновление общей суммы корзины
    let total = 0;
    document.querySelectorAll('.cart-item').forEach(item => {
        const price = parseFloat(item.querySelector('.item-price').textContent);
        const quantity = parseInt(item.querySelector('.quantity-input').value);
        total += price * quantity;
    });
    
    document.querySelector('.cart-total').textContent = `Итого: ${total.toFixed(2)} ₽`;
}

// Уведомления
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 1rem 2rem;
        background: ${type === 'success' ? '#4ecdc4' : type === 'error' ? '#ff6b6b' : '#333'};
        color: white;
        border-radius: 5px;
        z-index: 10000;
        animation: slideIn 0.3s ease;
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.remove();
    }, 3000);
}

// Фильтрация товаров
function applyFilters() {
    const formData = new FormData(document.getElementById('filtersForm'));
    const params = new URLSearchParams(formData);
    
    window.location.href = `catalog.php?${params.toString()}`;
}

function clearFilters() {
    window.location.href = 'catalog.php';
}// Функции для работы с отзывами
function loadProductReviews(productId) {
    fetch(`api/get_product_reviews.php?product_id=${productId}`)
        .then(response => response.json())
        .then(reviews => {
            updateReviewsDisplay(reviews);
        })
        .catch(error => console.error('Error loading reviews:', error));
}

function submitReview(productId, rating, comment) {
    const formData = new FormData();
    formData.append('product_id', productId);
    formData.append('rating', rating);
    formData.append('comment', comment);
    
    fetch('api/add_review.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showNotification('Отзыв успешно добавлен!', 'success');
            // Обновляем отображение отзывов
            loadProductReviews(productId);
        } else {
            showNotification(data.message, 'error');
        }
    });
}

// Функции для расширенной фильтрации
function toggleFilterSection(sectionId) {
    const section = document.getElementById(sectionId);
    section.classList.toggle('collapsed');
}

// Инициализация звезд рейтинга
function initStarRating() {
    const stars = document.querySelectorAll('.star-rating .star');
    stars.forEach(star => {
        star.addEventListener('mouseover', function() {
            const rating = this.dataset.rating;
            highlightStars(rating);
        });
        
        star.addEventListener('mouseout', function() {
            const currentRating = document.querySelector('.star-rating').dataset.currentRating || 0;
            highlightStars(currentRating);
        });
        
        star.addEventListener('click', function() {
            const rating = this.dataset.rating;
            document.querySelector('.star-rating').dataset.currentRating = rating;
            document.getElementById('ratingInput').value = rating;
            highlightStars(rating);
        });
    });
}

function highlightStars(rating) {
    const stars = document.querySelectorAll('.star-rating .star');
    stars.forEach((star, index) => {
        star.textContent = index < rating ? '★' : '☆';
    });
}
