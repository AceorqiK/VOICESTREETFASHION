<?php
session_start();
require_once 'includes/database.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$cart_id = $_POST['cart_id'] ?? $_GET['cart_id'] ?? null;

if (!$cart_id) {
    $_SESSION['cart_error'] = 'Не указан товар для удаления';
    header("Location: cart.php");
    exit;
}

try {
    $db = new Database();
    $connection = $db->getConnection();
    
    // Проверяем, принадлежит ли товар текущему пользователю
    $stmt = $connection->prepare("SELECT * FROM cart WHERE id = ? AND user_id = ?");
    $stmt->execute([$cart_id, $_SESSION['user_id']]);
    $cart_item = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$cart_item) {
        $_SESSION['cart_error'] = 'Товар не найден в вашей корзине';
        header("Location: cart.php");
        exit;
    }
    
    // Удаляем товар из корзины
    $stmt = $connection->prepare("DELETE FROM cart WHERE id = ? AND user_id = ?");
    $stmt->execute([$cart_id, $_SESSION['user_id']]);
    
    $_SESSION['cart_success'] = 'Товар успешно удален из корзины!';
    header("Location: cart.php");
    exit;
    
} catch (Exception $e) {
    $_SESSION['cart_error'] = 'Ошибка при удалении товара из корзины: ' . $e->getMessage();
    header("Location: cart.php");
    exit;
}
?>
