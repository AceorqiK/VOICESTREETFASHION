<?php
session_start();

// Подсчет количества товаров в корзине
$cart_count = 0;
if (isset($_SESSION['cart']) && is_array($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $item) {
        $cart_count += isset($item['quantity']) ? $item['quantity'] : 1;
    }
}

require_once 'includes/database.php';

$db = new Database();
$connection = $db->getConnection();

// Проверяем, является ли пользователь администратором
$is_admin = false;
if(isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $stmt = $connection->prepare("SELECT role FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($user) {
        $is_admin = ($user['role'] === 'admin');
        $_SESSION['is_admin'] = $is_admin;
    }
}

$product_id = $_GET['id'] ?? null;

if (!$product_id) {
    header("Location: catalog.php");
    exit;
}

// Получение информации о товаре
$stmt = $connection->prepare("SELECT * FROM products WHERE id = ?");
$stmt->execute([$product_id]);
$product = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$product) {
    header("Location: catalog.php");
    exit;
}

// Получение отзывов
$stmt = $connection->prepare("
    SELECT r.*, u.username 
    FROM reviews r 
    JOIN users u ON r.user_id = u.id 
    WHERE r.product_id = ? 
    ORDER BY r.created_at DESC
");
$stmt->execute([$product_id]);
$reviews = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Статистика рейтингов
$rating_stats = [1 => 0, 2 => 0, 3 => 0, 4 => 0, 5 => 0];
foreach ($reviews as $review) {
    $rating_stats[$review['rating']]++;
}

// Добавление отзыва
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_review']) && isset($_SESSION['user_id'])) {
    $rating = $_POST['rating'];
    $comment = trim($_POST['comment']);
    
    $errors = [];
    
    if ($rating < 1 || $rating > 5) {
        $errors[] = "Выберите корректный рейтинг";
    }
    
    if (empty($comment)) {
        $errors[] = "Введите текст отзыва";
    }
    
    // Проверка, оставлял ли пользователь уже отзыв
    $stmt = $connection->prepare("SELECT id FROM reviews WHERE user_id = ? AND product_id = ?");
    $stmt->execute([$_SESSION['user_id'], $product_id]);
    if ($stmt->fetch()) {
        $errors[] = "Вы уже оставляли отзыв на этот товар";
    }
    
    if (empty($errors)) {
        try {
            $connection->beginTransaction();
            
            $stmt = $connection->prepare("INSERT INTO reviews (user_id, product_id, rating, comment) VALUES (?, ?, ?, ?)");
            $stmt->execute([$_SESSION['user_id'], $product_id, $rating, $comment]);
            
            $stmt = $connection->prepare("
                UPDATE products 
                SET average_rating = (
                    SELECT AVG(rating) FROM reviews WHERE product_id = ?
                ),
                review_count = (
                    SELECT COUNT(*) FROM reviews WHERE product_id = ?
                )
                WHERE id = ?
            ");
            $stmt->execute([$product_id, $product_id, $product_id]);
            
            $connection->commit();
            $_SESSION['review_success'] = "Отзыв успешно добавлен!";
            header("Location: product.php?id=$product_id");
            exit;
            
        } catch (Exception $e) {
            $connection->rollBack();
            $errors[] = "Ошибка при добавлении отзыва: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($product['name']) ?> - VoiceStreetFashion</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #000000;
            --secondary-color: #333333;
            --accent-color: #666666;
            --light-color: #ffffff;
            --text-color: #000000;
            --success-color: #333333;
            --border-color: #eaeaea;
            --admin-color: #000000;
            --background-color: #ffffff;
            --section-bg: #fafafa;
            --card-shadow: 0 10px 30px -10px rgba(0,0,0,0.1);
            --hover-shadow: 0 20px 40px -15px rgba(0,0,0,0.2);
            --transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
        }
        
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        
        html {
            font-size: 14px;
            scroll-behavior: smooth;
        }
        
        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            line-height: 1.6;
            overflow-x: hidden;
            background-color: var(--background-color);
            color: var(--text-color);
        }
        
        .container {
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 1rem;
        }
        
        /* Header Styles */
        header {
            background: white;
            box-shadow: 0 2px 20px rgba(0,0,0,0.1);
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            padding: 0.5rem 0;
            width: 100%;
            backdrop-filter: blur(10px);
            background: rgba(255,255,255,0.98);
        }
        
        .header-full-width {
            max-width: 100%;
            margin: 0;
            padding: 0 2rem;
        }
        
        .header-container {
            display: flex;
            align-items: center;
            justify-content: space-between;
            width: 100%;
            gap: 3rem;
        }
        
        .logo {
            display: flex;
            flex-direction: column;
            align-items: flex-start;
            min-width: 200px;
        }
        
        .logo h1 {
            color: var(--primary-color) !important;
            font-size: 1.8rem;
            font-weight: 800;
            margin: 0;
            line-height: 1;
            white-space: nowrap;
            letter-spacing: -0.5px;
        }
        
        .logo span {
            color: var(--secondary-color);
            font-size: 0.8rem;
            margin-top: 2px;
            letter-spacing: 1px;
            text-transform: uppercase;
        }
        
        nav {
            flex: 1;
            display: flex;
            justify-content: center;
            margin: 0 2rem;
        }
        
        nav ul {
            display: flex;
            list-style: none;
            margin: 0;
            padding: 0;
            gap: 2rem;
        }
        
        nav a {
            text-decoration: none;
            color: var(--text-color);
            font-weight: 500;
            font-size: 1rem;
            transition: color 0.3s;
            position: relative;
            white-space: nowrap;
            padding: 0.5rem 0;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        nav a:hover {
            color: var(--primary-color);
        }
        
        nav a::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 0;
            height: 2px;
            background: var(--primary-color);
            transition: width 0.3s ease;
        }
        
        nav a:hover::after,
        nav a.active::after {
            width: 100%;
        }
        
        .header-actions {
            display: flex;
            align-items: center;
            gap: 1rem;
            min-width: 300px;
            justify-content: flex-end;
        }
        
        .search-box {
            display: flex;
            background: var(--light-color);
            border-radius: 30px;
            padding: 0.4rem;
            border: 2px solid transparent;
            transition: border-color 0.3s;
            min-width: 250px;
            margin-right: 1rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        
        .search-box:focus-within {
            border-color: var(--primary-color);
            box-shadow: 0 2px 15px rgba(0,0,0,0.1);
        }
        
        .search-box input {
            border: none;
            background: none;
            outline: none;
            padding: 0 1rem;
            width: 100%;
            font-size: 0.9rem;
        }
        
        .search-box button {
            background: var(--primary-color);
            color: white;
            border: none;
            padding: 0.4rem 1rem;
            border-radius: 25px;
            cursor: pointer;
            font-size: 0.9rem;
            transition: background 0.3s;
            white-space: nowrap;
        }
        
        .search-box button:hover {
            background: var(--secondary-color);
            transform: scale(0.98);
        }
        
        .cart-link {
            display: flex;
            align-items: center;
            text-decoration: none;
            color: var(--text-color);
            transition: color 0.3s;
            padding: 0.5rem;
            position: relative;
            background: none !important;
        }
        
        .cart-link:hover {
            color: var(--primary-color);
            transform: translateY(-2px);
        }
        
        .cart-icon {
            width: 24px;
            height: 24px;
            stroke: currentColor;
            stroke-width: 2;
            fill: none;
        }
        
        .cart-count {
            background: var(--accent-color);
            color: white;
            border-radius: 50%;
            width: 18px;
            height: 18px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.7rem;
            position: absolute;
            top: 2px;
            right: 2px;
            font-weight: bold;
            transition: transform 0.2s ease;
            border: 2px solid white;
        }

        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            font-size: 1.5rem;
            color: var(--text-color);
            cursor: pointer;
        }

        main {
            margin-top: 80px;
            min-height: calc(100vh - 80px);
            padding: 3rem 0;
            background: linear-gradient(135deg, #fff 0%, #fafafa 100%);
        }

        /* Product Detail */
        .product-detail {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 3rem;
            margin: 2rem 0;
            background: white;
            border-radius: 20px;
            padding: 2rem;
            box-shadow: var(--card-shadow);
            border: 1px solid var(--border-color);
        }
        
        .product-gallery {
            position: relative;
        }
        
        .product-gallery img {
            width: 100%;
            height: auto;
            border-radius: 15px;
            transition: var(--transition);
            border: 1px solid var(--border-color);
        }
        
        .product-gallery img:hover {
            transform: scale(1.02);
            box-shadow: var(--hover-shadow);
        }
        
        .product-info {
            padding: 0;
        }
        
        .product-info h1 {
            color: var(--primary-color);
            margin-bottom: 1rem;
            font-size: 2.2rem;
            font-weight: 800;
            line-height: 1.2;
            letter-spacing: -0.5px;
        }
        
        .rating-overview {
            display: flex;
            align-items: center;
            gap: 1rem;
            margin: 1rem 0;
            padding: 1rem 0;
            border-bottom: 1px solid var(--border-color);
            flex-wrap: wrap;
        }
        
        .rating-stars {
            color: #000;
            font-size: 1.3rem;
            letter-spacing: 2px;
        }
        
        .rating-stars .filled {
            color: #000;
        }
        
        .rating-stars .half {
            position: relative;
            display: inline-block;
        }
        
        .product-price {
            font-size: 2.5rem;
            color: var(--primary-color) !important;
            font-weight: 900;
            margin: 1.5rem 0;
            letter-spacing: -1px;
        }
        
        .product-price::after {
            content: ' ₽';
            font-size: 1.5rem;
            font-weight: 500;
            color: var(--accent-color);
        }
        
        .product-meta-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 1rem;
            margin: 1.5rem 0;
            padding: 1.5rem 0;
            border-top: 1px solid var(--border-color);
            border-bottom: 1px solid var(--border-color);
            background: var(--section-bg);
            border-radius: 10px;
            padding: 1.5rem;
        }
        
        .meta-item {
            display: flex;
            flex-direction: column;
            gap: 0.3rem;
            padding: 0.5rem;
        }
        
        .meta-item span {
            color: var(--accent-color);
            font-size: 0.85rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .meta-item strong {
            color: var(--primary-color);
            font-weight: 700;
            font-size: 1.1rem;
        }
        
        .size-selection {
            margin: 2rem 0;
        }
        
        .size-selection h4 {
            color: var(--primary-color);
            margin-bottom: 1rem;
            font-size: 1.1rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .size-options {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(60px, 1fr));
            gap: 0.8rem;
        }
        
        .size-option {
            padding: 0.8rem 0.5rem;
            border: 2px solid var(--border-color);
            border-radius: 8px;
            cursor: pointer;
            transition: var(--transition);
            background: white;
            color: var(--text-color);
            font-weight: 600;
            text-align: center;
            font-size: 1rem;
        }
        
        .size-option:hover {
            border-color: var(--primary-color);
            transform: translateY(-2px);
        }
        
        .size-option.selected {
            background: var(--primary-color);
            color: white;
            border-color: var(--primary-color);
        }
        
        .product-actions {
            margin: 2rem 0;
        }
        
        .btn {
            background: var(--primary-color);
            color: white;
            border: 2px solid var(--primary-color);
            padding: 1.2rem 2rem;
            border-radius: 12px;
            cursor: pointer;
            font-size: 1.1rem;
            transition: var(--transition);
            font-weight: 700;
            text-decoration: none;
            display: block;
            width: 100%;
            text-align: center;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .btn:hover {
            background: white;
            color: var(--primary-color);
            transform: translateY(-3px);
            box-shadow: var(--hover-shadow);
        }
        
        .btn:active {
            transform: translateY(0);
        }
        
        .product-description {
            margin: 2rem 0;
            padding: 1.5rem 0;
            border-top: 1px solid var(--border-color);
        }
        
        .product-description h3 {
            color: var(--primary-color);
            margin-bottom: 1rem;
            font-size: 1.3rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .product-description p {
            line-height: 1.8;
            color: var(--secondary-color);
            font-size: 1rem;
        }
        
        /* Reviews Section */
        .reviews-section {
            margin-top: 3rem;
            padding: 2rem;
            background: white;
            border-radius: 20px;
            border: 1px solid var(--border-color);
            box-shadow: var(--card-shadow);
        }
        
        .reviews-section h2 {
            color: var(--primary-color);
            margin-bottom: 2rem;
            font-size: 2rem;
            text-align: center;
            font-weight: 800;
            letter-spacing: -0.5px;
            position: relative;
        }
        
        .reviews-section h2::after {
            content: '';
            display: block;
            width: 60px;
            height: 3px;
            background: var(--primary-color);
            margin: 1rem auto 0;
        }
        
        .reviews-grid {
            display: grid;
            grid-template-columns: 300px 1fr;
            gap: 2rem;
            align-items: start;
            margin: 1.5rem 0;
        }
        
        .reviews-left {
            position: sticky;
            top: 100px;
            align-self: start;
            height: fit-content;
        }
        
        .reviews-right {
            display: flex;
            flex-direction: column;
            gap: 2rem;
        }
        
        /* Rating Breakdown */
        .rating-breakdown {
            background: var(--section-bg);
            padding: 2rem;
            border-radius: 15px;
            border: 1px solid var(--border-color);
            box-shadow: var(--card-shadow);
        }
        
        .rating-breakdown h4 {
            color: var(--primary-color);
            margin-bottom: 1.5rem;
            font-size: 1.2rem;
            text-align: center;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .rating-bar {
            display: flex;
            align-items: center;
            gap: 0.8rem;
            margin: 0.8rem 0;
        }
        
        .rating-bar span:first-child {
            min-width: 35px;
            font-weight: 600;
            color: var(--primary-color);
        }
        
        .rating-bar span:last-child {
            min-width: 30px;
            text-align: right;
            color: var(--accent-color);
            font-weight: 500;
        }
        
        .bar-container {
            flex: 1;
            border-radius: 20px;
            overflow: hidden;
            background: var(--border-color);
            height: 8px;
        }
        
        .bar-fill {
            height: 100%;
            background: linear-gradient(90deg, var(--primary-color), var(--secondary-color));
            transition: width 1s ease-in-out;
            border-radius: 20px;
        }
        
        /* Review Form */
        .add-review-form {
            background: white;
            padding: 2rem;
            border-radius: 15px;
            border: 1px solid var(--border-color);
            box-shadow: var(--card-shadow);
        }
        
        .add-review-form h4 {
            color: var(--primary-color);
            margin-bottom: 1.5rem;
            font-size: 1.3rem;
            font-weight: 700;
        }
        
        .form-group {
            margin-bottom: 1.5rem;
        }
        
        .form-group label {
            display: block;
            color: var(--primary-color);
            margin-bottom: 0.5rem;
            font-weight: 600;
            font-size: 1rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .star-rating {
            display: flex;
            gap: 0.8rem;
            margin: 0.5rem 0;
            justify-content: center;
        }
        
        .star {
            font-size: 2.2rem;
            cursor: pointer;
            color: var(--border-color);
            transition: var(--transition);
        }
        
        .star:hover,
        .star.active {
            color: #000;
            transform: scale(1.1);
        }
        
        textarea {
            width: 100%;
            padding: 1rem;
            border: 2px solid var(--border-color);
            border-radius: 10px;
            background: white;
            color: var(--text-color);
            font-family: inherit;
            resize: vertical;
            min-height: 120px;
            transition: var(--transition);
            font-size: 1rem;
            line-height: 1.6;
        }
        
        textarea:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 4px rgba(0,0,0,0.05);
        }
        
        /* Login Prompt */
        .login-prompt {
            text-align: center;
            padding: 3rem 2rem;
            background: var(--section-bg);
            border-radius: 15px;
            border: 1px solid var(--border-color);
            box-shadow: var(--card-shadow);
        }
        
        .login-prompt i {
            font-size: 3rem;
            color: var(--accent-color);
            margin-bottom: 1.5rem;
        }
        
        .login-prompt p {
            color: var(--secondary-color);
            margin-bottom: 2rem;
            font-size: 1.1rem;
        }
        
        /* Reviews List */
        .reviews-list {
            margin-top: 0;
        }
        
        .reviews-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid var(--border-color);
            flex-wrap: wrap;
            gap: 1rem;
        }
        
        .reviews-header h4 {
            color: var(--primary-color);
            margin: 0;
            font-size: 1.3rem;
            font-weight: 700;
        }
        
        .reviews-stats {
            display: flex;
            align-items: center;
            gap: 1rem;
            color: var(--accent-color);
            font-size: 0.95rem;
            font-weight: 500;
            background: var(--section-bg);
            padding: 0.5rem 1rem;
            border-radius: 30px;
        }
        
        .review-item {
            background: white;
            padding: 2rem;
            margin-bottom: 1.5rem;
            border-radius: 15px;
            border: 1px solid var(--border-color);
            transition: var(--transition);
            box-shadow: 0 2px 8px rgba(0,0,0,0.02);
        }
        
        .review-item:hover {
            transform: translateY(-3px);
            box-shadow: var(--hover-shadow);
            border-color: var(--primary-color);
        }
        
        .review-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 1.5rem;
            flex-wrap: wrap;
            gap: 1rem;
        }
        
        .review-user {
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        
        .user-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 700;
            font-size: 1.2rem;
            text-transform: uppercase;
        }
        
        .user-info {
            display: flex;
            flex-direction: column;
        }
        
        .user-info strong {
            color: var(--primary-color);
            font-size: 1.1rem;
            margin-bottom: 0.3rem;
            font-weight: 700;
        }
        
        .review-rating {
            color: #000;
            font-size: 1rem;
            letter-spacing: 2px;
        }
        
        .review-date {
            color: var(--accent-color);
            font-size: 0.9rem;
            font-weight: 500;
        }
        
        .review-content {
            line-height: 1.8;
            color: var(--secondary-color);
            margin: 1.5rem 0;
            padding-left: 1rem;
            border-left: 3px solid var(--primary-color);
            font-size: 1rem;
        }
        
        .review-actions {
            display: flex;
            gap: 1rem;
            margin-top: 1.5rem;
            padding-top: 1.5rem;
            border-top: 1px solid var(--border-color);
        }
        
        .review-action-btn {
            background: none;
            border: 1px solid var(--border-color);
            color: var(--accent-color);
            cursor: pointer;
            font-size: 0.9rem;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.5rem 1rem;
            border-radius: 30px;
            font-weight: 500;
        }
        
        .review-action-btn:hover {
            background: var(--primary-color);
            color: white;
            border-color: var(--primary-color);
            transform: translateY(-2px);
        }
        
        .no-reviews {
            text-align: center;
            padding: 3rem 2rem;
            color: var(--secondary-color);
            background: var(--section-bg);
            border-radius: 15px;
            border: 1px solid var(--border-color);
        }
        
        .no-reviews i {
            font-size: 3rem;
            color: var(--border-color);
            margin-bottom: 1.5rem;
        }
        
        .no-reviews h4 {
            color: var(--primary-color);
            margin-bottom: 0.8rem;
            font-size: 1.2rem;
            font-weight: 700;
        }
        
        .no-reviews p {
            color: var(--accent-color);
            margin-bottom: 0;
            font-size: 1rem;
        }
        
        /* Messages */
        .success-message {
            background: #e8f5e9;
            color: #2e7d32;
            padding: 1rem 1.5rem;
            border-radius: 10px;
            border-left: 4px solid #2e7d32;
            margin: 1rem 0;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            animation: slideDown 0.3s ease;
        }
        
        .error-message {
            background: #ffebee;
            color: #c62828;
            padding: 1rem 1.5rem;
            border-radius: 10px;
            border-left: 4px solid #c62828;
            margin: 1rem 0;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            animation: slideDown 0.3s ease;
        }
        
        /* Notification Container */
        .notification-container {
            position: fixed;
            top: 100px;
            right: 20px;
            z-index: 9999;
        }
        
        .notification {
            background: white;
            color: var(--text-color);
            padding: 1rem 1.5rem;
            margin-bottom: 10px;
            border-radius: 10px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.15);
            animation: slideIn 0.3s ease;
            border-left: 4px solid var(--success-color);
            font-weight: 500;
            min-width: 300px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .notification.error {
            border-left-color: #c62828;
        }
        
        .notification.success {
            border-left-color: #2e7d32;
        }
        
        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        @keyframes slideIn {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
        
        @keyframes slideOut {
            from {
                transform: translateX(0);
                opacity: 1;
            }
            to {
                transform: translateX(100%);
                opacity: 0;
            }
        }
        
        /* Footer */
        footer {
            background: var(--primary-color);
            color: white;
            padding: 4rem 0 2rem;
            margin-top: 4rem;
        }
        
        .footer-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 3rem;
            margin-bottom: 3rem;
        }
        
        .footer-column h3,
        .footer-column h4 {
            color: white;
            margin-bottom: 1.5rem;
            font-size: 1.2rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .footer-links {
            display: flex;
            flex-direction: column;
            gap: 0.8rem;
        }
        
        .footer-links a {
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            transition: opacity 0.3s;
            font-size: 0.95rem;
        }
        
        .footer-links a:hover {
            opacity: 1;
        }
        
        .footer-bottom {
            text-align: center;
            padding-top: 2rem;
            border-top: 1px solid rgba(255,255,255,0.1);
        }
        
        .footer-bottom p {
            margin: 0;
            opacity: 0.8;
            font-size: 0.9rem;
            line-height: 1.6;
        }
        
        /* Responsive */
        @media (max-width: 1200px) {
            .header-full-width {
                padding: 0 1.5rem;
            }
            
            .header-container {
                gap: 2rem;
            }
            
            nav ul {
                gap: 1.5rem;
            }
            
            .header-actions {
                min-width: 250px;
            }
            
            .search-box {
                min-width: 200px;
            }
        }
        
        @media (max-width: 992px) {
            .product-detail {
                grid-template-columns: 1fr;
                gap: 2rem;
            }
            
            .reviews-grid {
                grid-template-columns: 1fr;
                gap: 1.5rem;
            }
            
            .reviews-left {
                position: static;
            }
            
            .header-container {
                gap: 1.5rem;
            }
            
            nav {
                margin: 0 1rem;
            }
            
            nav ul {
                gap: 1rem;
            }
            
            .header-actions {
                min-width: 200px;
            }
            
            .search-box {
                min-width: 180px;
                margin-right: 0.5rem;
            }
        }
        
        @media (max-width: 768px) {
            .header-container {
                flex-wrap: wrap;
                gap: 1rem;
            }
            
            .mobile-menu-btn {
                display: block;
            }
            
            nav {
                order: 3;
                display: none;
                width: 100%;
                margin: 0;
            }
            
            nav.active {
                display: block;
            }
            
            nav ul {
                flex-direction: column;
                gap: 0.5rem;
                padding: 1rem 0;
            }
            
            .header-actions {
                min-width: auto;
                gap: 0.5rem;
            }
            
            .search-box {
                min-width: 150px;
            }
            
            .logo {
                min-width: auto;
            }
            
            .logo h1 {
                font-size: 1.5rem;
            }
            
            .cart-link {
                padding: 0.3rem;
            }
            
            .product-info h1 {
                font-size: 1.8rem;
            }
            
            .product-price {
                font-size: 2rem;
            }
            
            .product-meta-grid {
                grid-template-columns: 1fr;
            }
            
            .size-options {
                grid-template-columns: repeat(4, 1fr);
            }
            
            .reviews-header {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .review-header {
                flex-direction: column;
            }
            
            .footer-grid {
                grid-template-columns: 1fr;
                gap: 2rem;
            }
        }
        
        @media (max-width: 480px) {
            .header-full-width {
                padding: 0 1rem;
            }
            
            .search-box {
                min-width: 120px;
            }
            
            .cart-link {
                padding: 0.2rem;
            }
            
            .product-detail {
                padding: 1rem;
            }
            
            .product-info h1 {
                font-size: 1.5rem;
            }
            
            .product-price {
                font-size: 1.8rem;
            }
            
            .size-options {
                grid-template-columns: repeat(3, 1fr);
            }
            
            .reviews-section {
                padding: 1.5rem;
            }
            
            .review-actions {
                flex-direction: column;
                gap: 0.5rem;
            }
            
            .review-action-btn {
                justify-content: center;
            }
            
            .star-rating {
                gap: 0.3rem;
            }
            
            .star {
                font-size: 1.8rem;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="header-full-width">
            <div class="header-container">
                <button class="mobile-menu-btn">
                    <i class="fas fa-bars"></i>
                </button>
                
                <div class="logo">
                    <h1>VoiceStreetFashion</h1>
                </div>
                
                <nav id="main-nav">
                    <ul>
                        <li><a href="index.php">Главная</a></li>
                        <li><a href="catalog.php">Обувь</a></li>
                        <li><a href="feedback.php">Обратная связь</a></li>
                        <?php if(isset($_SESSION['user_id'])): ?>
                            <?php if($is_admin): ?>
                                <li><a href="admin.php" class="admin-link">Админ панель</a></li>
                            <?php endif; ?>
                            <li><a href="profile.php">Личный кабинет</a></li>
                            <li><a href="logout.php">Выйти</a></li>
                        <?php else: ?>
                            <li><a href="login.php">Войти</a></li>
                            <li><a href="register.php">Регистрация</a></li>
                        <?php endif; ?>
                    </ul>
                </nav>
                
                <div class="header-actions">
                    <div class="search-box">
                        <input type="text" id="searchInput" placeholder="Поиск товаров...">
                        <button onclick="searchProducts()">
                            <i class="fas fa-search"></i>
                        </button>
                    </div>
                    
                    <a href="cart.php" class="cart-link" id="cart-link">
                        <svg class="cart-icon" viewBox="0 0 24 24">
                            <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path>
                            <line x1="3" y1="6" x2="21" y2="6"></line>
                            <path d="M16 10a4 4 0 0 1-8 0"></path>
                        </svg>
                        <span class="cart-count" id="cart-count">
                            <?php 
                            if (isset($_SESSION['user_id'])) {
                                // Для авторизованных - считаем из БД
                                $stmt = $connection->prepare("SELECT SUM(quantity) as total FROM cart WHERE user_id = ?");
                                $stmt->execute([$_SESSION['user_id']]);
                                $result = $stmt->fetch(PDO::FETCH_ASSOC);
                                echo $result['total'] ?? 0;
                            } else {
                                // Для неавторизованных - считаем из сессии
                                echo $cart_count;
                            }
                            ?>
                        </span>
                    </a>
                </div>
            </div>
        </div>
    </header>
    
    <main>
        <div class="container">
            <!-- Сообщения -->
            <?php if (isset($_SESSION['cart_success'])): ?>
                <div class="success-message">
                    <i class="fas fa-check-circle"></i>
                    <p><?= $_SESSION['cart_success'] ?></p>
                </div>
                <?php unset($_SESSION['cart_success']); ?>
            <?php endif; ?>
            
            <?php if (isset($_SESSION['cart_error'])): ?>
                <div class="error-message">
                    <i class="fas fa-exclamation-circle"></i>
                    <p><?= $_SESSION['cart_error'] ?></p>
                </div>
                <?php unset($_SESSION['cart_error']); ?>
            <?php endif; ?>
            
            <!-- Детали товара -->
            <div class="product-detail">
                <div class="product-gallery">
                    <img src="<?= $product['image_url'] ?>" alt="<?= htmlspecialchars($product['name']) ?>">
                </div>
                
                <div class="product-info">
                    <h1><?= htmlspecialchars($product['name']) ?></h1>
                    
                    <div class="rating-overview">
                        <div class="rating-stars">
                            <?php
                            $avg_rating = $product['average_rating'];
                            $full_stars = floor($avg_rating);
                            $half_star = $avg_rating - $full_stars >= 0.5;
                            
                            for ($i = 1; $i <= 5; $i++) {
                                if ($i <= $full_stars) {
                                    echo '<span class="filled">★</span>';
                                } elseif ($i == $full_stars + 1 && $half_star) {
                                    echo '<span class="half">½</span>';
                                } else {
                                    echo '<span>☆</span>';
                                }
                            }
                            ?>
                        </div>
                        <span><?= number_format($avg_rating, 1) ?> (<?= $product['review_count'] ?> отзывов)</span>
                    </div>
                    
                    <div class="product-price">
                        <?= number_format($product['price'], 0, ',', ' ') ?>
                    </div>
                    
                    <div class="product-meta-grid">
                        <div class="meta-item">
                            <span>Бренд</span>
                            <strong><?= htmlspecialchars($product['brand']) ?></strong>
                        </div>
                        <div class="meta-item">
                            <span>Цвет</span>
                            <strong><?= htmlspecialchars($product['color'] ?? 'Не указан') ?></strong>
                        </div>
                        <div class="meta-item">
                            <span>Материал</span>
                            <strong><?= htmlspecialchars($product['material'] ?? 'Не указан') ?></strong>
                        </div>
                        <div class="meta-item">
                            <span>Пол</span>
                            <strong>
                                <?= $product['gender'] == 'male' ? 'Мужской' : 
                                    ($product['gender'] == 'female' ? 'Женский' : 'Унисекс') ?>
                            </strong>
                        </div>
                        <div class="meta-item">
                            <span>Сезон</span>
                            <strong><?= htmlspecialchars($product['season'] ?? 'Круглогодичный') ?></strong>
                        </div>
                        <div class="meta-item">
                            <span>В наличии</span>
                            <strong><?= $product['in_stock_quantity'] > 0 ? $product['in_stock_quantity'] . ' шт.' : 'Нет в наличии' ?></strong>
                        </div>
                    </div>
                    
                    <div class="size-selection">
                        <h4>Выберите размер</h4>
                        <div class="size-options" id="sizeOptions">
                            <?php
                            $sizes = explode(',', $product['size_range'] ?? '38,39,40,41,42,43,44,45');
                            foreach ($sizes as $size) {
                                $size = trim($size);
                                echo "<div class='size-option' onclick='selectSize(\"$size\", this)'>$size</div>";
                            }
                            ?>
                            <input type="hidden" name="selected_size" id="selectedSize">
                        </div>
                    </div>
                    
                    <div class="product-actions">
                        <?php if (isset($_SESSION['user_id'])): ?>
                            <!-- Для авторизованных пользователей -->
                            <form method="POST" action="add_to_cart_simple.php" id="addToCartForm">
                                <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
                                <input type="hidden" name="size" id="selectedSizeForm" value="">
                                <button type="submit" class="btn" id="addToCartBtn">
                                    Добавить в корзину
                                </button>
                            </form>
                        <?php else: ?>
                            <!-- Для неавторизованных пользователей -->
                            <form method="POST" action="add_to_cart_handler.php" id="addToCartForm">
                                <?php 
                                // Генерируем CSRF токен
                                if (!isset($_SESSION['csrf_token'])) {
                                    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
                                }
                                ?>
                                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                                <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
                                <input type="hidden" name="size" id="selectedSizeForm" value="">
                                <button type="submit" class="btn" id="addToCartBtn">
                                    Добавить в корзину
                                </button>
                            </form>
                        <?php endif; ?>
                    </div>
                    
                    <div class="product-description">
                        <h3>Описание товара</h3>
                        <p><?= nl2br(htmlspecialchars($product['description'] ?? 'Описание товара скоро будет добавлено.')) ?></p>
                    </div>
                </div>
            </div>
            
            <!-- Секция отзывов -->
            <div class="reviews-section">
                <h2>Отзывы и оценки</h2>
                
                <div class="reviews-grid">
                    <!-- Левая колонка - sticky блок -->
                    <div class="reviews-left">
                        <div class="rating-breakdown">
                            <h4>Распределение оценок</h4>
                            <?php for ($i = 5; $i >= 1; $i--): 
                                $percentage = $product['review_count'] > 0 ? 
                                    ($rating_stats[$i] / $product['review_count']) * 100 : 0;
                            ?>
                                <div class="rating-bar">
                                    <span><?= $i ?> ★</span>
                                    <div class="bar-container">
                                        <div class="bar-fill" style="width: <?= $percentage ?>%"></div>
                                    </div>
                                    <span><?= $rating_stats[$i] ?></span>
                                </div>
                            <?php endfor; ?>
                        </div>
                    </div>
                    
                    <!-- Правая колонка - контент -->
                    <div class="reviews-right">
                        <?php if (isset($_SESSION['user_id'])): ?>
                            <div class="add-review-form">
                                <h4>Оставить отзыв</h4>
                                
                                <?php if (isset($_SESSION['review_success'])): ?>
                                    <div class="success-message">
                                        <i class="fas fa-check-circle"></i>
                                        <p><?= $_SESSION['review_success'] ?></p>
                                    </div>
                                    <?php unset($_SESSION['review_success']); ?>
                                <?php endif; ?>
                                
                                <?php if (!empty($errors)): ?>
                                    <div class="error-message">
                                        <i class="fas fa-exclamation-circle"></i>
                                        <div>
                                            <?php foreach ($errors as $error): ?>
                                                <p><?= $error ?></p>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                <?php endif; ?>
                                
                                <form method="POST" action="" id="reviewForm">
                                    <div class="form-group">
                                        <label>Ваша оценка</label>
                                        <div class="star-rating">
                                            <?php for ($i = 1; $i <= 5; $i++): ?>
                                                <span class="star" data-rating="<?= $i ?>" 
                                                      onclick="setRating(<?= $i ?>)">☆</span>
                                            <?php endfor; ?>
                                            <input type="hidden" name="rating" id="ratingInput" required>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="comment">Ваш отзыв</label>
                                        <textarea id="comment" name="comment" placeholder="Поделитесь вашим мнением о товаре..." required></textarea>
                                    </div>
                                    
                                    <button type="submit" name="add_review" class="btn">Оставить отзыв</button>
                                </form>
                            </div>
                        <?php else: ?>
                            <div class="login-prompt">
                                <i class="fas fa-user-circle"></i>
                                <p>Войдите, чтобы оставить отзыв</p>
                                <a href="login.php" class="btn">Войти в аккаунт</a>
                            </div>
                        <?php endif; ?>
                        
                        <div class="reviews-list">
                            <div class="reviews-header">
                                <h4>Отзывы покупателей</h4>
                                <div class="reviews-stats">
                                    <span><i class="far fa-comment"></i> <?= count($reviews) ?> отзывов</span>
                                    <span>•</span>
                                    <span><i class="fas fa-star"></i> <?= number_format($avg_rating, 1) ?></span>
                                </div>
                            </div>
                            
                            <?php if (empty($reviews)): ?>
                                <div class="no-reviews">
                                    <i class="far fa-comment-dots"></i>
                                    <h4>Пока нет отзывов</h4>
                                    <p>Будьте первым, кто поделится впечатлениями об этом товаре!</p>
                                </div>
                            <?php else: ?>
                                <?php foreach ($reviews as $review): ?>
                                    <div class="review-item">
                                        <div class="review-header">
                                            <div class="review-user">
                                                <div class="user-avatar">
                                                    <?= strtoupper(mb_substr($review['username'], 0, 1)) ?>
                                                </div>
                                                <div class="user-info">
                                                    <strong><?= htmlspecialchars($review['username']) ?></strong>
                                                    <div class="review-rating">
                                                        <?= str_repeat('★', $review['rating']) . str_repeat('☆', 5 - $review['rating']) ?>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="review-date">
                                                <i class="far fa-calendar-alt"></i>
                                                <?= date('d.m.Y в H:i', strtotime($review['created_at'])) ?>
                                            </div>
                                        </div>
                                        <p class="review-content"><?= nl2br(htmlspecialchars($review['comment'])) ?></p>
                                        
                                        <div class="review-actions">
                                            <button class="review-action-btn" onclick="likeReview(<?= $review['id'] ?>)">
                                                <i class="far fa-thumbs-up"></i> Полезно
                                            </button>
                                            <button class="review-action-btn" onclick="reportReview(<?= $review['id'] ?>)">
                                                <i class="far fa-flag"></i> Пожаловаться
                                            </button>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
    
    <footer>
        <div class="container">
            <div class="footer-grid">
                <div>
                    <h3>VoiceStreetFashion</h3>
                    <p style="line-height: 1.8; opacity: 0.9;">Ваш голос в мире уличной моды. Премиальная обувь от ведущих мировых брендов с доставкой по всей России.</p>
                    <div style="display: flex; gap: 1.5rem; margin-top: 1.5rem;">
                        <a href="#" style="color: white; opacity: 0.8; transition: opacity 0.3s; font-size: 1.2rem;">
                            <i class="fab fa-instagram"></i>
                        </a>
                        <a href="#" style="color: white; opacity: 0.8; transition: opacity 0.3s; font-size: 1.2rem;">
                            <i class="fab fa-telegram-plane"></i>
                        </a>
                        <a href="#" style="color: white; opacity: 0.8; transition: opacity 0.3s; font-size: 1.2rem;">
                            <i class="fab fa-vk"></i>
                        </a>
                    </div>
                </div>
                
                <div>
                    <h4>Контактная информация</h4>
                    <div class="footer-links">
                        <div>
                            <i class="fas fa-phone"></i>
                            <span>+7 (999) 123-45-67</span>
                        </div>
                        <div>
                            <i class="fas fa-envelope"></i>
                            <span>info@voicestreet.ru</span>
                        </div>
                        <div>
                            <i class="fas fa-map-marker-alt"></i>
                            <span>Москва, ул. Примерная, 123</span>
                        </div>
                    </div>
                </div>
                
                <div>
                    <h4>Полезные ссылки</h4>
                    <div class="footer-links">
                        <a href="catalog.php">Каталог обуви</a>
                        <a href="feedback.php">Обратная связь</a>
                        <a href="login.php">Личный кабинет</a>
                    </div>
                </div>
                
                <div>
                    <h4>Часы работы</h4>
                    <div style="opacity: 0.9;">
                        <div>Пн-Пт: 9:00 - 21:00</div>
                        <div>Сб-Вс: 10:00 - 20:00</div>
                        <div style="margin-top: 1rem; font-size: 0.9rem;">Доставка работает ежедневно</div>
                    </div>
                </div>
            </div>
            
            <div class="footer-bottom">
                <p>
                    &copy; 2026 VoiceStreetFashion. Все права защищены.
                </p>
            </div>
        </div>
    </footer>
    
    <!-- Notification Container -->
    <div class="notification-container" id="notificationContainer"></div>
    
    <script>
        // Mobile menu toggle
        document.querySelector('.mobile-menu-btn').addEventListener('click', function() {
            document.getElementById('main-nav').classList.toggle('active');
        });

        document.addEventListener('click', function(event) {
            const nav = document.getElementById('main-nav');
            const menuBtn = document.querySelector('.mobile-menu-btn');
            if (!nav.contains(event.target) && !menuBtn.contains(event.target)) {
                nav.classList.remove('active');
            }
        });

        function searchProducts() {
            const searchTerm = document.getElementById('searchInput').value;
            if (searchTerm.trim()) {
                window.location.href = `catalog.php?search=${encodeURIComponent(searchTerm)}`;
            }
        }

        document.getElementById('searchInput').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                searchProducts();
            }
        });

        // Переменная для хранения выбранного размера
        let selectedSizeValue = '';

        // Функция выбора размера
        function selectSize(size, element) {
            const options = document.querySelectorAll('.size-option');
            options.forEach(opt => opt.classList.remove('selected'));
            element.classList.add('selected');
            selectedSizeValue = size;
            document.getElementById('selectedSize').value = size;
            document.getElementById('selectedSizeForm').value = size;
        }

        // Функция для установки рейтинга в отзыве
        function setRating(rating) {
            document.getElementById('ratingInput').value = rating;
            const stars = document.querySelectorAll('.star');
            stars.forEach((star, index) => {
                if (index < rating) {
                    star.textContent = '★';
                    star.classList.add('active');
                } else {
                    star.textContent = '☆';
                    star.classList.remove('active');
                }
            });
        }

        // Функции для отзывов
        function likeReview(reviewId) {
            showNotification('Спасибо за отзыв!', 'success');
        }

        function reportReview(reviewId) {
            showNotification('Жалоба отправлена администратору', 'success');
        }

        // Функция для показа уведомлений
        function showNotification(message, type) {
            const container = document.getElementById('notificationContainer');
            const notification = document.createElement('div');
            notification.className = `notification ${type}`;
            notification.innerHTML = `
                <i class="fas ${type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'}"></i>
                <span>${message}</span>
            `;
            
            container.appendChild(notification);
            
            setTimeout(() => {
                notification.style.animation = 'slideOut 0.3s ease';
                setTimeout(() => {
                    notification.remove();
                }, 300);
            }, 3000);
        }

        // Функция для обновления счетчика корзины
        function updateCartCount() {
            fetch('get_cart_count.php')
                .then(response => response.json())
                .then(data => {
                    const cartCountElement = document.getElementById('cart-count');
                    if (cartCountElement) {
                        cartCountElement.textContent = data.count;
                        
                        cartCountElement.style.transform = 'scale(1.2)';
                        setTimeout(() => {
                            cartCountElement.style.transform = 'scale(1)';
                        }, 200);
                    }
                })
                .catch(error => console.error('Error:', error));
        }

        // Обработка формы добавления в корзину
        document.addEventListener('DOMContentLoaded', function() {
            const addToCartForm = document.getElementById('addToCartForm');
            if (addToCartForm) {
                addToCartForm.addEventListener('submit', function(e) {
                    // Проверяем, выбран ли размер
                    if (!selectedSizeValue) {
                        e.preventDefault();
                        showNotification('Выберите размер!', 'error');
                        return false;
                    }
                    
                    // Обновляем скрытое поле с размером
                    document.getElementById('selectedSizeForm').value = selectedSizeValue;
                    
                    <?php if (isset($_SESSION['user_id'])): ?>
                    // Для авторизованных пользователей используем AJAX
                    e.preventDefault();
                    
                    const formData = new FormData(this);
                    
                    fetch('add_to_cart_simple.php', {
                        method: 'POST',
                        body: formData
                    })
                    .then(response => {
                        if (response.redirected) {
                            window.location.href = response.url;
                            return;
                        }
                        // Проверяем тип ответа
                        const contentType = response.headers.get('content-type');
                        if (contentType && contentType.includes('application/json')) {
                            return response.json();
                        }
                        // Если не JSON, значит это редирект или ошибка
                        showNotification('Товар добавлен в корзину!', 'success');
                        updateCartCount();
                        
                        const cartIcon = document.querySelector('.cart-link');
                        cartIcon.style.transform = 'scale(1.2)';
                        setTimeout(() => {
                            cartIcon.style.transform = 'scale(1)';
                        }, 200);
                    })
                    .then(data => {
                        if (data && data.success === false) {
                            showNotification(data.error || 'Ошибка при добавлении в корзину', 'error');
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        // Даже при ошибке, товар мог добавиться (редирект)
                        showNotification('Товар добавлен в корзину!', 'success');
                        updateCartCount();
                    });
                    <?php endif; ?>
                });
            }
            
            // Автоматически выбираем первый размер при загрузке
            const firstSize = document.querySelector('.size-option');
            if (firstSize && !selectedSizeValue) {
                firstSize.classList.add('selected');
                selectedSizeValue = firstSize.textContent.trim();
                document.getElementById('selectedSize').value = selectedSizeValue;
                document.getElementById('selectedSizeForm').value = selectedSizeValue;
            }
            
            // Анимация заполнения рейтинг-баров
            const bars = document.querySelectorAll('.bar-fill');
            bars.forEach(bar => {
                const width = bar.style.width;
                bar.style.width = '0';
                setTimeout(() => {
                    bar.style.width = width;
                }, 300);
            });
        });
    </script>
</body>
</html>