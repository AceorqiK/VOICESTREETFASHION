<?php
session_start();
require_once '../includes/database.php';
require_once '../includes/config.php';

// Проверка админа
if (!isset($_SESSION['user_id']) || $_SESSION['user_id'] != 1) {
    die('Доступ запрещен');
}

$db = new Database();
$connection = $db->getConnection();
if ($i <= 80) {
    $category_id = 1; // Кроссовки
    $name = "$brand Street Style " . ($i % 20 + 1);
} elseif ($i <= 120) {
    $category_id = 2; // Ботинки
    $name = "$brand Urban Boots " . (($i - 80) % 10 + 1);
} elseif ($i <= 150) {
    $category_id = 3; // Спортивная обувь
    $name = "$brand Street Running " . (($i - 120) % 10 + 1);
} elseif ($i <= 170) {
    $category_id = 4; // Тапочки
    $name = "$brand Home Collection " . (($i - 150) % 5 + 1);
} else {
    $category_id = 5; // Кеды
    $name = "$brand Classic Street " . (($i - 170) % 10 + 1);
}
// Массив брендов
$brands = ['Nike', 'Adidas', 'Jordan', 'New Balance', 'Puma', 'Reebok', 'Converse', 'Vans', 'Balenciaga', 'Gucci'];

// Массив цветов
$colors = ['Черный', 'Белый', 'Красный', 'Синий', 'Зеленый', 'Желтый', 'Розовый', 'Фиолетовый', 'Оранжевый', 'Серый'];

// Массив материалов
$materials = ['Кожа', 'Замша', 'Текстиль', 'Резина', 'Искусственная кожа', 'Хлопок', 'Полиэстер'];

// Массив сезонов
$seasons = ['Лето', 'Зима', 'Весна-Осень', 'Круглогодичный'];

// Описания товаров
$descriptions = [
    "Стильные и удобные кроссовки для повседневной носки. Идеальное сочетание комфорта и стиля.",
    "Премиальная обувь с инновационными технологиями. Обеспечивает максимальный комфорт при ходьбе.",
    "Современный дизайн и качественные материалы. Подходят для спорта и повседневной носки.",
    "Эксклюзивная модель с уникальным дизайном. Высокое качество сборки и материалов.",
    "Ультралегкие и дышащие. Идеальны для активного образа жизни и занятий спортом.",
    "Классический дизайн в современном исполнении. Универсальная модель для любого гардероба.",
    "Технологичные кроссовки с амортизацией. Подходят для бега и тренировок.",
    "Стильная обувь для города. Сочетание моды и функциональности.",
    "Лимитированная коллекция. Эксклюзивный дизайн и премиальные материалы.",
    "Инновационная модель с улучшенной поддержкой стопы. Идеальны для долгих прогулок."
];

// Генерация 200 товаров
for ($i = 1; $i <= 200; $i++) {
    $brand = $brands[array_rand($brands)];
    $color = $colors[array_rand($colors)];
    $material = $materials[array_rand($materials)];
    $season = $seasons[array_rand($seasons)];
    $description = $descriptions[array_rand($descriptions)];
    
    // Определяем категорию на основе номера товара
    if ($i <= 80) {
        $category_id = 1; // Кроссовки
        $name = "$brand Classic Sneaker " . ($i % 20 + 1);
    } elseif ($i <= 120) {
        $category_id = 2; // Ботинки
        $name = "$brand Winter Boots " . (($i - 80) % 10 + 1);
    } elseif ($i <= 150) {
        $category_id = 3; // Спортивная обувь
        $name = "$brand Running Shoes " . (($i - 120) % 10 + 1);
    } elseif ($i <= 170) {
        $category_id = 4; // Тапочки
        $name = "$brand Home Slippers " . (($i - 150) % 5 + 1);
    } else {
        $category_id = 5; // Кеды
        $name = "$brand Classic Keds " . (($i - 170) % 10 + 1);
    }
    
    $price = rand(3000, 25000);
    $in_stock_quantity = rand(0, 50);
    $average_rating = rand(30, 50) / 10; // Рейтинг от 3.0 до 5.0
    $review_count = rand(0, 100);
    
    // Генерация URL изображения (используем placeholder)
    $image_url = "https://via.placeholder.com/400x300/2c3e50/ffffff?text=" . urlencode($name);
    
    // Размеры в зависимости от категории
    if ($category_id == 1 || $category_id == 3 || $category_id == 5) {
        $size_range = '38,39,40,41,42,43,44,45';
        $gender = ['male', 'unisex'][rand(0,1)];
    } elseif ($category_id == 2) {
        $size_range = '39,40,41,42,43,44';
        $gender = ['male', 'unisex'][rand(0,1)];
    } else {
        $size_range = '36,37,38,39,40';
        $gender = ['male', 'female', 'unisex'][rand(0,2)];
    }
    
    $stmt = $connection->prepare("
        INSERT INTO products (name, description, price, category_id, brand, color, material, gender, season, 
                            in_stock_quantity, average_rating, review_count, image_url, size_range) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");
    
    $stmt->execute([
        $name, $description, $price, $category_id, $brand, $color, $material, $gender, 
        $season, $in_stock_quantity, $average_rating, $review_count, $image_url, $size_range
    ]);
    
    echo "Создан товар: $name<br>";
}

echo "<h2>Генерация завершена! Создано 200 товаров.</h2>";
?>
