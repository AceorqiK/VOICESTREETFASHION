<?php
require_once 'config.php';

class Database {
    private $connection;
    
    public function __construct() {
        try {
            // ЗАЩИТА: Добавляем charset=utf8 для предотвращения атак через кодировку
            $this->connection = new PDO(
                "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
                DB_USER,
                DB_PASS,
                [
                    // ЗАЩИТА: Важные настройки безопасности PDO
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false, // Важно для безопасности
                    PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci"
                ]
            );
        } catch(PDOException $e) {
            // ЗАЩИТА: Не раскрываем детали ошибки в продакшене
            error_log("Database connection error: " . $e->getMessage());
            die("Database connection error. Please try again later.");
        }
    }
    
    public function getConnection() {
        return $this->connection;
    }
    
    // ЗАЩИТА: Дополнительные безопасные методы для работы с базой
    
    /**
     * Безопасное выполнение SELECT запроса
     */
    public function select($sql, $params = []) {
        try {
            $stmt = $this->connection->prepare($sql);
            $stmt->execute($params);
            return $stmt->fetchAll();
        } catch (PDOException $e) {
            error_log("Select query error: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Безопасное выполнение INSERT/UPDATE/DELETE запроса
     */
    public function execute($sql, $params = []) {
        try {
            $stmt = $this->connection->prepare($sql);
            return $stmt->execute($params);
        } catch (PDOException $e) {
            error_log("Execute query error: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Безопасное получение одной записи
     */
    public function selectOne($sql, $params = []) {
        try {
            $stmt = $this->connection->prepare($sql);
            $stmt->execute($params);
            return $stmt->fetch();
        } catch (PDOException $e) {
            error_log("Select one query error: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Безопасное получение значения одной колонки
     */
    public function selectValue($sql, $params = []) {
        try {
            $stmt = $this->connection->prepare($sql);
            $stmt->execute($params);
            $result = $stmt->fetch(PDO::FETCH_NUM);
            return $result ? $result[0] : false;
        } catch (PDOException $e) {
            error_log("Select value query error: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Проверка существования записи
     */
    public function exists($table, $conditions = []) {
        $where = [];
        $params = [];
        
        foreach ($conditions as $field => $value) {
            $where[] = "$field = ?";
            $params[] = $value;
        }
        
        $sql = "SELECT 1 FROM $table WHERE " . implode(' AND ', $where) . " LIMIT 1";
        $stmt = $this->connection->prepare($sql);
        $stmt->execute($params);
        
        return (bool) $stmt->fetch();
    }
    
    /**
     * Безопасная вставка с возвратом ID
     */
    public function insert($table, $data) {
        $fields = array_keys($data);
        $placeholders = array_fill(0, count($fields), '?');
        $values = array_values($data);
        
        $sql = "INSERT INTO $table (" . implode(', ', $fields) . ") 
                VALUES (" . implode(', ', $placeholders) . ")";
        
        try {
            $stmt = $this->connection->prepare($sql);
            $stmt->execute($values);
            return $this->connection->lastInsertId();
        } catch (PDOException $e) {
            error_log("Insert query error: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Безопасное обновление
     */
    public function update($table, $data, $conditions) {
        $set = [];
        $where = [];
        $params = [];
        
        foreach ($data as $field => $value) {
            $set[] = "$field = ?";
            $params[] = $value;
        }
        
        foreach ($conditions as $field => $value) {
            $where[] = "$field = ?";
            $params[] = $value;
        }
        
        $sql = "UPDATE $table SET " . implode(', ', $set) . 
               " WHERE " . implode(' AND ', $where);
        
        try {
            $stmt = $this->connection->prepare($sql);
            return $stmt->execute($params);
        } catch (PDOException $e) {
            error_log("Update query error: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Начало транзакции
     */
    public function beginTransaction() {
        return $this->connection->beginTransaction();
    }
    
    /**
     * Подтверждение транзакции
     */
    public function commit() {
        return $this->connection->commit();
    }
    
    /**
     * Откат транзакции
     */
    public function rollBack() {
        return $this->connection->rollBack();
    }
    
    /**
     * Экранирование строки (использовать только в крайних случаях)
     */
    public function quote($string) {
        return $this->connection->quote($string);
    }
}
?>