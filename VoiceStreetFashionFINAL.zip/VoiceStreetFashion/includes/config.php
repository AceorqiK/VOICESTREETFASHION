<?php
// Настройки базы данных
define('DB_HOST', 'localhost');
define('DB_NAME', 'shoes_store');
define('DB_USER', 'root');
define('DB_PASS', '');

// Настройки сайта
define('SITE_NAME', 'VoiceStreetFashion');
define('SITE_SLOGAN', 'Твой стиль - твои правила');
define('SITE_DESCRIPTION', 'Магазин premium кроссовок и уличной одежды от ведущих мировых брендов');

// Новая цветовая схема из фото
define('PRIMARY_COLOR', '#380F17');    // Темно-бордовый
define('SECONDARY_COLOR', '#8F0B13');  // Ярко-красный
define('ACCENT_COLOR', '#EFDFC5');     // Кремовый/бежевый
define('BACKGROUND_COLOR', '#252B2B'); // Темно-серый/черный
define('TEXT_COLOR', '#EFDFC5');       // Светлый текст
define('LIGHT_COLOR', '#4C4F54');      // Серый
define('SUCCESS_COLOR', '#27ae60');    // Зеленый
define('WARNING_COLOR', '#f39c12');    // Оранжевый

// Контакты
define('PHONE', '+7 (999) 123-45-67');
define('EMAIL', 'info@voicestreetfashion.ru');
define('ADDRESS', 'Москва, ул. Тверская, д. 10');

// Социальные сети
define('INSTAGRAM', 'https://instagram.com/voicestreetfashion');
define('TELEGRAM', 'https://t.me/voicestreetfashion');
define('VK', 'https://vk.com/voicestreetfashion');

// Настройки email для подтверждения

define('EMAIL_FROM', 'noreply@voicestreetfashion.ru'); // Должен существовать
define('EMAIL_FROM_NAME', 'VoiceStreetFashion');
define('SITE_URL', 'http://localhost/VoiceStreetFashion'); // Замените на ваш реальный домен

// Настройки безопасности
define('TOKEN_EXPIRY', 24 * 60 * 60); // 24 часа для токена подтверждения
?>
