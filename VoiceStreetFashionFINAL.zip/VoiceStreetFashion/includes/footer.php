<?php
require_once 'config.php';
?>
<footer style="background: var(--primary-color); color: white; padding: 3rem 0; margin-top: 4rem;">
    <div class="container">
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 3rem; margin-bottom: 2rem;">
            <div>
                <h3 style="color: var(--light-color); margin-bottom: 1rem; font-size: 1.5rem;">VoiceStreetFashion</h3>
                <p style="line-height: 1.6; opacity: 0.9;">Ваш голос в мире уличной моды. Премиальная обувь от ведущих мировых брендов с доставкой по всей России.</p>
                <div style="display: flex; gap: 1rem; margin-top: 1rem;">
                    <a href="<?= INSTAGRAM ?>" style="color: white; opacity: 0.8; transition: opacity 0.3s;" onmouseover="this.style.opacity='1'" onmouseout="this.style.opacity='0.8'">
                         Instagram
                    </a>
                    <a href="<?= TELEGRAM ?>" style="color: white; opacity: 0.8; transition: opacity 0.3s;" onmouseover="this.style.opacity='1'" onmouseout="this.style.opacity='0.8'">
                         Telegram
                    </a>
                    <a href="<?= VK ?>" style="color: white; opacity: 0.8; transition: opacity 0.3s;" onmouseover="this.style.opacity='1'" onmouseout="this.style.opacity='0.8'">
                         VK
                    </a>
                </div>
            </div>
            
            <div>
                <h4 style="color: var(--light-color); margin-bottom: 1rem;">Контактная информация</h4>
                <div style="display: flex; flex-direction: column; gap: 0.5rem;">
                    <div style="display: flex; align-items: center; gap: 0.5rem;">
                        <span></span>
                        <span><?= PHONE ?></span>
                    </div>
                    <div style="display: flex; align-items: center; gap: 0.5rem;">
                        <span></span>
                        <span><?= EMAIL ?></span>
                    </div>
                    <div style="display: flex; align-items: center; gap: 0.5rem;">
                        <span></span>
                        <span><?= ADDRESS ?></span>
                    </div>
                </div>
            </div>
            
            <div>
                <h4 style="color: var(--light-color); margin-bottom: 1rem;">Полезные ссылки</h4>
                <div style="display: flex; flex-direction: column; gap: 0.5rem;">
                    <a href="catalog.php" style="color: white; opacity: 0.8; text-decoration: none; transition: opacity 0.3s;" 
                       onmouseover="this.style.opacity='1'" onmouseout="this.style.opacity='0.8'">Каталог обуви</a>
                    <a href="feedback.php" style="color: white; opacity: 0.8; text-decoration: none; transition: opacity 0.3s;" 
                       onmouseover="this.style.opacity='1'" onmouseout="this.style.opacity='0.8'">Обратная связь</a>
                    <a href="login.php" style="color: white; opacity: 0.8; text-decoration: none; transition: opacity 0.3s;" 
                       onmouseover="this.style.opacity='1'" onmouseout="this.style.opacity='0.8'">Личный кабинет</a>
                </div>
            </div>
            
            <div>
                <h4 style="color: var(--light-color); margin-bottom: 1rem;">Часы работы</h4>
                <div style="display: flex; flex-direction: column; gap: 0.5rem; opacity: 0.9;">
                    <div>Пн-Пт: 9:00 - 21:00</div>
                    <div>Сб-Вс: 10:00 - 20:00</div>
                    <div style="margin-top: 0.5rem; font-size: 0.9rem;">Доставка работает ежедневно</div>
                </div>
            </div>
        </div>
        
        <div style="text-align: center; padding-top: 2rem; border-top: 1px solid rgba(255,255,255,0.2);">
            <p style="margin: 0; opacity: 0.8; font-size: 0.9rem;">
                &copy; 2026 VoiceStreetFashion. Все права защищены. 
                <span style="display: block; margin-top: 0.5rem;">
                    Сайт создан для демонстрации возможностей интернет-магазина
                </span>
            </p>
        </div>
    </div>
</footer>
