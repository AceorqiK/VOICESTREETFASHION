<?php
// includes/security.php

class Security {
    
    // Генерация CSRF токена
    public static function generateCSRFToken() {
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }
    
    // Проверка CSRF токена
    public static function verifyCSRFToken($token) {
        if (empty($_SESSION['csrf_token']) || empty($token)) {
            return false;
        }
        return hash_equals($_SESSION['csrf_token'], $token);
    }
    
    // Санация строки
    public static function sanitizeString($string) {
        $string = trim($string);
        $string = strip_tags($string);
        $string = htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
        return $string;
    }
    
    // Валидация email
    public static function validateEmail($email) {
        return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
    }
    
    // Валидация числа
    public static function validateNumber($number, $min = null, $max = null) {
        if (!is_numeric($number)) return false;
        
        $number = (int)$number;
        
        if ($min !== null && $number < $min) return false;
        if ($max !== null && $number > $max) return false;
        
        return true;
    }
    
    // Защита от XSS через Content Security Policy
    public static function setSecurityHeaders() {
        header("X-Content-Type-Options: nosniff");
        header("X-Frame-Options: DENY");
        header("X-XSS-Protection: 1; mode=block");
        
        // CSP header - разрешаем только свои ресурсы
        $csp = "default-src 'self'; ";
        $csp .= "script-src 'self' 'unsafe-inline' https://cdnjs.cloudflare.com; ";
        $csp .= "style-src 'self' 'unsafe-inline' https://cdnjs.cloudflare.com; ";
        $csp .= "img-src 'self' data: https:; ";
        $csp .= "font-src 'self' https://cdnjs.cloudflare.com;";
        
        header("Content-Security-Policy: " . $csp);
    }
    
    // Валидация ID
    public static function validateId($id) {
        return is_numeric($id) && $id > 0 && $id == (int)$id;
    }
    
    // Очистка массива данных
    public static function sanitizeArray($array) {
        $cleanArray = [];
        foreach ($array as $key => $value) {
            if (is_array($value)) {
                $cleanArray[$key] = self::sanitizeArray($value);
            } else {
                $cleanArray[$key] = self::sanitizeString($value);
            }
        }
        return $cleanArray;
    }
}
?>
