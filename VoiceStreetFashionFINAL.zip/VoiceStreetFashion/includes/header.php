<?php
require_once 'config.php';

$cart_count = 0;
if (isset($_SESSION['user_id'])) {
    require_once 'database.php';
    $db = new Database();
    $connection = $db->getConnection();
    $stmt = $connection->prepare("SELECT SUM(quantity) as total FROM cart WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    $cart_count = $result['total'] ?? 0;
}
?>
<header style="background: <?= PRIMARY_COLOR ?>; color: <?= TEXT_COLOR ?>; padding: 1rem 0; position: fixed; width: 100%; top: 0; z-index: 1000; box-shadow: 0 2px 10px rgba(0,0,0,0.3);">
    <div class="container">
        <div style="display: flex; justify-content: space-between; align-items: center;">
            <!-- Логотип -->
            <div class="logo">
                <h1 style="margin: 0; font-size: 1.8rem;">
                    <a href="index.php" style="color: <?= TEXT_COLOR ?>; text-decoration: none; font-weight: bold;">
                        <?= SITE_NAME ?>
                    </a>
                </h1>
            </div>

            <!-- Навигация -->
            <nav>
                <ul style="display: flex; list-style: none; margin: 0; padding: 0; gap: 2rem; align-items: center;">
                    <li><a href="index.php" style="color: <?= TEXT_COLOR ?>; text-decoration: none; font-weight: 500; transition: color 0.3s;" onmouseover="this.style.color='<?= ACCENT_COLOR ?>'" onmouseout="this.style.color='<?= TEXT_COLOR ?>'">Главная</a></li>
                    <li><a href="catalog.php" style="color: <?= TEXT_COLOR ?>; text-decoration: none; font-weight: 500; transition: color 0.3s;" onmouseover="this.style.color='<?= ACCENT_COLOR ?>'" onmouseout="this.style.color='<?= TEXT_COLOR ?>'">Обувь</a></li>
                    <li><a href="feedback.php" style="color: <?= TEXT_COLOR ?>; text-decoration: none; font-weight: 500; transition: color 0.3s;" onmouseover="this.style.color='<?= ACCENT_COLOR ?>'" onmouseout="this.style.color='<?= TEXT_COLOR ?>'">Обратная связь</a></li>
                    <?php if(isset($_SESSION['user_id'])): ?>
                        <?php if($_SESSION['user_id'] == 1): ?>
                            <li><a href="admin.php" style="color: <?= ACCENT_COLOR ?>; text-decoration: none; font-weight: 500;">Админ-панель</a></li>
                        <?php endif; ?>
                        <li><a href="profile.php" style="color: <?= TEXT_COLOR ?>; text-decoration: none; font-weight: 500; transition: color 0.3s;" onmouseover="this.style.color='<?= ACCENT_COLOR ?>'" onmouseout="this.style.color='<?= TEXT_COLOR ?>'">Личный кабинет</a></li>
                        <li><a href="logout.php" style="color: <?= TEXT_COLOR ?>; text-decoration: none; font-weight: 500; transition: color 0.3s;" onmouseover="this.style.color='<?= ACCENT_COLOR ?>'" onmouseout="this.style.color='<?= TEXT_COLOR ?>'">Выйти</a></li>
                    <?php else: ?>
                        <li><a href="login.php" style="color: <?= TEXT_COLOR ?>; text-decoration: none; font-weight: 500; transition: color 0.3s;" onmouseover="this.style.color='<?= ACCENT_COLOR ?>'" onmouseout="this.style.color='<?= TEXT_COLOR ?>'">Войти</a></li>
                        <li><a href="register.php" style="color: <?= TEXT_COLOR ?>; text-decoration: none; font-weight: 500; transition: color 0.3s;" onmouseover="this.style.color='<?= ACCENT_COLOR ?>'" onmouseout="this.style.color='<?= TEXT_COLOR ?>'">Регистрация</a></li>
                    <?php endif; ?>
                </ul>
            </nav>

            <!-- Поиск и корзина -->
            <div style="display: flex; align-items: center; gap: 1rem;">
                <div class="search-box" style="display: flex;">
                    <input type="text" id="searchInput" placeholder="Поиск товаров..." style="padding: 0.5rem; border: none; border-radius: 4px 0 0 4px; background: <?= LIGHT_COLOR ?>; color: <?= TEXT_COLOR ?>;">
                    <button onclick="searchProducts()" style="padding: 0.5rem 1rem; background: <?= SECONDARY_COLOR ?>; color: white; border: none; border-radius: 0 4px 0; cursor: pointer;">Найти</button>
                </div>
                <a href="cart.php" class="cart-link" style="background: <?= SECONDARY_COLOR ?>; color: white; padding: 0.5rem 1rem; text-decoration: none; border-radius: 4px; transition: background 0.3s;" onmouseover="this.style.background='#a00d15'" onmouseout="this.style.background='<?= SECONDARY_COLOR ?>'">
                    Корзина <?= $cart_count > 0 ? "($cart_count)" : '' ?>
                </a>
            </div>
        </div>
    </div>
</header>
