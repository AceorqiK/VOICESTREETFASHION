<?php
session_start();

// Подключаем security functions
require_once 'includes/security.php';

// Устанавливаем security headers
Security::setSecurityHeaders();

// Проверка CSRF токена
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!Security::verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $_SESSION['cart_error'] = "Ошибка безопасности. Пожалуйста, попробуйте еще раз.";
        header("Location: " . ($_SERVER['HTTP_REFERER'] ?? 'catalog.php'));
        exit;
    }
}

require_once 'includes/database.php';

$db = new Database();
$connection = $db->getConnection();

// Валидация входных данных
$product_id = isset($_POST['product_id']) ? (int)$_POST['product_id'] : 0;
$size = isset($_POST['size']) ? Security::sanitizeString($_POST['size']) : '';

if (!$product_id || $product_id <= 0) {
    $_SESSION['cart_error'] = "Неверный идентификатор товара";
    header("Location: catalog.php");
    exit;
}

if (empty($size)) {
    $_SESSION['cart_error'] = "Выберите размер";
    header("Location: product.php?id=$product_id");
    exit;
}

// Проверка существования товара
try {
    $stmt = $connection->prepare("SELECT * FROM products WHERE id = ? AND in_stock_quantity > 0");
    $stmt->execute([$product_id]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$product) {
        $_SESSION['cart_error'] = "Товар не найден или отсутствует в наличии";
        header("Location: product.php?id=$product_id");
        exit;
    }
    
    // Проверка доступности размера
    $sizes = explode(',', $product['size_range'] ?? '');
    $clean_sizes = array_map('trim', $sizes);
    if (!in_array($size, $clean_sizes)) {
        $_SESSION['cart_error'] = "Выбранный размер недоступен для этого товара";
        header("Location: product.php?id=$product_id");
        exit;
    }
    
    // Инициализация корзины
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }
    
    // Добавление товара в корзину
    $cart_item_key = $product_id . '_' . $size;
    
    if (isset($_SESSION['cart'][$cart_item_key])) {
        $_SESSION['cart'][$cart_item_key]['quantity'] += 1;
    } else {
        $_SESSION['cart'][$cart_item_key] = [
            'product_id' => $product_id,
            'size' => $size,
            'quantity' => 1,
            'price' => $product['price'],
            'name' => $product['name'],
            'image_url' => $product['image_url']
        ];
    }
    
    $_SESSION['cart_success'] = "Товар успешно добавлен в корзину!";
    
} catch (Exception $e) {
    error_log("Ошибка при добавлении в корзину: " . $e->getMessage());
    $_SESSION['cart_error'] = "Произошла ошибка при добавлении товара в корзину";
}

// Перенаправление обратно на страницу товара
header("Location: product.php?id=$product_id");
exit;
?>
