<?php
session_start();
require_once 'includes/database.php';
require_once 'includes/config.php';

// Класс безопасности
class Security {
    public static function escape($data) {
        if (is_array($data)) {
            return array_map([self::class, 'escape'], $data);
        }
        return htmlspecialchars($data, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    }
    
    public static function validateInput($data, $type = 'string') {
        if ($data === null) return '';
        
        $data = trim($data);
        $data = stripslashes($data);
        
        switch ($type) {
            case 'email':
                $data = filter_var($data, FILTER_SANITIZE_EMAIL);
                return filter_var($data, FILTER_VALIDATE_EMAIL) ? $data : false;
            case 'int':
                return filter_var($data, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
            case 'text':
                return self::escape($data);
            default:
                return self::escape($data);
        }
    }
}

$db = new Database();
$connection = $db->getConnection();

// ЗАЩИТА: Проверяем, является ли пользователь администратором
$is_admin = false;
$cart_count = 0; // Переменная для количества товаров в корзине

if(isset($_SESSION['user_id'])) {
    $user_id = Security::validateInput($_SESSION['user_id'], 'int');
    
    if ($user_id) {
        try {
            // ЗАЩИТА: Подготовленный запрос для проверки роли
            $stmt = $connection->prepare("SELECT role FROM users WHERE id = ?");
            $stmt->execute([$user_id]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($user && isset($user['role'])) {
                $is_admin = ($user['role'] === 'admin');
                $_SESSION['is_admin'] = $is_admin;
            } else {
                // Если колонки role нет, используем ID пользователя как fallback
                $is_admin = ($user_id == 1);
                $_SESSION['is_admin'] = $is_admin;
            }
            
            // ПОЛУЧАЕМ КОЛИЧЕСТВО ТОВАРОВ В КОРЗИНЕ
            $stmt = $connection->prepare("SELECT SUM(quantity) as total FROM cart WHERE user_id = ?");
            $stmt->execute([$user_id]);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            $cart_count = $result['total'] ?? 0;
            
        } catch (PDOException $e) {
            // Если произошла ошибка (колонка role не существует), используем fallback
            error_log("Ошибка проверки роли: " . $e->getMessage());
            $is_admin = ($user_id == 1); // ID 1 = администратор
            $_SESSION['is_admin'] = $is_admin;
            
            // Пытаемся получить количество товаров в корзине
            try {
                $stmt = $connection->prepare("SELECT SUM(quantity) as total FROM cart WHERE user_id = ?");
                $stmt->execute([$user_id]);
                $result = $stmt->fetch(PDO::FETCH_ASSOC);
                $cart_count = $result['total'] ?? 0;
            } catch (PDOException $e2) {
                error_log("Ошибка получения количества товаров в корзине: " . $e2->getMessage());
                $cart_count = 0;
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- ЗАЩИТА ОТ XSS: экранируем вывод -->
    <title><?= Security::escape(SITE_NAME) ?> - <?= Security::escape(SITE_SLOGAN) ?></title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #000;
            --secondary-color: #111;
            --accent-color: #555;
            --light-color: #eee;
            --text-color: #333;
            --success-color: #28a745;
            --border-color: #ddd;
            --admin-color: #dc3545;
        }
        
        /* Base Responsive Styles */
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        
        html {
            font-size: 16px;
        }
        
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            overflow-x: hidden;
        }
        
        .container {
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 1rem;
        }
        
        /* Header Styles - Full Width */
        header {
            background: white;
            box-shadow: 0 2px 20px rgba(0,0,0,0.1);
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            padding: 0.5rem 0;
            width: 100%;
        }
        
        .header-full-width {
            width: 100%;
            margin: 0;
            padding: 0 1rem;
        }
        
        .header-container {
            display: flex;
            align-items: center;
            justify-content: space-between;
            width: 100%;
            gap: 1rem;
        }
        
        .logo {
            display: flex;
            flex-direction: column;
            align-items: flex-start;
            flex-shrink: 0;
        }
        
        .logo h1 {
            color: var(--primary-color) !important;
            font-size: clamp(1.2rem, 4vw, 1.8rem);
            font-weight: bold;
            margin: 0;
            line-height: 1;
        }
        
        .logo span {
            color: var(--secondary-color);
            font-size: clamp(0.6rem, 2vw, 0.8rem);
            margin-top: 2px;
        }
        
        nav {
            flex: 1;
            display: flex;
            justify-content: center;
            margin: 0 1rem;
        }
        
        nav ul {
            display: flex;
            list-style: none;
            margin: 0;
            padding: 0;
            gap: clamp(0.5rem, 2vw, 2rem);
        }
        
        nav a {
            text-decoration: none;
            color: var(--text-color);
            font-weight: 500;
            font-size: clamp(0.8rem, 2.5vw, 1rem);
            transition: color 0.3s;
            position: relative;
            white-space: nowrap;
            padding: 0.5rem 0;
        }
        
        nav a:hover {
            color: var(--primary-color);
        }
        
        nav a::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 0;
            height: 2px;
            background: var(--primary-color);
            transition: width 0.3s;
        }
        
        nav a:hover::after {
            width: 100%;
        }
        
        .admin-link {
            color: var(--admin-color) !important;
            font-weight: 600 !important;
        }
        
        .admin-link:hover {
            color: var(--admin-color) !important;
        }
        
        .admin-link::after {
            background: var(--admin-color) !important;
        }
        
        .header-actions {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            justify-content: flex-end;
            flex-shrink: 0;
        }
        
        .search-box {
            display: flex;
            background: var(--light-color);
            border-radius: 25px;
            padding: 0.4rem;
            border: 2px solid transparent;
            transition: border-color 0.3s;
            min-width: min(250px, 40vw);
            margin-right: 0.5rem;
        }
        
        .search-box:focus-within {
            border-color: var(--primary-color);
        }
        
        .search-box input {
            border: none;
            background: none;
            outline: none;
            padding: 0 1rem;
            width: 100%;
            font-size: 0.9rem;
        }
        
        .search-box button {
            background: var(--primary-color);
            color: white;
            border: none;
            padding: 0.4rem 1rem;
            border-radius: 20px;
            cursor: pointer;
            font-size: 0.9rem;
            transition: background 0.3s;
            white-space: nowrap;
        }
        
        .search-box button:hover {
            background: var(--secondary-color);
        }
        
        .cart-link {
            display: flex;
            align-items: center;
            text-decoration: none;
            color: var(--text-color);
            transition: color 0.3s;
            padding: 0.5rem;
            position: relative;
            background: none !important;
        }
        
        .cart-link:hover {
            color: var(--primary-color);
        }
        
        .cart-icon {
            width: 24px;
            height: 24px;
        }
        
        .cart-count {
            background: var(--accent-color);
            color: white;
            border-radius: 50%;
            width: 18px;
            height: 18px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.7rem;
            position: absolute;
            top: 2px;
            right: 2px;
            font-weight: bold;
        }

        /* Mobile menu button */
        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            font-size: 1.5rem;
            color: var(--text-color);
            cursor: pointer;
            padding: 0.5rem;
        }

        /* Hero section margin for fixed header */
        .hero-section {
            margin-top: 80px;
        }

        /* Mobile Navigation */
        @media (max-width: 768px) {
            .header-container {
                flex-wrap: wrap;
                gap: 0.5rem;
            }
            
            .mobile-menu-btn {
                display: block;
                order: 1;
            }
            
            .logo {
                order: 2;
                flex: 1;
                text-align: center;
                align-items: center;
            }
            
            .header-actions {
                order: 3;
            }
            
            nav {
                order: 4;
                display: none;
                width: 100%;
                margin: 0;
            }
            
            nav.active {
                display: block;
            }
            
            nav ul {
                flex-direction: column;
                gap: 0;
                width: 100%;
            }
            
            nav li {
                width: 100%;
                border-bottom: 1px solid var(--border-color);
            }
            
            nav a {
                display: block;
                padding: 1rem;
                text-align: center;
            }
            
            .search-box {
                min-width: 150px;
                margin-right: 0;
            }
            
            .header-actions {
                min-width: auto;
            }
        }

        @media (max-width: 480px) {
            .header-full-width {
                padding: 0 0.5rem;
            }
            
            .search-box {
                min-width: 120px;
            }
            
            .search-box input {
                padding: 0 0.5rem;
            }
            
            .search-box button {
                padding: 0.4rem 0.8rem;
            }
        }

        /* Hero Section */
        .hero-section {
            background: linear-gradient(135deg, var(--secondary-color) 0%, var(--primary-color) 100%);
            color: white;
            padding: clamp(3rem, 8vw, 6rem) 0;
            text-align: center;
            position: relative;
            overflow: hidden;
        }
        
        .hero-section::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('images/magaz.jpg') center/cover;
            opacity: 0.1;
        }
        
        .hero-content {
            position: relative;
            z-index: 2;
            max-width: 800px;
            margin: 0 auto;
        }
        
        .hero-title {
            font-size: clamp(2rem, 6vw, 3.5rem);
            margin-bottom: 1rem;
            font-weight: bold;
            line-height: 1.2;
        }
        
        .hero-subtitle {
            font-size: clamp(1.1rem, 3vw, 1.5rem);
            margin-bottom: 2rem;
            opacity: 0.9;
        }

        /* Statistics Grid */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 1rem;
            margin-top: 2rem;
        }
        
        .stat-item {
            text-align: center;
            padding: 1.5rem 0.5rem;
        }
        
        .stat-number {
            font-size: clamp(1.8rem, 4vw, 2.8rem);
            font-weight: bold;
            color: #000;
            margin-bottom: 0.5rem;
            line-height: 1;
        }
        
        .stat-label {
            color: #000;
            font-size: clamp(0.9rem, 2vw, 1.1rem);
            font-weight: 500;
        }

        /* Features Grid */
        .features-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-top: 2rem;
        }
        
        .feature-card {
            text-align: center;
            padding: 2rem 1rem;
            background: white;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            cursor: pointer;
        }
        
        .feature-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.15);
        }

        /* Brands Section */
        .brands-section {
            background: white;
            padding: clamp(2rem, 6vw, 4rem) 0;
            border-top: 1px solid #eee;
            border-bottom: 1px solid #eee;
        }
        
        .brands-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 1rem;
            margin-top: 2rem;
        }
        
        .brand-logo {
            background: white;
            border: 2px solid #000;
            padding: 1.5rem 0.5rem;
            text-align: center;
            font-weight: bold;
            font-size: clamp(1rem, 3vw, 1.5rem);
            color: #000;
            transition: all 0.3s ease;
            cursor: pointer;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .brand-logo:hover {
            background: #000;
            color: white;
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        /* Categories Section */
        .categories {
            background: white;
            padding: clamp(2rem, 6vw, 4rem) 0;
        }
        
        .category-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-top: 2rem;
        }
        
        .category-card {
            background: white;
            border-radius: 0;
            padding: 0;
            text-decoration: none;
            color: var(--text-color);
            transition: all 0.3s ease;
            text-align: center;
            border: 2px solid #000;
            position: relative;
            overflow: hidden;
        }
        
        .category-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }
        
        .category-card h3 {
            font-size: clamp(1.2rem, 3vw, 1.5rem);
            margin: 1rem 0 0.5rem 0;
            font-weight: bold;
            color: #000;
            padding: 0 1rem;
        }
        
        .category-card p {
            line-height: 1.5;
            opacity: 0.8;
            font-size: 0.9rem;
            color: var(--text-color);
            padding: 0 1rem 1.5rem 1rem;
            margin: 0;
        }
        
        .category-image {
            width: 100%;
            height: 200px;
            margin: 0;
            background: white;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            border-bottom: 2px solid #000;
        }
        
        .category-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        /* Buttons */
        .btn {
            display: inline-block;
            background: white;
            color: var(--primary-color);
            padding: clamp(0.8rem, 2vw, 1rem) clamp(1.5rem, 3vw, 2rem);
            font-size: clamp(1rem, 2.5vw, 1.1rem);
            text-decoration: none;
            border-radius: 5px;
            transition: all 0.3s ease;
            border: 2px solid transparent;
        }
        
        .btn:hover {
            background: var(--primary-color);
            color: white;
        }

        /* Section Headers */
        .section-header {
            text-align: center;
            color: #000;
            font-size: clamp(1.8rem, 5vw, 2.5rem);
            margin-bottom: clamp(1.5rem, 4vw, 3rem);
            font-weight: bold;
        }

        /* Footer */
        footer {
            background: var(--primary-color);
            color: white;
            padding: clamp(2rem, 5vw, 3rem) 0;
            margin-top: 4rem;
        }
        
        .footer-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 2rem;
            margin-bottom: 2rem;
        }
        
        .footer-column h3,
        .footer-column h4 {
            color: var(--light-color);
            margin-bottom: 1rem;
        }
        
        .footer-links {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }
        
        .footer-links a {
            color: white;
            opacity: 0.8;
            text-decoration: none;
            transition: opacity 0.3s;
        }
        
        .footer-links a:hover {
            opacity: 1;
        }
        
        .footer-bottom {
            text-align: center;
            padding-top: 2rem;
            border-top: 1px solid rgba(255,255,255,0.2);
        }
        
        .footer-bottom p {
            margin: 0;
            opacity: 0.8;
            font-size: 0.9rem;
        }

        /* Small screens adjustments */
        @media (max-width: 360px) {
            .brands-grid {
                grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
            }
            
            .category-grid {
                grid-template-columns: 1fr;
            }
            
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }
    </style>
</head>
<body>
    <!-- Header - Full Width -->
    <header>
        <div class="header-full-width">
            <div class="header-container">
                <button class="mobile-menu-btn">
                    <i class="fas fa-bars"></i>
                </button>
                
                <div class="logo">
                    <!-- ЗАЩИТА ОТ XSS: экранируем вывод -->
                    <h1><?= Security::escape(SITE_NAME) ?></h1>
                </div>
                
                <nav id="main-nav">
                    <ul>
                        <li><a href="index.php" style="color: var(--primary-color);">Главная</a></li>
                        <li><a href="catalog.php">Обувь</a></li>
                        <li><a href="feedback.php">Обратная связь</a></li>
                        <?php if(isset($_SESSION['user_id'])): ?>
                            <?php if($is_admin): ?>
                                <li><a href="admin.php" class="admin-link">Админ панель</a></li>
                            <?php endif; ?>
                            <li><a href="profile.php">Личный кабинет</a></li>
                            <li><a href="logout.php">Выйти</a></li>
                        <?php else: ?>
                            <li><a href="login.php">Войти</a></li>
                            <li><a href="register.php">Регистрация</a></li>
                        <?php endif; ?>
                    </ul>
                </nav>
                
                <div class="header-actions">
                    <div class="search-box">
                        <input type="text" id="searchInput" placeholder="Поиск товаров...">
                        <button onclick="searchProducts()">
                            <i class="fas fa-search"></i>
                        </button>
                    </div>
                    
                    <a href="cart.php" class="cart-link">
                        <svg class="cart-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path>
                            <line x1="3" y1="6" x2="21" y2="6"></line>
                            <path d="M16 10a4 4 0 0 1-8 0"></path>
                        </svg>
                        <?php if($cart_count > 0): ?>
                            <span class="cart-count"><?= Security::escape($cart_count) ?></span>
                        <?php endif; ?>
                    </a>
                </div>
            </div>
        </div>
    </header>

    <!-- Hero Section -->
    <section class="hero-section">
        <div class="container">
            <div class="hero-content">
                <!-- ЗАЩИТА ОТ XSS: экранируем вывод -->
                <h1 class="hero-title"><?= Security::escape(SITE_NAME) ?></h1>
                <p class="hero-subtitle"><?= Security::escape(SITE_SLOGAN) ?></p>
                <p style="font-size: clamp(1rem, 2.5vw, 1.2rem); margin-bottom: 2rem; opacity: 0.9;">
                    Открой для себя мир уличной моды и премиальной обуви от ведущих брендов
                </p>
                <a href="catalog.php" class="btn">
                    Начать покупки
                </a>
            </div>
        </div>
    </section>

    <!-- About Section -->
    <section class="history-section" style="background: white; padding: clamp(2rem, 6vw, 4rem) 0;">
        <div class="container">
            <div style="max-width: 1000px; margin: 0 auto; text-align: center;">
                <h1 class="section-header">Наша история</h1>
                
                <!-- Statistics Grid -->
                <div class="stats-grid">
                    <div class="stat-item">
                        <div class="stat-number">8+</div>
                        <div class="stat-label">Лет на рынке</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-number">50,000+</div>
                        <div class="stat-label">Довольных клиентов</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-number">200+</div>
                        <div class="stat-label">Брендов</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-number">15</div>
                        <div class="stat-label">Магазинов по России</div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section class="features-section" style="background: white; padding: clamp(2rem, 6vw, 4rem) 0;">
        <div class="container">
            <div style="max-width: 1000px; margin: 0 auto; text-align: center;">
                <h1 class="section-header">Почему выбирают нас</h1>
                
                <!-- Features Grid -->
                <div class="features-grid">
                    <!-- Быстрая доставка -->
                    <div class="feature-card">
                        <div style="font-size: 2rem; margin-bottom: 1rem; transition: transform 0.3s ease;">
                            <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M5 18H3c-.6 0-1-.4-1-1V7c0-.6.4-1 1-1h10c.6 0 1 .4 1 1v11"/>
                                <path d="M14 9h4l4 4v4c0 .6-.4 1-1 1h-2"/>
                                <circle cx="7" cy="18" r="2"/>
                                <path d="M15 18H9"/>
                                <circle cx="17" cy="18" r="2"/>
                            </svg>
                        </div>
                        <div style="color: #000; font-size: 1.2rem; font-weight: 500;">Быстрая доставка</div>
                    </div>
                    
                    <!-- Гарантия подлинности -->
                    <div class="feature-card">
                        <div style="font-size: 2rem; margin-bottom: 1rem;">
                            <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
                                <path d="m9 12 2 2 4-4"/>
                            </svg>
                        </div>
                        <div style="color: #000; font-size: 1.2rem; font-weight: 500;">Гарантия подлинности</div>
                    </div>
                    
                    <!-- Удобная оплата -->
                    <div class="feature-card">
                        <div style="font-size: 2rem; margin-bottom: 1rem;">
                            <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                                <rect x="2" y="5" width="20" height="14" rx="2"/>
                                <line x1="2" y1="10" x2="22" y2="10"/>
                            </svg>
                        </div>
                        <div style="color: #000; font-size: 1.2rem; font-weight: 500;">Удобная оплата</div>
                    </div>
                    
                    <!-- Легкий возврат -->
                    <div class="feature-card">
                        <div style="font-size: 2rem; margin-bottom: 1rem;">
                            <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M3 12a9 9 0 1 0 18 0 9 9 0 0 0-18 0"/>
                                <path d="m9 12 2 2 4-4"/>
                                <path d="M12 7v5"/>
                            </svg>
                        </div>
                        <div style="color: #000; font-size: 1.2rem; font-weight: 500;">Легкий возврат</div>
                    </div>
                    
                    <!-- Эксклюзивные модели -->
                    <div class="feature-card">
                        <div style="font-size: 2rem; margin-bottom: 1rem;">
                            <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M12 2 2 7l10 5 10-5-10-5z"/>
                                <path d="M2 17l10 5 10-5"/>
                                <path d="M2 12l10 5 10-5"/>
                            </svg>
                        </div>
                        <div style="color: #000; font-size: 1.2rem; font-weight: 500;">Эксклюзивные модели</div>
                    </div>
                    
                    <!-- Профессиональный подбор -->
                    <div class="feature-card">
                        <div style="font-size: 2rem; margin-bottom: 1rem;">
                            <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                                <circle cx="12" cy="8" r="7"/>
                                <path d="M8.21 13.89 7 23l5-3 5 3-1.21-9.12"/>
                            </svg>
                        </div>
                        <div style="color: #000; font-size: 1.2rem; font-weight: 500;">Профессиональный подбор</div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Brands Section -->
    <section class="brands-section">
        <div class="container">
            <h2 class="section-header">Наши бренды</h2>
            <p style="font-size: clamp(1rem, 2.5vw, 1.2rem); color: #333; margin-bottom: 2rem; text-align: center;">
                Работаем с ведущими мировыми производителями уличной моды
            </p>
            <div class="brands-grid">
                <div class="brand-logo">NIKE</div>
                <div class="brand-logo">ADIDAS</div>
                <div class="brand-logo">JORDAN</div>
                <div class="brand-logo">ASICS</div>
                <div class="brand-logo">LACOSTE</div>
            </div>
        </div>
    </section>

    <!-- Categories Section -->
    <section class="categories">
        <div class="container">
            <h2 class="section-header">Категории обуви</h2>
            <div class="category-grid">
                <a href="catalog.php?category=sneakers" class="category-card">
                    <div class="category-image">
                        <img src="images/af1.png" alt="Кроссовки">
                    </div>
                    <h3>Кроссовки</h3>
                    <p>Современные модели для повседневной носки и спорта</p>
                </a>
                
                <a href="catalog.php?category=boots" class="category-card">
                    <div class="category-image">
                        <img src="images/timbi.png" alt="Ботинки">
                    </div>
                    <h3>Зимняя обувь</h3>
                    <p>Теплые и стильные ботинки для холодного сезона</p>
                </a>
                
                <a href="catalog.php?category=sport" class="category-card">
                    <div class="category-image">
                        <img src="images/asics.png" alt="Спортивная обувь">
                    </div>
                    <h3>Обувь для спорта</h3>
                    <p>Профессиональная обувь для тренировок и соревнований</p>
                </a>
                
                <a href="catalog.php?category=keds" class="category-card">
                    <div class="category-image">
                        <img src="images/mais.webp" alt="Кеды">
                    </div>
                    <h3>Кеды</h3>
                    <p>Классические кеды и новые модели для стильного образа</p>
                </a>
            </div>
        </div>
    </section>

    <script>
        // Mobile menu toggle
        document.querySelector('.mobile-menu-btn').addEventListener('click', function() {
            document.getElementById('main-nav').classList.toggle('active');
        });

        // Close mobile menu when clicking outside
        document.addEventListener('click', function(event) {
            const nav = document.getElementById('main-nav');
            const menuBtn = document.querySelector('.mobile-menu-btn');
            if (!nav.contains(event.target) && !menuBtn.contains(event.target)) {
                nav.classList.remove('active');
            }
        });

        function searchProducts() {
            const searchTerm = document.getElementById('searchInput').value;
            if (searchTerm.trim()) {
                // ЗАЩИТА: Кодируем параметры URL
                window.location.href = `catalog.php?search=${encodeURIComponent(searchTerm)}`;
            }
        }

        // Search on Enter key
        document.getElementById('searchInput').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                searchProducts();
            }
        });

        // Close menu when clicking on link (mobile)
        document.querySelectorAll('nav a').forEach(link => {
            link.addEventListener('click', function() {
                document.getElementById('main-nav').classList.remove('active');
            });
        });
    </script>

    <footer>
        <div class="container">
            <div class="footer-grid">
                <div>
                    <!-- ЗАЩИТА ОТ XSS: экранируем вывод -->
                    <h3><?= Security::escape(SITE_NAME) ?></h3>
                    <p style="line-height: 1.6; opacity: 0.9;">Ваш голос в мире уличной моды. Премиальная обувь от ведущих мировых брендов с доставкой по всей России.</p>
                    <div style="display: flex; gap: 1rem; margin-top: 1rem;">
                        <a href="<?= Security::escape(INSTAGRAM) ?>" style="color: white; opacity: 0.8; transition: opacity 0.3s;" onmouseover="this.style.opacity='1'" onmouseout="this.style.opacity='0.8'">
                             Instagram
                        </a>
                        <a href="<?= Security::escape(TELEGRAM) ?>" style="color: white; opacity: 0.8; transition: opacity 0.3s;" onmouseover="this.style.opacity='1'" onmouseout="this.style.opacity='0.8'">
                             Telegram
                        </a>
                        <a href="<?= Security::escape(VK) ?>" style="color: white; opacity: 0.8; transition: opacity 0.3s;" onmouseover="this.style.opacity='1'" onmouseout="this.style.opacity='0.8'">
                             VK
                        </a>
                    </div>
                </div>
                
                <div>
                    <h4>Контактная информация</h4>
                    <div class="footer-links">
                        <div style="display: flex; align-items: center; gap: 0.5rem;">
                            <span></span>
                            <!-- ЗАЩИТА ОТ XSS: экранируем контактные данные -->
                            <span><?= Security::escape(PHONE) ?></span>
                        </div>
                        <div style="display: flex; align-items: center; gap: 0.5rem;">
                            <span></span>
                            <span><?= Security::escape(EMAIL) ?></span>
                        </div>
                        <div style="display: flex; align-items: center; gap: 0.5rem;">
                            <span></span>
                            <span><?= Security::escape(ADDRESS) ?></span>
                        </div>
                    </div>
                </div>
                
                <div>
                    <h4>Полезные ссылки</h4>
                    <div class="footer-links">
                        <a href="catalog.php">Каталог обуви</a>
                        <a href="feedback.php">Обратная связь</a>
                        <a href="login.php">Личный кабинет</a>
                    </div>
                </div>
                
                <div>
                    <h4>Часы работы</h4>
                    <div style="display: flex; flex-direction: column; gap: 0.5rem; opacity: 0.9;">
                        <div>Пн-Пт: 9:00 - 21:00</div>
                        <div>Сб-Вс: 10:00 - 20:00</div>
                        <div style="margin-top: 0.5rem; font-size: 0.9rem;">Доставка работает ежедневно</div>
                    </div>
                </div>
            </div>
            <div class="footer-bottom">
                <p>
                    &copy; 2026 <?= Security::escape(SITE_NAME) ?>. Все права защищены. 
                    <span style="display: block; margin-top: 0.5rem;">
                        Сайт создан для демонстрации возможностей интернет-магазина
                    </span>
                </p>
            </div>
        </div>
    </footer>
</body>
</html>